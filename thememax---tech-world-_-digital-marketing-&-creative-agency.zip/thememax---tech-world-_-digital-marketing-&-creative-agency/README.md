# Thememax - Tech World | Premium Digital Marketing & Creative Agency

> *"Ideas That Move Businesses Forward."*

A modern, high-craft, and fully interactive digital marketing agency web platform built with React, TypeScript, Tailwind CSS, Motion design, and responsive component architecture.

---

## 🚀 Key Highlights & Architectural Features

### 1. Brand Identity & Visual Theme
- **Thememax Tech World Logo**: Precision vector reproduction of the signature logo featuring the vibrant orange rounded 'T', deep crimson 'heme', vivid scarlet 'ma', and interlocking midnight slate/orange 'x' with the glowing cyber globe in the 'O' of 'WORLD'.
- **Color Discipline**:
  - Dominant Neutral Canvas: Midnight Dark Slate (`#0A0E17`) & Deep Black (`#05080E`) / Off-White light mode (`#F9FAFB`)
  - Signature Warm Brand Accent: Vibrant Orange / Vermilion (`#FF5722`)
  - Secondary Brand Crimson: Ruby Scarlet (`#DC2626` / `#B91C1C`)
  - Cyber Tech Glow: Electric Cyan (`#00D2FF`) for network data nodes and speed metrics
- **Custom Primary Navigation Icons**: Hand-crafted vector iconography tailored to each agency discipline (Services, Industries, Work, Case Studies, About, Insights).

### 2. Global Header & Top Bar Contract
- **Sticky Glassmorphism**: Starts transparent over the hero, transitions to blurred glass on scroll.
- **Three-Zone Contract**: Brand mark, 6 clean navigation links with custom icons and spring layout indicator, search trigger, theme switcher, and primary "Start a Project →" CTA.
- **Mobile Drawer**: Fluid slideout navigation menu with search and theme controls.

### 3. Core Pages & Routes
| Path | Page | Description |
| :--- | :--- | :--- |
| `/` | **Home** | Full-screen cinematic hero with 3D cyber sphere, client logo marquee, who we are, featured disciplines, selected work, deep case studies, interactive 6-stage methodology, animated counters, testimonial slider, creative wall, technology stack, and final CTA. |
| `/about` | **About** | Agency genesis, operating principles, core values, leadership team, and verifiable proof metrics. |
| `/services` | **Services** | 5 comprehensive expandable categories: Strategy & Branding, Digital & Performance Marketing, Social Media & Influence, Creative & Content, Web & Technology with metrics and deliverable manifests. |
| `/work` | **Work / Portfolio** | Filterable portfolio across Branding, Websites, Social Media, Performance, Video, and Ecommerce with interactive modal deep-dives. |
| `/case-studies` | **Case Studies** | Detailed transformation breakdowns (Nova Properties, Aurelia Beauty, Vertex Mobility) covering Challenge, Solution, Tactical Execution, and Verified Metrics. |
| `/industries` | **Industries** | 12 dedicated industry matrices (Real Estate, Automotive, Healthcare, Education, Ecommerce, Finance, Hospitality, Fashion, Beauty, Technology, Manufacturing, Food & Beverage). |
| `/blog` | **Ideas & Insights** | Editorial articles with category filtering, reading time estimates, author credits, and reader drawer. |
| `/contact` | **Contact** | Validated project brief form with multi-select services, budget tiering, honeypot anti-spam protection, and simulated API persistence. |

### 4. Interactive Components & Micro-Interactions
- **Global Search Overlay**: Keyboard-accessible (`ESC` to exit) index searching services, case studies, industries, portfolio projects, and editorial articles in real-time.
- **Project Detail Modal**: Full-screen dialog with key metrics, tech stack tags, deliverables checklist, and direct action.
- **Testimonial Carousel**: Autoplay with pause-on-hover, previous/next controls, and verifiable client attribution.
- **Client Logo Marquee**: Infinite horizontal ticker with hover pause.
- **Stats Counter**: Viewport-triggered animated counting numbers.
- **Dark / Light Theme Switcher**: Automatically syncs with `localStorage` and `prefers-color-scheme`.

### 5. Technical Excellence & Standards
- **Zero Broken Images**: Fully styled, high-craft SVG and CSS fallback containers with brand graphics.
- **WCAG AA Compliance**: High-contrast typography, visible focus states, ARIA labels, semantic markup, and `prefers-reduced-motion` support.
- **Zero-Pill Discipline**: Metadata displayed as clean, unboxed text with subtle typographic separators (`·`).

---

## 🛠️ Tech Stack

- **React 19**
- **TypeScript**
- **Vite 8**
- **Tailwind CSS 4**
- **Motion / Framer Motion**
- **React Router DOM 7**
- **Lucide Icons**

---

## 📦 Getting Started

```bash
# 1. Install dependencies
npm install

# 2. Launch development server (Port 3000)
npm run dev

# 3. Build for production
npm run build

# 4. Type check / lint
npm run lint
```
