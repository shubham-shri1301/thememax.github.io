import { servicesData, ServiceCategory } from "../data/servicesData";
import { portfolioData, Project } from "../data/portfolioData";
import { caseStudiesData, CaseStudy } from "../data/caseStudiesData";
import { blogData, BlogPost } from "../data/blogData";

export interface ContactSubmission {
  name: string;
  company: string;
  email: string;
  phone: string;
  website?: string;
  services: string[];
  budget: string;
  details: string;
  honeypot?: string;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "";

// Delay simulation for realistic async transitions
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export const api = {
  async getServices(): Promise<ApiResponse<ServiceCategory[]>> {
    try {
      if (API_BASE_URL) {
        const res = await fetch(`${API_BASE_URL}/services`);
        if (!res.ok) throw new Error("Failed to fetch services");
        const json = await res.json();
        return { success: true, data: json };
      }
      await delay(120);
      return { success: true, data: servicesData };
    } catch {
      return { success: true, data: servicesData };
    }
  },

  async getPortfolio(category?: string): Promise<ApiResponse<Project[]>> {
    try {
      if (API_BASE_URL) {
        const url = category && category !== "All" 
          ? `${API_BASE_URL}/portfolio?category=${encodeURIComponent(category)}`
          : `${API_BASE_URL}/portfolio`;
        const res = await fetch(url);
        if (!res.ok) throw new Error("Failed to fetch portfolio");
        const json = await res.json();
        return { success: true, data: json };
      }
      await delay(120);
      let items = portfolioData;
      if (category && category !== "All") {
        items = items.filter((p) => p.category === category);
      }
      return { success: true, data: items };
    } catch {
      return { success: true, data: portfolioData };
    }
  },

  async getCaseStudies(): Promise<ApiResponse<CaseStudy[]>> {
    try {
      if (API_BASE_URL) {
        const res = await fetch(`${API_BASE_URL}/case-studies`);
        if (!res.ok) throw new Error("Failed to fetch case studies");
        const json = await res.json();
        return { success: true, data: json };
      }
      await delay(100);
      return { success: true, data: caseStudiesData };
    } catch {
      return { success: true, data: caseStudiesData };
    }
  },

  async getBlog(): Promise<ApiResponse<BlogPost[]>> {
    try {
      if (API_BASE_URL) {
        const res = await fetch(`${API_BASE_URL}/blog`);
        if (!res.ok) throw new Error("Failed to fetch blog");
        const json = await res.json();
        return { success: true, data: json };
      }
      await delay(100);
      return { success: true, data: blogData };
    } catch {
      return { success: true, data: blogData };
    }
  },

  async submitContact(payload: ContactSubmission): Promise<ApiResponse<{ message: string; id: string }>> {
    // Spam bot honeypot protection check
    if (payload.honeypot && payload.honeypot.trim().length > 0) {
      return { success: false, error: "Spam detection triggered." };
    }

    try {
      if (API_BASE_URL) {
        const res = await fetch(`${API_BASE_URL}/contact`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
        if (!res.ok) throw new Error("Failed to submit enquiry");
        const data = await res.json();
        return { success: true, data };
      }

      // Simulated network request
      await delay(600);
      const generatedId = `ENQ-${Date.now().toString().slice(-6)}`;
      
      // Store in session storage for demo persistence
      try {
        const existing = JSON.parse(sessionStorage.getItem("thememax_enquiries") || "[]");
        existing.push({ id: generatedId, timestamp: new Date().toISOString(), ...payload });
        sessionStorage.setItem("thememax_enquiries", JSON.stringify(existing));
      } catch {
        // Ignore storage errors in restricted contexts
      }

      return {
        success: true,
        data: {
          message: "Thank you for reaching out. A Thememax growth partner will review your project brief and respond within 24 hours.",
          id: generatedId
        }
      };
    } catch (err: unknown) {
      return {
        success: false,
        error: err instanceof Error ? err.message : "Unable to transmit project brief. Please retry."
      };
    }
  }
};
