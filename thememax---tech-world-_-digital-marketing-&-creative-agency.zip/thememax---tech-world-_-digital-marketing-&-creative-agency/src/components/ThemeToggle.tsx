import React from "react";
import { Sun, Moon } from "lucide-react";
import { useTheme } from "../hooks/useTheme";

export interface ThemeToggleProps {
  /** Optional extra Tailwind CSS classes */
  className?: string;
  /** Whether to show descriptive label text next to the icon */
  showLabel?: boolean;
  /** Visual variant: button icon or segmented pill */
  variant?: "icon" | "button" | "pill";
  /** Size variant */
  size?: "sm" | "md" | "lg";
}

/**
 * ThemeToggle
 * An accessible toggle component that persists the user's light/dark mode preference
 * in localStorage and toggles the 'dark' class on the HTML element via useTheme.
 */
export const ThemeToggle: React.FC<ThemeToggleProps> = ({
  className = "",
  showLabel = false,
  variant = "icon",
  size = "md"
}) => {
  const { theme, toggleTheme, isDark } = useTheme();

  const sizeClasses = {
    sm: "p-1.5 text-xs gap-1.5",
    md: "p-2.5 text-sm gap-2",
    lg: "p-3 text-base gap-2.5"
  };

  const iconSizes = {
    sm: 14,
    md: 16,
    lg: 20
  };

  const currentIconSize = iconSizes[size];

  if (variant === "pill") {
    return (
      <div
        className={`inline-flex items-center p-1 rounded-full bg-neutral-900/90 dark:bg-neutral-900 border border-neutral-800 text-neutral-400 ${className}`}
        role="group"
        aria-label="Theme mode switcher"
      >
        <button
          type="button"
          onClick={() => isDark && toggleTheme()}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium transition-all ${
            !isDark
              ? "bg-amber-500 text-white shadow-sm"
              : "hover:text-neutral-200"
          }`}
          aria-pressed={!isDark}
        >
          <Sun size={14} className={!isDark ? "animate-spin-slow" : ""} />
          <span>Light</span>
        </button>
        <button
          type="button"
          onClick={() => !isDark && toggleTheme()}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium transition-all ${
            isDark
              ? "bg-neutral-800 text-cyan-300 shadow-sm border border-cyan-500/20"
              : "hover:text-neutral-200"
          }`}
          aria-pressed={isDark}
        >
          <Moon size={14} />
          <span>Dark</span>
        </button>
      </div>
    );
  }

  return (
    <button
      type="button"
      onClick={toggleTheme}
      className={`relative inline-flex items-center justify-center rounded-xl transition-all duration-200 text-neutral-300 hover:text-white bg-neutral-900/50 hover:bg-neutral-800/80 border border-neutral-800/80 hover:border-neutral-700 active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-orange-500 ${sizeClasses[size]} ${className}`}
      aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
      title={isDark ? "Switch to light mode" : "Switch to dark mode"}
    >
      <span className="relative flex items-center justify-center">
        {isDark ? (
          <Sun
            size={currentIconSize}
            className="text-amber-400 transition-transform duration-300 hover:rotate-90"
          />
        ) : (
          <Moon
            size={currentIconSize}
            className="text-cyan-400 transition-transform duration-300 hover:-rotate-12"
          />
        )}
      </span>

      {showLabel && (
        <span className="font-medium select-none">
          {isDark ? "Light Mode" : "Dark Mode"}
        </span>
      )}
    </button>
  );
};
