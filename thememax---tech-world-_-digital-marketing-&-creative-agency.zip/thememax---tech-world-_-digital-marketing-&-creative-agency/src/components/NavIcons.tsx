import React from "react";

interface IconProps extends React.SVGProps<SVGSVGElement> {
  size?: number;
  className?: string;
}

// Custom Navigation Icon for Services: Layered modular tech stack with radiant orange core
export const ServicesNavIcon: React.FC<IconProps> = ({ size = 20, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    {/* Base foundation platform */}
    <path
      d="M3 17.5L12 21.5L21 17.5L12 13.5L3 17.5Z"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="opacity-70"
    />
    {/* Mid platform */}
    <path
      d="M3 12L12 16L21 12L12 8L3 12Z"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    {/* Top focused apex plate with Thememax orange accent */}
    <path
      d="M12 2.5L21 6.5L12 10.5L3 6.5L12 2.5Z"
      stroke="#FF5722"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    {/* Glowing tech node in center */}
    <circle cx="12" cy="6.5" r="1.5" fill="#00D2FF" />
  </svg>
);

// Custom Navigation Icon for Industries: Connected matrix with Thememax orange beacon
export const IndustriesNavIcon: React.FC<IconProps> = ({ size = 20, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    {/* Connected hexagon grid nodes */}
    <rect x="3" y="3" width="7" height="7" rx="2" stroke="currentColor" strokeWidth="1.5" />
    <rect x="14" y="3" width="7" height="7" rx="2" stroke="#FF5722" strokeWidth="1.8" />
    <rect x="3" y="14" width="7" height="7" rx="2" stroke="currentColor" strokeWidth="1.5" className="opacity-70" />
    <rect x="14" y="14" width="7" height="7" rx="2" stroke="currentColor" strokeWidth="1.5" />
    
    {/* Cyber linking vectors */}
    <path d="M10 6.5H14" stroke="#00D2FF" strokeWidth="1.5" strokeDasharray="2 1.5" />
    <path d="M6.5 10V14" stroke="currentColor" strokeWidth="1.5" className="opacity-50" />
    <path d="M17.5 10V14" stroke="#00D2FF" strokeWidth="1.5" />
    
    <circle cx="17.5" cy="6.5" r="1.5" fill="#FF5722" />
  </svg>
);

// Custom Navigation Icon for Work / Portfolio: Viewport frame with interlocking creative diagonal
export const WorkNavIcon: React.FC<IconProps> = ({ size = 20, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    {/* Studio monitor / showcase frame */}
    <rect x="2.5" y="3.5" width="19" height="14" rx="2.5" stroke="currentColor" strokeWidth="1.5" />
    {/* Intersecting dynamic diagonal inspired by the Thememax 'x' */}
    <path d="M6 13.5L10.5 8L14.5 12.5L18 8" stroke="#FF5722" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    {/* Ambient cyber sun / lens */}
    <circle cx="8" cy="7" r="1.5" fill="#00D2FF" />
    {/* Minimalist pedestal */}
    <path d="M9 20.5H15" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <path d="M12 17.5V20.5" stroke="currentColor" strokeWidth="1.5" />
  </svg>
);

// Custom Navigation Icon for Case Studies: Trajectory chart with verified milestone node
export const CaseStudiesNavIcon: React.FC<IconProps> = ({ size = 20, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    {/* Data axes */}
    <path d="M3 20.5H21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <path d="M3.5 3.5V20.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    {/* Ascending performance spline */}
    <path
      d="M4 16.5C7.5 15.5 9 11 12 10.5C15 10 16.5 6 20.5 4.5"
      stroke="#FF5722"
      strokeWidth="2"
      strokeLinecap="round"
    />
    {/* Peak verified impact node */}
    <circle cx="20.5" cy="4.5" r="2.5" fill="#00D2FF" stroke="#0A1128" strokeWidth="1" />
    {/* Ambient shadow bars */}
    <rect x="8" y="14" width="2" height="6.5" rx="1" fill="currentColor" opacity="0.3" />
    <rect x="13.5" y="11" width="2" height="9.5" rx="1" fill="currentColor" opacity="0.4" />
  </svg>
);

// Custom Navigation Icon for About: Thememax Tech World dual-ring cyber globe
export const AboutNavIcon: React.FC<IconProps> = ({ size = 20, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    {/* Outer boundary */}
    <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.5" />
    {/* Latitude ring */}
    <ellipse cx="12" cy="12" rx="9" ry="3.8" stroke="#00D2FF" strokeWidth="1.4" strokeDasharray="1.5 1.5" />
    {/* Longitude ring */}
    <ellipse cx="12" cy="12" rx="4" ry="9" stroke="currentColor" strokeWidth="1.4" opacity="0.6" />
    {/* Core Thememax spark */}
    <circle cx="12" cy="12" r="2" fill="#FF5722" />
  </svg>
);

// Custom Navigation Icon for Insights / Blog: Digital radiant quill & beacon wave
export const InsightsNavIcon: React.FC<IconProps> = ({ size = 20, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    {/* Clean editorial journal */}
    <path
      d="M4.5 4C4.5 3.17157 5.17157 2.5 6 2.5H16.5C17.3284 2.5 18 3.17157 18 4V19.5C18 20.6046 17.1046 21.5 16 21.5H6C4.89543 21.5 4 20.6046 4 19.5V4.5C4 4.22386 4.22386 4 4.5 4Z"
      stroke="currentColor"
      strokeWidth="1.5"
    />
    <path d="M8 7H14" stroke="#FF5722" strokeWidth="1.8" strokeLinecap="round" />
    <path d="M8 11H14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" opacity="0.6" />
    <path d="M8 15H12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" opacity="0.6" />
    {/* Glowing insight node */}
    <circle cx="18" cy="17" r="2.5" fill="#00D2FF" stroke="#FF5722" strokeWidth="1.2" />
  </svg>
);
