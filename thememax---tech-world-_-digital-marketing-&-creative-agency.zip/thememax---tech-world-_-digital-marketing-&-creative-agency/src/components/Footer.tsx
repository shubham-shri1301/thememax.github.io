import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight, Mail, Phone, MapPin, CheckCircle2 } from "lucide-react";
import { Logo } from "./Logo";

export const Footer: React.FC = () => {
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [newsletterStatus, setNewsletterStatus] = useState<"idle" | "submitting" | "success">("idle");

  const handleNewsletter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail || !newsletterEmail.includes("@")) return;
    setNewsletterStatus("submitting");
    setTimeout(() => {
      setNewsletterStatus("success");
      setNewsletterEmail("");
    }, 600);
  };

  return (
    <footer className="bg-neutral-950 text-neutral-300 border-t border-neutral-900 pt-20 pb-12 overflow-hidden relative">
      {/* Subtle background ambient mesh */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-orange-600/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-80 h-80 bg-red-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Top agency value callout & newsletter */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 pb-16 border-b border-neutral-900">
          <div className="lg:col-span-6 space-y-6">
            <Logo size="lg" />
            <p className="text-xl sm:text-2xl font-display font-medium text-white max-w-lg leading-snug">
              Ideas That Move Businesses Forward.
            </p>
            <p className="text-sm text-neutral-400 max-w-md leading-relaxed">
              We engineer complete digital growth systems combining strategic brand positioning, high-impact creative production, performance customer acquisition, and custom web technology.
            </p>

            {/* Direct contact indicators */}
            <div className="pt-2 flex flex-col sm:flex-row gap-4 sm:gap-8 text-xs font-mono text-neutral-400">
              <a
                href="mailto:hello@thememax.example"
                className="flex items-center gap-2 hover:text-orange-400 transition-colors"
              >
                <Mail className="w-4 h-4 text-orange-500" />
                <span>hello@thememax.example</span>
              </a>
              <a
                href="tel:+919876543210"
                className="flex items-center gap-2 hover:text-orange-400 transition-colors"
              >
                <Phone className="w-4 h-4 text-orange-500" />
                <span>+91 98765 43210</span>
              </a>
              <div className="flex items-center gap-2 text-neutral-500">
                <MapPin className="w-4 h-4 text-red-500" />
                <span>Tech World HQ · Global Operations</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 flex flex-col justify-center">
            <div className="bg-neutral-900/70 border border-neutral-800 p-6 sm:p-8 rounded-2xl">
              <h4 className="text-lg font-semibold text-white mb-2">Subscribe to The Growth Dispatch</h4>
              <p className="text-xs text-neutral-400 mb-5 leading-relaxed">
                Bi-weekly teardowns of high-converting creative playbooks, paid acquisition strategies, and emerging web technologies. Zero spam.
              </p>

              {newsletterStatus === "success" ? (
                <div className="flex items-center gap-2 text-emerald-400 text-sm py-2">
                  <CheckCircle2 className="w-5 h-5 shrink-0" />
                  <span>You are subscribed to The Growth Dispatch. Check your inbox shortly.</span>
                </div>
              ) : (
                <form onSubmit={handleNewsletter} className="flex flex-col sm:flex-row gap-3">
                  <input
                    type="email"
                    required
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    placeholder="Enter your executive email"
                    className="flex-1 bg-neutral-950 border border-neutral-800 rounded-lg px-4 py-3 text-sm text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-orange-500 transition-colors"
                  />
                  <button
                    type="submit"
                    disabled={newsletterStatus === "submitting"}
                    className="px-6 py-3 text-xs font-semibold uppercase tracking-wider text-white bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 rounded-lg transition-all active:scale-95 disabled:opacity-50 whitespace-nowrap"
                  >
                    {newsletterStatus === "submitting" ? "Subscribing..." : "Join Dispatch"}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>

        {/* 4 Multi-column directory */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 py-16 border-b border-neutral-900">
          {/* Col 1: Explore */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-widest text-white mb-4">
              Explore
            </h4>
            <ul className="space-y-2.5 text-sm text-neutral-400">
              <li>
                <Link to="/" className="hover:text-orange-400 transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-orange-400 transition-colors">
                  About Agency
                </Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-orange-400 transition-colors">
                  All Services
                </Link>
              </li>
              <li>
                <Link to="/work" className="hover:text-orange-400 transition-colors">
                  Selected Work
                </Link>
              </li>
              <li>
                <Link to="/case-studies" className="hover:text-orange-400 transition-colors">
                  Case Studies
                </Link>
              </li>
              <li>
                <Link to="/blog" className="hover:text-orange-400 transition-colors">
                  Ideas & Insights
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-orange-400 transition-colors">
                  Contact & Inquiries
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 2: Services */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-widest text-white mb-4">
              Capabilities
            </h4>
            <ul className="space-y-2.5 text-sm text-neutral-400">
              <li>
                <Link to="/services#digital-marketing" className="hover:text-orange-400 transition-colors">
                  Performance Marketing
                </Link>
              </li>
              <li>
                <Link to="/services#strategy-branding" className="hover:text-orange-400 transition-colors">
                  Brand & Visual Strategy
                </Link>
              </li>
              <li>
                <Link to="/services#digital-marketing" className="hover:text-orange-400 transition-colors">
                  Technical SEO Optimization
                </Link>
              </li>
              <li>
                <Link to="/services#social-media" className="hover:text-orange-400 transition-colors">
                  Social Media & Creator UGC
                </Link>
              </li>
              <li>
                <Link to="/services#creative-content" className="hover:text-orange-400 transition-colors">
                  Creative & Video Production
                </Link>
              </li>
              <li>
                <Link to="/services#web-technology" className="hover:text-orange-400 transition-colors">
                  Web & Headless Engineering
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 3: Industries */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-widest text-white mb-4">
              Industries
            </h4>
            <ul className="space-y-2.5 text-sm text-neutral-400">
              <li>
                <Link to="/industries#real-estate" className="hover:text-orange-400 transition-colors">
                  Real Estate & Development
                </Link>
              </li>
              <li>
                <Link to="/industries#automotive" className="hover:text-orange-400 transition-colors">
                  Automotive & Mobility
                </Link>
              </li>
              <li>
                <Link to="/industries#healthcare" className="hover:text-orange-400 transition-colors">
                  Healthcare & Telehealth
                </Link>
              </li>
              <li>
                <Link to="/industries#ecommerce" className="hover:text-orange-400 transition-colors">
                  E-Commerce & DTC Retail
                </Link>
              </li>
              <li>
                <Link to="/industries#finance" className="hover:text-orange-400 transition-colors">
                  Finance & Wealth Tech
                </Link>
              </li>
              <li>
                <Link to="/industries#technology" className="hover:text-orange-400 transition-colors">
                  B2B SaaS & Enterprise
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 4: Connect */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-widest text-white mb-4">
              Connect
            </h4>
            <ul className="space-y-2.5 text-sm text-neutral-400">
              <li>
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 hover:text-orange-400 transition-colors"
                >
                  <span>LinkedIn</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-neutral-600" />
                </a>
              </li>
              <li>
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 hover:text-orange-400 transition-colors"
                >
                  <span>Instagram</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-neutral-600" />
                </a>
              </li>
              <li>
                <a
                  href="https://youtube.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 hover:text-orange-400 transition-colors"
                >
                  <span>YouTube</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-neutral-600" />
                </a>
              </li>
              <li>
                <a
                  href="https://twitter.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 hover:text-orange-400 transition-colors"
                >
                  <span>Twitter / X</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-neutral-600" />
                </a>
              </li>
              <li>
                <a
                  href="https://facebook.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 hover:text-orange-400 transition-colors"
                >
                  <span>Facebook</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-neutral-600" />
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom copyright and legal notes */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-neutral-500">
          <div>
            &copy; 2026 Thememax - Tech World. All rights reserved.
          </div>
          <div className="flex items-center gap-6">
            <span className="hover:text-neutral-400 cursor-pointer transition-colors">Privacy Policy</span>
            <span className="hover:text-neutral-400 cursor-pointer transition-colors">Terms of Service</span>
            <span className="hover:text-neutral-400 cursor-pointer transition-colors">Cookie Preferences</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
