import React, { useState } from "react";
import { motion } from "motion/react";
import { TrendingUp, Zap, Sparkles, Activity, ShieldCheck } from "lucide-react";
import { useGalaxy } from "../context/GalaxyContext";

export const HeroVisual: React.FC = () => {
  const [isHovered, setIsHovered] = useState(false);
  const { triggerSupernova } = useGalaxy();

  const handleGlobeClick = (e: React.MouseEvent) => {
    triggerSupernova(e.clientX, e.clientY);
  };

  return (
    <div
      className="relative w-full aspect-[4/3] sm:aspect-square max-w-lg mx-auto flex items-center justify-center select-none"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Dynamic Background Glow - Thememax Orange + Cyan + Crimson */}
      <div className="absolute inset-0 bg-gradient-to-tr from-orange-600/25 via-purple-900/20 to-cyan-500/25 rounded-full blur-3xl animate-pulse-glow" />

      {/* Galactic Accretion Disk / Cosmic Orbit Ring */}
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 50, repeat: Infinity, ease: "linear" }}
        className="absolute w-80 h-80 sm:w-[26rem] sm:h-[26rem] rounded-full border border-orange-500/20 dark:border-orange-500/25 pointer-events-none"
        style={{
          boxShadow: "0 0 45px rgba(255, 87, 34, 0.12), inset 0 0 35px rgba(0, 210, 255, 0.08)"
        }}
      >
        {/* Orbiting Stardust nodes */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3.5 h-3.5 rounded-full bg-orange-500 shadow-lg shadow-orange-500/70" />
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-lg shadow-cyan-400/70" />
        <div className="absolute left-0 top-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-white shadow-md shadow-white" />
        <div className="absolute right-0 top-1/2 translate-x-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-violet-400 shadow-md shadow-violet-400" />
      </motion.div>

      {/* Counter-Rotating Cosmic Dust Ring */}
      <motion.div
        animate={{ rotate: -360 }}
        transition={{ duration: 35, repeat: Infinity, ease: "linear" }}
        className="absolute w-64 h-64 sm:w-80 sm:h-80 rounded-full border border-cyan-500/30 border-dashed pointer-events-none"
      >
        <div className="absolute top-1/4 right-0 translate-x-1/2 w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-md shadow-cyan-400" />
        <div className="absolute bottom-1/4 left-0 -translate-x-1/2 w-2 h-2 rounded-full bg-amber-400 shadow-md shadow-amber-400" />
      </motion.div>

      {/* Central 3D Tech World Globe Sphere (Direct homage to Thememax Logo & Galaxy Core) */}
      <div
        onClick={handleGlobeClick}
        role="button"
        tabIndex={0}
        aria-label="Ignite cosmic supernova pulse"
        className="relative z-10 w-44 h-44 sm:w-56 sm:h-56 rounded-full bg-gradient-to-br from-neutral-900 via-neutral-950 to-neutral-900 border border-neutral-700/60 shadow-2xl flex items-center justify-center overflow-hidden cursor-pointer hover:border-orange-500/70 transition-all duration-300 group hover:scale-[1.03] active:scale-95"
      >
        {/* Sphere shading & inner cosmic depth */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(255,87,34,0.4),transparent_60%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_75%,rgba(0,210,255,0.3),transparent_55%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(147,51,234,0.2),transparent_70%)]" />

        {/* Cyber Network Grid Lines inside Sphere - Rotating in Loop */}
        <motion.svg
          viewBox="0 0 100 100"
          animate={{ rotate: 360 }}
          transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
          style={{ transformOrigin: "50% 50%" }}
          className="absolute inset-0 w-full h-full opacity-65 group-hover:opacity-85 transition-opacity pointer-events-none origin-center"
        >
          <ellipse cx="50" cy="50" rx="46" ry="18" fill="none" stroke="#00D2FF" strokeWidth="0.8" strokeDasharray="2 2" />
          <ellipse cx="50" cy="50" rx="46" ry="32" fill="none" stroke="#00D2FF" strokeWidth="0.6" opacity="0.6" />
          <ellipse cx="50" cy="50" rx="18" ry="46" fill="none" stroke="#FF5722" strokeWidth="0.8" opacity="0.7" />
          <ellipse cx="50" cy="50" rx="32" ry="46" fill="none" stroke="#00D2FF" strokeWidth="0.6" opacity="0.5" />
          <line x1="4" y1="50" x2="96" y2="50" stroke="#00D2FF" strokeWidth="0.7" opacity="0.8" />
          <line x1="50" y1="4" x2="50" y2="96" stroke="#FF5722" strokeWidth="0.7" opacity="0.8" />
          {/* Constellation nodes */}
          <circle cx="32" cy="38" r="1.8" fill="#FFFFFF" />
          <circle cx="68" cy="42" r="1.8" fill="#FF5722" />
          <circle cx="50" cy="50" r="2.2" fill="#00D2FF" />
          <circle cx="44" cy="68" r="1.5" fill="#FFFFFF" />
          <circle cx="62" cy="60" r="1.6" fill="#00D2FF" />
        </motion.svg>

        {/* Center Tech World Agency Mark */}
        <div className="relative z-20 text-center pointer-events-none">
          <div className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center justify-center gap-1 font-display">
            <span className="text-orange-500">T</span>
            <span>M</span>
          </div>
          <span className="text-[9px] font-mono tracking-widest text-cyan-400 uppercase font-semibold">
            Tech World
          </span>
          <div className="text-[8px] font-mono text-orange-400/90 tracking-tighter mt-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
            ✦ TAP TO BURST
          </div>
        </div>
      </div>

      {/* Floating Card 1: ROAS Performance & Live Trajectory (Top Right) */}
      <motion.div
        animate={{
          y: isHovered ? -12 : [-4, 6, -4],
          x: isHovered ? 6 : 0
        }}
        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-2 sm:top-6 -right-2 sm:-right-6 z-20 bg-neutral-900/90 dark:bg-neutral-900/95 backdrop-blur-md border border-neutral-800 p-3 sm:p-4 rounded-xl shadow-xl shadow-black/40 w-44 sm:w-52"
      >
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-orange-500/20 text-orange-500 flex items-center justify-center">
              <TrendingUp className="w-3.5 h-3.5" />
            </div>
            <span className="text-xs font-semibold text-neutral-200">Meta & Google</span>
          </div>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/40 px-1.5 py-0.5 rounded">
            +312%
          </span>
        </div>
        <div className="text-lg sm:text-xl font-bold font-mono text-white tabular-nums">
          4.82x ROAS
        </div>
        <p className="text-[10px] text-neutral-400 mt-0.5">Continuous bidding calibration</p>
      </motion.div>

      {/* Floating Card 2: Headless Web Speed & Uptime (Bottom Left) */}
      <motion.div
        animate={{
          y: isHovered ? 10 : [6, -6, 6],
          x: isHovered ? -6 : 0
        }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
        className="absolute -bottom-2 sm:bottom-4 -left-2 sm:-left-8 z-20 bg-neutral-900/90 dark:bg-neutral-900/95 backdrop-blur-md border border-neutral-800 p-3 sm:p-4 rounded-xl shadow-xl shadow-black/40 w-44 sm:w-52"
      >
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <Zap className="w-3.5 h-3.5" />
            </div>
            <span className="text-xs font-semibold text-neutral-200">Core Web Vitals</span>
          </div>
          <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-800/40 px-1.5 py-0.5 rounded">
            Grade A
          </span>
        </div>
        <div className="text-lg sm:text-xl font-bold font-mono text-white tabular-nums flex items-baseline gap-1">
          <span>0.58s</span>
          <span className="text-xs text-neutral-400 font-normal">FCP</span>
        </div>
        <p className="text-[10px] text-neutral-400 mt-0.5">Edge-accelerated storefront</p>
      </motion.div>

      {/* Floating Badge 3: Verified Client Growth Pipeline (Bottom Right) */}
      <motion.div
        animate={{
          scale: isHovered ? 1.05 : [1, 1.03, 1]
        }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        className="hidden sm:flex absolute -bottom-4 right-8 z-20 items-center gap-2.5 bg-neutral-950/90 border border-neutral-800 px-3.5 py-2 rounded-full shadow-lg"
      >
        <div className="w-2 h-2 rounded-full bg-orange-500 animate-ping" />
        <span className="text-xs font-mono text-neutral-300">
          ₹154 Cr Verified Pipeline
        </span>
      </motion.div>
    </div>
  );
};
