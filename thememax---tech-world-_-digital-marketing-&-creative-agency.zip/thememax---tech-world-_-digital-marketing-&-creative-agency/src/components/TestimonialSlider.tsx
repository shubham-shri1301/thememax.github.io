import React, { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, Quote, Building } from "lucide-react";
import { testimonialsData } from "../data/testimonialsData";

export const TestimonialSlider: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const prev = () => {
    setCurrentIndex((prev) => (prev === 0 ? testimonialsData.length - 1 : prev - 1));
  };

  const next = () => {
    setCurrentIndex((prev) => (prev === testimonialsData.length - 1 ? 0 : prev + 1));
  };

  useEffect(() => {
    if (isPaused) return;
    const interval = setInterval(next, 7000);
    return () => clearInterval(interval);
  }, [isPaused]);

  const current = testimonialsData[currentIndex];

  return (
    <section className="py-24 bg-neutral-950/90 relative overflow-hidden border-t border-neutral-900">
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 right-10 w-96 h-96 bg-red-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-4">
          <div>
            <span className="text-xs font-semibold uppercase tracking-widest text-orange-500">
              Client Perspectives (Demonstration)
            </span>
            <h2 className="text-3xl sm:text-5xl font-extrabold font-display text-white tracking-tight mt-2">
              Endorsed by leaders scaling markets.
            </h2>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center gap-3">
            <button
              onClick={prev}
              className="p-3 rounded-full bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-neutral-300 hover:text-white transition-colors"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <span className="text-xs font-mono text-neutral-500 tabular-nums">
              0{currentIndex + 1} / 0{testimonialsData.length}
            </span>
            <button
              onClick={next}
              className="p-3 rounded-full bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-neutral-300 hover:text-white transition-colors"
              aria-label="Next testimonial"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Testimonial Active Display */}
        <div
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
          className="relative bg-neutral-900/70 border border-neutral-800 rounded-3xl p-8 sm:p-14 transition-all duration-300"
        >
          <Quote className="w-12 h-12 text-orange-500/30 mb-6" />

          <blockquote className="text-xl sm:text-3xl font-display font-medium text-white leading-relaxed">
            &ldquo;{current.quote}&rdquo;
          </blockquote>

          <div className="mt-10 pt-8 border-t border-neutral-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-orange-500 to-red-600 flex items-center justify-center text-white font-bold font-display shadow-md">
                {current.name.split(" ").map((n) => n[0]).join("")}
              </div>
              <div>
                <div className="text-base font-semibold text-white">{current.name}</div>
                <div className="text-xs text-neutral-400">
                  {current.role} · <span className="text-orange-400">{current.company}</span>
                </div>
              </div>
            </div>

            {/* Verifiable outcome block */}
            <div className="sm:text-right">
              <div className="text-[11px] font-mono uppercase tracking-widest text-neutral-500">
                Documented Outcome
              </div>
              <div className="text-sm font-semibold font-mono text-emerald-400 mt-0.5">
                {current.outcome}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
