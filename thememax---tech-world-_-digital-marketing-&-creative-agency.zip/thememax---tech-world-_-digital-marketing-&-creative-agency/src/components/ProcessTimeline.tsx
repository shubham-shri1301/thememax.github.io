import React, { useState } from "react";
import { ArrowRight, CheckCircle2 } from "lucide-react";

interface Step {
  num: string;
  title: string;
  description: string;
  deliverables: string[];
}

const steps: Step[] = [
  {
    num: "01",
    title: "Discover & Audit",
    description: "Deep diagnostic analysis of current funnel economics, competitive positioning, tech stack bottlenecks, and untapped market demand.",
    deliverables: ["Funnel Drop-Off Audit", "Competitor Matrix", "Attribution Diagnostics"]
  },
  {
    num: "02",
    title: "Strategize & Model",
    description: "Formulate the integrated customer acquisition playbook: channel allocation, target unit economics, messaging pillars, and technical architecture.",
    deliverables: ["Growth Model Roadmap", "Creative Testing Matrix", "Budget Allocation Plan"]
  },
  {
    num: "03",
    title: "Create & Engineer",
    description: "High-craft production of high-converting visual assets, narrative video hooks, kinetic design systems, and headless digital experiences.",
    deliverables: ["Ad Creative Suites", "Sub-Second Web Pages", "CRM Attribution Flows"]
  },
  {
    num: "04",
    title: "Launch & Calibrate",
    description: "Precision media deployment across paid channels with automated bid calibration, conversions API tracking, and real-time alerts.",
    deliverables: ["Full-Funnel Pixel Launch", "Audience Cohort Seeding", "Live Telemetry Dashboard"]
  },
  {
    num: "05",
    title: "Analyze & Optimize",
    description: "Relentless multivariate split testing across ad creatives, landing page hooks, and checkout steps to continuously compress customer acquisition costs.",
    deliverables: ["Weekly Creative Teardowns", "Conversion Rate Split Tests", "Channel Margin Reports"]
  },
  {
    num: "06",
    title: "Scale & Dominate",
    description: "Systematic budget expansion, geographic market entry, and omnichannel organic synergy for sustainable long-term enterprise dominance.",
    deliverables: ["International Scaling Sprints", "Retention & LTV Engines", "Executive Growth Review"]
  }
];

export const ProcessTimeline: React.FC = () => {
  const [activeStep, setActiveStep] = useState(0);

  return (
    <section className="py-24 bg-neutral-950 relative overflow-hidden border-t border-neutral-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-16">
          <span className="text-xs font-semibold uppercase tracking-widest text-orange-500">
            Methodology
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold font-display text-white tracking-tight mt-2">
            How We Move Businesses Forward
          </h2>
          <p className="mt-4 text-sm sm:text-base text-neutral-400 leading-relaxed">
            Our disciplined six-stage execution framework bridges the gap between bold creative ideas and mathematically predictable growth.
          </p>
        </div>

        {/* 6 Step Grid with Connecting Line & Interaction */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 relative">
          {steps.map((step, idx) => {
            const isSelected = activeStep === idx;
            return (
              <div
                key={step.num}
                onClick={() => setActiveStep(idx)}
                className={`p-8 rounded-2xl border transition-all duration-300 cursor-pointer relative ${
                  isSelected
                    ? "bg-neutral-900 border-orange-500 shadow-xl shadow-orange-500/10"
                    : "bg-neutral-900/50 border-neutral-800 hover:border-neutral-700"
                }`}
              >
                <div className="flex items-center justify-between mb-4">
                  <span className={`text-sm font-mono font-bold ${isSelected ? "text-orange-500" : "text-neutral-500"}`}>
                    Phase {step.num}
                  </span>
                  <span className={`w-2.5 h-2.5 rounded-full ${isSelected ? "bg-orange-500 animate-pulse" : "bg-neutral-800"}`} />
                </div>

                <h3 className="text-xl font-bold font-display text-white mb-2">
                  {step.title}
                </h3>

                <p className="text-xs text-neutral-400 leading-relaxed mb-6">
                  {step.description}
                </p>

                <div className="pt-4 border-t border-neutral-800/80 space-y-2">
                  <div className="text-[10px] font-mono uppercase tracking-widest text-neutral-500">
                    Key Outputs
                  </div>
                  {step.deliverables.map((del, dIdx) => (
                    <div key={dIdx} className="flex items-center gap-2 text-xs text-neutral-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-orange-500/80 shrink-0" />
                      <span>{del}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
