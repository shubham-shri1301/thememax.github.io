import React from "react";
import { BarChart3, Database, Cpu, Bot, Search, Globe, Code, Target, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

interface TechPillar {
  icon: React.ElementType;
  name: string;
  tagline: string;
  detail: string;
  color: string;
}

const techPillars: TechPillar[] = [
  { icon: BarChart3, name: "Analytics & Attribution", tagline: "Server-side event streaming", detail: "Multi-touch attribution models capturing the non-linear buyer journey with zero signal loss.", color: "#FF5722" },
  { icon: Database, name: "CRM & Pipeline Automation", tagline: "HubSpot & Salesforce integrations", detail: "Instant webhook routing that connects paid inquiries with sales representatives in under 5 minutes.", color: "#DC2626" },
  { icon: Bot, name: "AI & Generative Engines", tagline: "Predictive bidding & creative testing", detail: "Accelerated creative variation generation and semantic prompt engineering for high-converting ads.", color: "#00D2FF" },
  { icon: Search, name: "Search Entity Architecture", tagline: "Knowledge graph & schema mastery", detail: "Deep semantic structuring that positions your enterprise as the canonical answer in search engines.", color: "#FF5722" },
  { icon: Target, name: "Precision Ad Networks", tagline: "Google Ads & Meta Conversions API", detail: "Custom bidding algorithms and lookalike models calibrated for high lifetime value customer cohorts.", color: "#DC2626" },
  { icon: Code, name: "Headless Web Engineering", tagline: "React, Vite, Edge computing", detail: "Sub-second digital flagships engineered with modern component architectures and zero bloat.", color: "#00D2FF" },
  { icon: Cpu, name: "Marketing Automation", tagline: "Klaviyo, Customer.io, Braze", detail: "Behavioral event-triggered email and SMS sequences that systematically nurture customer lifetime value.", color: "#FF5722" },
  { icon: Globe, name: "Conversion Rate Optimization", tagline: "Multivariate behavioral testing", detail: "Heatmapping, click-tracking, and rapid split tests that systematically compress friction points.", color: "#00D2FF" }
];

export const TechStackSection: React.FC = () => {
  return (
    <section className="py-24 bg-neutral-950 relative overflow-hidden border-t border-neutral-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-3xl mb-16">
          <span className="text-xs font-semibold uppercase tracking-widest text-orange-500">
            Technology Infrastructure
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold font-display text-white tracking-tight mt-2 leading-tight">
            Creative thinking. Digital technology. Measurable performance.
          </h2>
          <p className="mt-4 text-sm sm:text-base text-neutral-400 leading-relaxed">
            We are not just a design shop or a media buyer. Thememax operates as a technical growth partner, deploying integrated cloud systems and measurement architectures to power your commercial growth.
          </p>
        </div>

        {/* Dynamic 8-Pillar Tech Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {techPillars.map((pillar, idx) => {
            const IconComponent = pillar.icon;
            return (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 transition-all duration-300 group flex flex-col justify-between"
              >
                <div>
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center mb-5 transition-transform group-hover:scale-105"
                    style={{ backgroundColor: `${pillar.color}15`, color: pillar.color }}
                  >
                    <IconComponent className="w-6 h-6" />
                  </div>
                  <div className="text-[11px] font-mono uppercase tracking-wider text-orange-400 mb-1">
                    {pillar.tagline}
                  </div>
                  <h3 className="text-lg font-bold font-display text-white group-hover:text-orange-400 transition-colors">
                    {pillar.name}
                  </h3>
                  <p className="mt-2.5 text-xs text-neutral-400 leading-relaxed">
                    {pillar.detail}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Integration Callout */}
        <div className="mt-12 p-8 rounded-2xl bg-gradient-to-r from-neutral-900 to-neutral-950 border border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div>
            <div className="text-base font-bold text-white">
              Need a modern measurement & acquisition audit?
            </div>
            <p className="text-xs text-neutral-400 mt-1">
              We diagnose tracking discrepancies, attribution gaps, and conversion bottlenecks across your tech stack.
            </p>
          </div>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs font-semibold uppercase tracking-wider transition-colors shrink-0 shadow-md shadow-orange-500/20"
          >
            <span>Request Tech Audit</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    </section>
  );
};
