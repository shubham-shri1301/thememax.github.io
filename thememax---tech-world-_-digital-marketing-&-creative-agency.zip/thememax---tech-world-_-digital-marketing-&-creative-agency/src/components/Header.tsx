import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "motion/react";
import { Search, Sun, Moon, Menu, X, ArrowRight, Sparkles } from "lucide-react";
import { Logo } from "./Logo";
import {
  ServicesNavIcon,
  IndustriesNavIcon,
  WorkNavIcon,
  CaseStudiesNavIcon,
  AboutNavIcon,
  InsightsNavIcon
} from "./NavIcons";
import { GlobalSearch } from "./GlobalSearch";
import { ThemeToggle } from "./ThemeToggle";
import { useGalaxy } from "../context/GalaxyContext";

export const Header: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const { triggerSupernova } = useGalaxy();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  const navLinks = [
    { name: "Services", path: "/services", icon: ServicesNavIcon },
    { name: "Industries", path: "/industries", icon: IndustriesNavIcon },
    { name: "Work", path: "/work", icon: WorkNavIcon },
    { name: "Case Studies", path: "/case-studies", icon: CaseStudiesNavIcon },
    { name: "About", path: "/about", icon: AboutNavIcon },
    { name: "Insights", path: "/blog", icon: InsightsNavIcon }
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          scrolled
            ? "bg-white/90 dark:bg-neutral-950/90 backdrop-blur-md border-b border-neutral-200 dark:border-neutral-800/80 shadow-lg py-3.5"
            : "bg-transparent py-5"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-4">
            {/* Zone 1: Brand Wordmark (Single text/logo element) */}
            <div className="shrink-0 flex items-center">
              <Logo size="md" />
            </div>

            {/* Zone 2: Navigation Links with Custom Icons */}
            <nav className="hidden lg:flex items-center gap-1 xl:gap-2 text-sm font-medium">
              {navLinks.map((item) => {
                const isActive = location.pathname === item.path;
                const IconComponent = item.icon;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`relative flex items-center gap-2 px-3.5 py-2 rounded-lg transition-colors group ${
                      isActive
                        ? "text-orange-500 font-semibold"
                        : "text-neutral-700 dark:text-neutral-300 hover:text-neutral-950 dark:hover:text-white"
                    }`}
                  >
                    <IconComponent
                      size={18}
                      className={`transition-transform duration-200 group-hover:scale-110 ${
                        isActive ? "text-orange-500" : "text-neutral-500 dark:text-neutral-400 group-hover:text-orange-500"
                      }`}
                    />
                    <span className="whitespace-nowrap">{item.name}</span>
                    {isActive && (
                      <motion.div
                        layoutId="activeNavIndicator"
                        className="absolute bottom-0 left-3.5 right-3.5 h-0.5 bg-gradient-to-r from-orange-500 to-red-600 rounded-full"
                        transition={{ type: "spring", stiffness: 380, damping: 30 }}
                      />
                    )}
                  </Link>
                );
              })}
            </nav>

            {/* Zone 3: Interactive Controls & Primary Action CTA */}
            <div className="flex items-center gap-2 sm:gap-3 shrink-0">
              {/* Global Search trigger */}
              <button
                onClick={() => setSearchOpen(true)}
                className="p-2.5 rounded-lg text-neutral-600 dark:text-neutral-300 hover:text-neutral-950 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800/60 transition-colors flex items-center gap-2"
                aria-label="Open search dialog"
                title="Search (Esc)"
              >
                <Search className="w-4 h-4 text-orange-400" />
                <span className="hidden xl:inline text-xs text-neutral-500 dark:text-neutral-400">Search</span>
              </button>

              {/* Quick Cosmic Supernova Trigger */}
              <button
                type="button"
                onClick={(e) => triggerSupernova(e.clientX, e.clientY)}
                className="p-2.5 rounded-lg text-neutral-600 dark:text-neutral-300 hover:text-cyan-400 dark:hover:text-cyan-300 hover:bg-neutral-100 dark:hover:bg-neutral-800/60 transition-colors flex items-center gap-1.5 active:scale-95 group"
                aria-label="Ignite cosmic stardust pulse"
                title="Ignite Cosmic Stardust Pulse"
              >
                <Sparkles className="w-4 h-4 text-cyan-400 group-hover:rotate-45 transition-transform" />
              </button>

              {/* Theme Switcher Toggle Component */}
              <ThemeToggle size="md" />

              {/* Primary Action Button */}
              <Link
                to="/contact"
                className="hidden sm:inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-gradient-to-r from-orange-500 via-red-600 to-orange-600 hover:from-orange-600 hover:to-red-700 rounded-lg shadow-md shadow-orange-500/20 hover:shadow-orange-500/35 transition-all duration-200 active:scale-95 whitespace-nowrap"
              >
                <span>Start a Project</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>

              {/* Mobile Hamburger toggle */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2.5 rounded-lg text-neutral-300 hover:text-white hover:bg-neutral-800/60 transition-colors"
                aria-label="Toggle navigation menu"
                aria-expanded={mobileMenuOpen}
              >
                {mobileMenuOpen ? <X className="w-6 h-6 text-orange-500" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Slide-out Menu Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-50 lg:hidden bg-black/80 backdrop-blur-lg flex flex-col justify-between"
          >
            {/* Top Bar inside mobile menu */}
            <div className="flex items-center justify-between px-6 py-5 border-b border-neutral-800">
              <Logo size="md" />
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="p-2 rounded-lg text-neutral-300 hover:text-white hover:bg-neutral-800"
                aria-label="Close menu"
              >
                <X className="w-6 h-6 text-orange-500" />
              </button>
            </div>

            {/* Navigation list */}
            <div className="flex-1 overflow-y-auto px-6 py-8 space-y-4">
              <div className="text-xs font-semibold uppercase tracking-wider text-neutral-500 px-3">
                Navigation
              </div>
              <div className="space-y-1">
                {navLinks.map((item) => {
                  const Icon = item.icon;
                  const isActive = location.pathname === item.path;
                  return (
                    <Link
                      key={item.path}
                      to={item.path}
                      onClick={() => setMobileMenuOpen(false)}
                      className={`flex items-center justify-between p-3.5 rounded-xl transition-all ${
                        isActive
                          ? "bg-neutral-900 border border-orange-500/40 text-orange-400 font-semibold"
                          : "text-neutral-200 hover:bg-neutral-900/60 hover:text-white"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Icon size={20} className={isActive ? "text-orange-500" : "text-neutral-400"} />
                        <span className="text-base">{item.name}</span>
                      </div>
                      <ArrowRight className="w-4 h-4 text-neutral-500" />
                    </Link>
                  );
                })}
              </div>

              {/* Search button in mobile drawer */}
              <div className="pt-2">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    setSearchOpen(true);
                  }}
                  className="w-full flex items-center justify-between p-3.5 rounded-xl bg-neutral-900/80 border border-neutral-800 text-neutral-300"
                >
                  <div className="flex items-center gap-3">
                    <Search className="w-5 h-5 text-orange-500" />
                    <span className="text-sm">Search Thememax...</span>
                  </div>
                  <span className="text-xs font-mono text-neutral-500">Search</span>
                </button>
              </div>
            </div>

            {/* Bottom Actions inside mobile drawer */}
            <div className="p-6 border-t border-neutral-800 bg-neutral-950/90 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs text-neutral-400">Interface Theme</span>
                <ThemeToggle variant="pill" size="sm" />
              </div>
              <Link
                to="/contact"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full flex items-center justify-center gap-2 py-3.5 text-sm font-semibold uppercase tracking-wider text-white bg-gradient-to-r from-orange-500 via-red-600 to-orange-600 rounded-xl shadow-lg shadow-orange-500/25"
              >
                <span>Start a Project</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Global Search Modal */}
      <GlobalSearch isOpen={searchOpen} onClose={() => setSearchOpen(false)} />
    </>
  );
};
