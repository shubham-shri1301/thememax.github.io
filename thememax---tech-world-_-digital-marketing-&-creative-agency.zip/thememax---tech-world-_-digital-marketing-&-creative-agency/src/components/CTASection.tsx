import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight, MessageSquareCode, Sparkles } from "lucide-react";
import { FadeUp } from "./FadeUp";

export const CTASection: React.FC = () => {
  return (
    <section className="py-28 bg-neutral-950 relative overflow-hidden border-t border-neutral-900">
      {/* Dynamic ambient gradient glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-4xl h-96 bg-gradient-to-r from-orange-600/20 via-red-600/20 to-cyan-500/15 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <FadeUp>
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-neutral-900/90 border border-neutral-800 text-xs font-mono uppercase tracking-widest text-orange-400 mb-6">
            <Sparkles className="w-3.5 h-3.5 text-orange-500" />
            <span>Scale Your Digital Footprint</span>
          </div>

          <h2 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold font-display text-white tracking-tight leading-[1.08] text-balance">
            Have a business that deserves more attention?
          </h2>

          <p className="mt-6 text-lg sm:text-xl text-neutral-300 max-w-2xl mx-auto leading-relaxed text-balance">
            Let&apos;s turn your next idea into something people remember, talk about, and buy from.
          </p>

          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/contact"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-4 text-xs font-semibold uppercase tracking-wider text-white bg-gradient-to-r from-orange-500 via-red-600 to-orange-600 hover:from-orange-600 hover:to-red-700 rounded-xl shadow-xl shadow-orange-500/25 hover:shadow-orange-500/40 transition-all duration-200 active:scale-95"
            >
              <span>Start a Project</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
            <a
              href="mailto:hello@thememax.example"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-4 text-xs font-semibold uppercase tracking-wider text-neutral-200 hover:text-white bg-neutral-900 hover:bg-neutral-850 border border-neutral-800 rounded-xl transition-all"
            >
              <MessageSquareCode className="w-4 h-4 text-neutral-400" />
              <span>Talk to Our Team</span>
            </a>
          </div>

          <div className="mt-8 text-xs font-mono text-neutral-400">
            Average diagnostic turnaround: &lt; 24 hours · Non-disclosure agreements respected
          </div>
        </FadeUp>
      </div>
    </section>
  );
};
