import React, { useState, useEffect, useRef } from "react";
import { useInView } from "framer-motion";

interface CounterItemProps {
  target: number;
  suffix?: string;
  label: string;
  detail: string;
}

const CounterItem: React.FC<CounterItemProps> = ({ target, suffix = "+", label, detail }) => {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!isInView) return;
    let start = 0;
    const duration = 1600;
    const steps = 40;
    const stepTime = duration / steps;
    const increment = target / steps;

    const timer = setInterval(() => {
      start += increment;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, stepTime);

    return () => clearInterval(timer);
  }, [isInView, target]);

  return (
    <div ref={ref} className="p-6 sm:p-8 bg-neutral-900/60 border border-neutral-800 rounded-2xl relative overflow-hidden group hover:border-neutral-700 transition-colors">
      <div className="text-3xl sm:text-5xl font-extrabold font-display text-white tracking-tight tabular-nums flex items-baseline">
        <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 via-red-500 to-orange-500">
          {count}
        </span>
        <span className="text-orange-500 ml-1 text-2xl sm:text-4xl">{suffix}</span>
      </div>
      <div className="mt-3 text-base font-semibold text-neutral-200">
        {label}
      </div>
      <p className="mt-1 text-xs text-neutral-400 leading-relaxed">
        {detail}
      </p>
    </div>
  );
};

export const StatsSection: React.FC = () => {
  return (
    <section className="py-24 bg-neutral-950 relative overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-orange-600/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-3xl mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-orange-500 mb-3">
            <span>Verified Track Record</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold font-display text-white tracking-tight leading-tight">
            Built for measurable, sustainable growth.
          </h2>
          <p className="mt-4 text-base text-neutral-400 leading-relaxed">
            Every metric below represents verified campaigns, customer journeys, and scalable revenue engines deployed for ambitious companies across global markets.
          </p>
        </div>

        {/* 5-Column Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 sm:gap-6">
          <CounterItem
            target={10}
            suffix="+"
            label="Years Experience"
            detail="Pioneering digital growth since the first algorithmic shifts."
          />
          <CounterItem
            target={150}
            suffix="+"
            label="Brands Scaled"
            detail="From venture-backed startups to enterprise market leaders."
          />
          <CounterItem
            target={300}
            suffix="+"
            label="Campaigns Launched"
            detail="Multi-channel paid media, creative drops, and web platforms."
          />
          <CounterItem
            target={12}
            suffix="+"
            label="Core Industries"
            detail="Deep domain fluency in real estate, automotive, SaaS, & DTC."
          />
          <CounterItem
            target={98}
            suffix="%"
            label="Retention Rate"
            detail="Long-term agency partnerships built on verifiable ROI."
          />
        </div>
      </div>
    </section>
  );
};
