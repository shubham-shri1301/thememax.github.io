import React from "react";
import { Link } from "react-router-dom";
import { useTheme } from "../hooks/useTheme";

interface LogoProps {
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
  iconOnly?: boolean;
  withLink?: boolean;
}

export const Logo: React.FC<LogoProps> = ({
  size = "md",
  className = "",
  iconOnly = false,
  withLink = true
}) => {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  // Responsive height configurations
  const heightClasses = {
    sm: "h-7 sm:h-8",
    md: "h-9 sm:h-10",
    lg: "h-12 sm:h-14",
    xl: "h-16 sm:h-20"
  };

  const primaryTextColor = isDark ? "#F8FAFC" : "#0F172A";
  const xNeutralStroke = isDark ? "#FFFFFF" : "#0F172A";

  const content = iconOnly ? (
    <div className={`relative flex items-center justify-center aspect-square ${heightClasses[size]} ${className}`}>
      <svg
        viewBox="0 0 64 64"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-sm select-none"
        aria-label="Thememax Tech World Icon"
      >
        <defs>
          <linearGradient id="iconTGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FF6B35" />
            <stop offset="100%" stopColor="#FF5722" />
          </linearGradient>
          <radialGradient id="iconGlobeGlow" cx="40%" cy="40%" r="60%">
            <stop offset="0%" stopColor="#00E5FF" stopOpacity="0.95" />
            <stop offset="50%" stopColor="#0284C7" stopOpacity="0.85" />
            <stop offset="100%" stopColor="#03152B" stopOpacity="1" />
          </radialGradient>
        </defs>

        {/* Squircle Background container */}
        <rect
          width="64"
          height="64"
          rx="16"
          fill={isDark ? "#0A0E17" : "#FFFFFF"}
          stroke={isDark ? "#1E293B" : "#E2E8F0"}
          strokeWidth="1.5"
          className="shadow-inner"
        />

        {/* Signature Orange 'T' */}
        <rect x="13" y="14" width="38" height="11" rx="4.5" fill="url(#iconTGrad)" />
        <rect x="26.5" y="21" width="11" height="27" rx="4.5" fill="url(#iconTGrad)" />
        <path d="M 37.5 25 L 37.5 32 L 44 25 Z" fill="#D84315" opacity="0.65" />

        {/* Glowing Cyber World Globe Badge in bottom-right */}
        <g transform="translate(45, 45)">
          <circle cx="0" cy="0" r="11" fill="url(#iconGlobeGlow)" stroke="#00D2FF" strokeWidth="1.4" />
          <ellipse cx="0" cy="0" rx="10" ry="4" fill="none" stroke="#38BDF8" strokeWidth="0.9" strokeDasharray="1.5 1.5" opacity="0.85" />
          <ellipse cx="0" cy="0" rx="4" ry="10" fill="none" stroke="#38BDF8" strokeWidth="0.9" opacity="0.85" />
          <line x1="-10" y1="0" x2="10" y2="0" stroke="#38BDF8" strokeWidth="0.8" opacity="0.8" />
          <circle cx="-3.5" cy="-3.5" r="1.5" fill="#FFFFFF" />
          <circle cx="4" cy="3" r="1.4" fill="#FF5722" />
          <circle cx="0" cy="0" r="1.6" fill="#00F0FF" />
        </g>
      </svg>
    </div>
  ) : (
    <div className={`flex items-center select-none ${className}`}>
      <svg
        viewBox="0 0 570 148"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`${heightClasses[size]} w-auto drop-shadow-sm transition-transform duration-200 group-hover:scale-[1.01]`}
        aria-label="Thememax - Tech World"
      >
        <defs>
          {/* Gradient for T */}
          <linearGradient id="tLinearGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FF6B35" />
            <stop offset="100%" stopColor="#FF5722" />
          </linearGradient>

          {/* Glowing cyber globe gradient */}
          <radialGradient id="cyberGlobeGlow" cx="35%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#00E5FF" stopOpacity="0.95" />
            <stop offset="50%" stopColor="#0284C7" stopOpacity="0.85" />
            <stop offset="100%" stopColor="#021226" stopOpacity="1" />
          </radialGradient>

          {/* Drop shadow for overlapping orange X bar */}
          <filter id="xOverlapShadow" x="-30%" y="-30%" width="160%" height="160%">
            <feDropShadow dx="-1" dy="2" stdDeviation="2" floodColor="#000000" floodOpacity="0.4" />
          </filter>

          {/* General soft brand shadow */}
          <filter id="brandSubtleShadow" x="-5%" y="-5%" width="110%" height="110%">
            <feDropShadow dx="0" dy="1.5" stdDeviation="1.5" floodColor="#000000" floodOpacity="0.1" />
          </filter>
        </defs>

        {/* =========================================================
            PRIMARY WORDMARK: Thememax
            Spelled out clearly: T - h - e - m - e - m - a - x
            ========================================================= */}
        <g id="thememax-wordmark" filter="url(#brandSubtleShadow)">
          {/* 1. 'T': Vibrant Orange with rounded terminals & 3D origami fold */}
          <g id="letter-T">
            {/* Horizontal crossbar */}
            <rect x="20" y="32" width="60" height="18" rx="6" fill="url(#tLinearGrad)" />
            {/* Vertical stem */}
            <rect x="41" y="44" width="18" height="48" rx="6" fill="url(#tLinearGrad)" />
            {/* Inner corner fold shadow */}
            <path d="M 59 48 L 59 61 L 71 48 Z" fill="#D84315" opacity="0.65" />
          </g>

          {/* 2. 'h': Deep Burgundy Crimson */}
          <path
            id="letter-h"
            d="M 92 36 C 92 33.8 93.8 32 96 32 C 98.2 32 100 33.8 100 36 L 100 58 C 104 51.5 111 48 120 48 C 133 48 141 56 141 70 L 141 88 C 141 90.2 139.2 92 137 92 C 134.8 92 133 90.2 133 88 L 133 71 C 133 62 127.5 56.5 118 56.5 C 109 56.5 100 63 100 73 L 100 88 C 100 90.2 98.2 92 96 92 C 93.8 92 92 90.2 92 88 Z"
            fill="#880E17"
          />

          {/* 3. 'e' (1st): Deep Crimson */}
          <path
            id="letter-e-1"
            d="M 152 70 C 152 57.5 161.5 48 176 48 C 190.5 48 199.5 57 199.5 71.5 C 199.5 73.2 198.2 74.5 196.5 74.5 L 161.5 74.5 C 162.5 82.5 168 86.5 176 86.5 C 181.5 86.5 186.2 84 189 80.5 C 190.5 78.5 193.5 78.5 195.2 80.2 C 197 82 196.5 85 194.5 87.2 C 189.8 91.5 183.5 93.5 175.5 93.5 C 161 93.5 152 83.5 152 70 Z M 189.5 66 C 188.5 59.5 183.5 55.5 176 55.5 C 168.5 55.5 163 59.5 162 66 Z"
            fill="#9C101D"
          />

          {/* 4. 'm' (1st): Crimson Ruby */}
          <path
            id="letter-m-1"
            d="M 208 53 C 208 50.8 209.8 49 212 49 C 214.2 49 216 50.8 216 53 L 216 57 C 219.5 51.5 226 48 234 48 C 241 48 246.5 51.2 249.5 56.5 C 253.5 51.2 260 48 268 48 C 280 48 287 56 287 70 L 287 88 C 287 90.2 285.2 92 283 92 C 280.8 92 279 90.2 279 88 L 279 71 C 279 62 274 56.5 266.5 56.5 C 259 56.5 253 62.5 253 72 L 253 88 C 253 90.2 251.2 92 249 92 C 246.8 92 245 90.2 245 88 L 245 71 C 245 62 240 56.5 232.5 56.5 C 225 56.5 219 62.5 219 72 L 219 88 C 219 90.2 217.2 92 215 92 C 212.8 92 208 90.2 208 88 Z"
            fill="#AF1522"
          />

          {/* 5. 'e' (2nd): Ruby-Red */}
          <path
            id="letter-e-2"
            d="M 296 70 C 296 57.5 305.5 48 320 48 C 334.5 48 343.5 57 343.5 71.5 C 343.5 73.2 342.2 74.5 340.5 74.5 L 305.5 74.5 C 306.5 82.5 312 86.5 320 86.5 C 325.5 86.5 330.2 84 333 80.5 C 334.5 78.5 337.5 78.5 339.2 80.2 C 341 82 340.5 85 338.5 87.2 C 333.8 91.5 327.5 93.5 319.5 93.5 C 305 93.5 296 83.5 296 70 Z M 333.5 66 C 332.5 59.5 327.5 55.5 320 55.5 C 312.5 55.5 307 59.5 306 66 Z"
            fill="#C51A28"
          />

          {/* 6. 'm' (2nd): Vivid Scarlet Red (Explicit 2nd 'm' for Thememax!) */}
          <path
            id="letter-m-2"
            d="M 352 53 C 352 50.8 353.8 49 356 49 C 358.2 49 360 50.8 360 53 L 360 57 C 363.5 51.5 370 48 378 48 C 385 48 390.5 51.2 393.5 56.5 C 397.5 51.2 404 48 412 48 C 424 48 431 56 431 70 L 431 88 C 431 90.2 429.2 92 427 92 C 424.8 92 423 90.2 423 88 L 423 71 C 423 62 418 56.5 410.5 56.5 C 403 56.5 397 62.5 397 72 L 397 88 C 397 90.2 395.2 92 393 92 C 390.8 92 389 90.2 389 88 L 389 71 C 389 62 384 56.5 376.5 56.5 C 369 56.5 363 62.5 363 72 L 363 88 C 363 90.2 361.2 92 359 92 C 356.8 92 352 90.2 352 88 Z"
            fill="#D3202C"
          />

          {/* 7. 'a': Vivid Scarlet-Red */}
          <path
            id="letter-a"
            d="M 470 53 C 470 50.8 471.8 49 474 49 C 476.2 49 478 50.8 478 53 L 478 88 C 478 90.2 476.2 92 474 92 C 472.5 92 471 91.2 470.2 90 C 466.5 92.5 461.5 93.8 456 93.8 C 444 93.8 436 85.5 436 73 C 436 60.5 444.5 52.5 458 52.5 C 462.5 52.5 466.8 53.6 470 55.6 L 470 53 Z M 470 65 C 466.5 62.8 462.5 61.5 458.5 61.5 C 450.5 61.5 446 66.5 446 73 C 446 79.5 450.5 84.5 458 84.5 C 463.5 84.5 468 81 470 75.5 L 470 65 Z"
            fill="#EA2B39"
          />

          {/* 8. 'x': Signature Interlocking Dual-Tone Emblem */}
          <g id="letter-x">
            {/* Neutral Bar (Top-Left to Bottom-Right): White in dark mode, Charcoal in light mode */}
            <line
              x1="495"
              y1="36"
              x2="535"
              y2="88"
              stroke={xNeutralStroke}
              strokeWidth="15"
              strokeLinecap="round"
              className="text-slate-900 dark:text-white"
            />
            {/* Vibrant Orange Crossing Bar (Bottom-Left to Top-Right) with 3D depth */}
            <line
              x1="495"
              y1="88"
              x2="535"
              y2="36"
              stroke="#FF5722"
              strokeWidth="15"
              strokeLinecap="round"
              filter="url(#xOverlapShadow)"
            />
          </g>
        </g>

        {/* =========================================================
            SUB-LOCKUP: — TECH W 🌐 RLD —
            Centered symmetrically under Thememax (center x = 282)
            ========================================================= */}
        <g id="sub-lockup">
          {/* Left Orange Dash Accent */}
          <rect x="85" y="124" width="50" height="3.5" rx="1.75" fill="#FF5722" />

          {/* TECH */}
          <text
            x="150"
            y="130"
            fontFamily="'Plus Jakarta Sans', system-ui, -apple-system, sans-serif"
            fontWeight="800"
            fontSize="14"
            letterSpacing="5"
            fill={primaryTextColor}
            className="fill-slate-900 dark:fill-slate-100"
          >
            TECH
          </text>

          {/* W */}
          <text
            x="245"
            y="130"
            fontFamily="'Plus Jakarta Sans', system-ui, -apple-system, sans-serif"
            fontWeight="800"
            fontSize="14"
            letterSpacing="3"
            fill={primaryTextColor}
            className="fill-slate-900 dark:fill-slate-100"
          >
            W
          </text>

          {/* 🌐 Glowing Cyber World Globe replacing 'O' in WORLD */}
          <g transform="translate(282, 126)">
            {/* Sphere Body */}
            <circle cx="0" cy="0" r="9.5" fill="url(#cyberGlobeGlow)" stroke="#00D2FF" strokeWidth="1.2" />
            {/* Latitude rings */}
            <ellipse cx="0" cy="0" rx="8.5" ry="3.5" fill="none" stroke="#38BDF8" strokeWidth="0.9" strokeDasharray="1.5 1.2" opacity="0.85" />
            <line x1="-9" y1="0" x2="9" y2="0" stroke="#38BDF8" strokeWidth="0.8" opacity="0.8" />
            {/* Longitude ring */}
            <ellipse cx="0" cy="0" rx="3.5" ry="8.5" fill="none" stroke="#38BDF8" strokeWidth="0.9" opacity="0.85" />
            {/* Active network nexus nodes */}
            <circle cx="-3" cy="-3.5" r="1.3" fill="#FFFFFF" />
            <circle cx="3.5" cy="3" r="1.2" fill="#FF5722" />
            <circle cx="0" cy="0" r="1.5" fill="#00F0FF" />
          </g>

          {/* RLD */}
          <text
            x="302"
            y="130"
            fontFamily="'Plus Jakarta Sans', system-ui, -apple-system, sans-serif"
            fontWeight="800"
            fontSize="14"
            letterSpacing="5"
            fill={primaryTextColor}
            className="fill-slate-900 dark:fill-slate-100"
          >
            RLD
          </text>

          {/* Right Orange Dash Accent */}
          <rect x="428" y="124" width="50" height="3.5" rx="1.75" fill="#FF5722" />
        </g>
      </svg>
    </div>
  );

  if (withLink) {
    return (
      <Link
        to="/"
        className="inline-flex items-center focus:outline-none focus-visible:ring-2 focus-visible:ring-orange-500 rounded-lg group"
        aria-label="Thememax Tech World Home"
      >
        {content}
      </Link>
    );
  }

  return content;
};
