import React, { useEffect, useRef } from "react";
import { useGalaxy } from "../context/GalaxyContext";
import { useTheme } from "../hooks/useTheme";

interface Star {
  // Galaxy coordinates (spiral)
  arm: number;
  dist: number;
  angle: number;
  baseAngle: number;
  orbitSpeed: number;
  size: number;
  color: string;
  alpha: number;
  baseAlpha: number;
  twinkleSpeed: number;
  twinklePhase: number;
  depth: number; // 0 (far) to 1 (near)
}

interface FieldStar {
  x: number;
  y: number;
  z: number;
  size: number;
  color: string;
  alpha: number;
  baseAlpha: number;
  twinkleSpeed: number;
  twinklePhase: number;
}

interface Meteor {
  x: number;
  y: number;
  vx: number;
  vy: number;
  length: number;
  speed: number;
  alpha: number;
  color: string;
  life: number;
  maxLife: number;
}

interface SupernovaParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  decay: number;
}

interface Shockwave {
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  alpha: number;
  color: string;
}

export const GalaxyBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const { enabled, mode, intensity, isWarping, supernovaEvents, clearSupernovaEvent } = useGalaxy();
  const { isDark } = useTheme();

  // Internal persistent simulation refs
  const mouseRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0, isActive: false });
  const galaxyStarsRef = useRef<Star[]>([]);
  const fieldStarsRef = useRef<FieldStar[]>([]);
  const meteorsRef = useRef<Meteor[]>([]);
  const particlesRef = useRef<SupernovaParticle[]>([]);
  const shockwavesRef = useRef<Shockwave[]>([]);
  const rotationRef = useRef<number>(0);
  const warpFactorRef = useRef<number>(0);
  const animFrameRef = useRef<number>(0);
  const lastMeteorSpawnRef = useRef<number>(Date.now());

  // Spectral star palette matching Thememax identity
  const darkPalette = [
    "#FFFFFF", // Pure white stellar core
    "#E0F2FE", // Bright cyan-white
    "#38BDF8", // Cyan starlight
    "#00D2FF", // Signature Thememax Electric Cyan
    "#FFA726", // Solar Amber
    "#FF5722", // Signature Thememax Solar Orange
    "#F43F5E", // Rose Nebula
    "#A855F7"  // Cosmic Violet
  ];

  const lightPalette = [
    "#0284C7", // Cyan Deep
    "#0369A1", // Ocean
    "#D97706", // Amber
    "#EA580C", // Orange
    "#7C3AED", // Violet
    "#64748B"  // Slate
  ];

  // Initialize stars once on canvas resize or setup
  const initStars = (width: number, height: number) => {
    const starCount = intensity === "vivid" ? 750 : intensity === "subtle" ? 350 : 520;
    const fieldCount = intensity === "vivid" ? 220 : intensity === "subtle" ? 90 : 150;
    const colors = isDark ? darkPalette : lightPalette;

    // Spiral galaxy stars
    const stars: Star[] = [];
    const arms = 4;
    const maxRadius = Math.max(width, height) * 0.75;

    for (let i = 0; i < starCount; i++) {
      const arm = i % arms;
      // Exponential cluster towards galaxy nucleus
      const rRatio = Math.pow(Math.random(), 1.8);
      const dist = 30 + rRatio * maxRadius;
      
      // Logarithmic spiral angle + dispersion
      const spiralSpread = (Math.random() - 0.5) * (0.35 + (dist / maxRadius) * 0.45);
      const curl = 2.4;
      const angle = (arm * (2 * Math.PI / arms)) + Math.log(dist + 1) * curl + spiralSpread;

      // Differential orbital speed (Keplerian rotation curve)
      const orbitSpeed = (0.0003 + 0.0012 / Math.sqrt(dist + 50)) * (isDark ? 1 : 0.85);

      const color = colors[Math.floor(Math.random() * colors.length)];
      const baseAlpha = isDark ? 0.35 + Math.random() * 0.65 : 0.2 + Math.random() * 0.45;

      stars.push({
        arm,
        dist,
        angle,
        baseAngle: angle,
        orbitSpeed,
        size: Math.random() < 0.85 ? Math.random() * 1.5 + 0.7 : Math.random() * 2.8 + 1.6,
        color,
        alpha: baseAlpha,
        baseAlpha,
        twinkleSpeed: 0.02 + Math.random() * 0.05,
        twinklePhase: Math.random() * Math.PI * 2,
        depth: Math.random()
      });
    }
    galaxyStarsRef.current = stars;

    // Background deep field stars
    const fieldStars: FieldStar[] = [];
    for (let i = 0; i < fieldCount; i++) {
      fieldStars.push({
        x: Math.random() * width,
        y: Math.random() * height,
        z: Math.random() * 1000,
        size: Math.random() * 1.6 + 0.5,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: isDark ? 0.25 + Math.random() * 0.6 : 0.15 + Math.random() * 0.35,
        baseAlpha: isDark ? 0.25 + Math.random() * 0.6 : 0.15 + Math.random() * 0.35,
        twinkleSpeed: 0.015 + Math.random() * 0.04,
        twinklePhase: Math.random() * Math.PI * 2
      });
    }
    fieldStarsRef.current = fieldStars;
  };

  // Trigger supernova particle burst
  const spawnSupernova = (x: number, y: number) => {
    const particleCount = 70;
    const colors = ["#FFFFFF", "#00D2FF", "#FF5722", "#FFA726", "#F43F5E", "#C084FC"];
    const newParticles: SupernovaParticle[] = [];

    for (let i = 0; i < particleCount; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 6 + 2;
      newParticles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: Math.random() * 3 + 1.2,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: 1,
        decay: Math.random() * 0.015 + 0.008
      });
    }
    particlesRef.current.push(...newParticles);

    // Shockwave expansion ring
    shockwavesRef.current.push({
      x,
      y,
      radius: 4,
      maxRadius: Math.min(window.innerWidth, window.innerHeight) * 0.45,
      alpha: 0.9,
      color: "#00D2FF"
    });
    shockwavesRef.current.push({
      x,
      y,
      radius: 2,
      maxRadius: Math.min(window.innerWidth, window.innerHeight) * 0.35,
      alpha: 0.8,
      color: "#FF5722"
    });
  };

  // Handle external supernova requests from context
  useEffect(() => {
    if (supernovaEvents.length > 0) {
      const latest = supernovaEvents[supernovaEvents.length - 1];
      spawnSupernova(latest.x, latest.y);
      clearSupernovaEvent(latest.id);
    }
  }, [supernovaEvents, clearSupernovaEvent]);

  // Main canvas animation loop & event setup
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) return;

    let animationRunning = true;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    // Handle high DPI displays for crisp stars
    const handleResize = () => {
      if (!canvas) return;
      width = window.innerWidth;
      height = window.innerHeight;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      ctx.resetTransform?.();
      ctx.scale(dpr, dpr);
      initStars(width, height);
    };

    handleResize();
    window.addEventListener("resize", handleResize);

    // Mouse movement parallax & gravitational pull
    const handlePointerMove = (e: PointerEvent) => {
      mouseRef.current.targetX = e.clientX;
      mouseRef.current.targetY = e.clientY;
      mouseRef.current.isActive = true;
    };

    // Click on window triggers an interactive stardust burst
    const handleClick = (e: MouseEvent) => {
      // Avoid intercepting clicks on buttons, inputs, links, or modals
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.closest("button") ||
          target.closest("a") ||
          target.closest("input") ||
          target.closest("textarea") ||
          target.closest("[role='dialog']") ||
          target.closest("[role='menu']"))
      ) {
        return;
      }
      spawnSupernova(e.clientX, e.clientY);
    };

    window.addEventListener("pointermove", handlePointerMove, { passive: true });
    window.addEventListener("click", handleClick);

    // Periodic shooting stars / meteors
    const spawnMeteor = () => {
      const angle = (Math.PI / 4) + (Math.random() - 0.5) * 0.4; // Diagonal downwards
      const startX = Math.random() * width * 0.9;
      const startY = Math.random() * height * 0.35;
      const speed = Math.random() * 12 + 14;
      const length = Math.random() * 140 + 80;
      const colors = ["#FFFFFF", "#00D2FF", "#FFA726", "#38BDF8"];
      
      meteorsRef.current.push({
        x: startX,
        y: startY,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        length,
        speed,
        alpha: 1,
        color: colors[Math.floor(Math.random() * colors.length)],
        life: 0,
        maxLife: Math.floor(Math.random() * 40 + 35)
      });
    };

    // Nebula cloud time variables
    let nebulaTime = 0;

    // Check reduced motion preference
    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    // Tick frame render function
    const render = () => {
      if (!animationRunning) return;

      // Handle visibilitychange pause
      if (document.hidden) {
        animFrameRef.current = requestAnimationFrame(render);
        return;
      }

      // Smooth mouse tracking
      const mouse = mouseRef.current;
      mouse.x += (mouse.targetX - mouse.x) * 0.05;
      mouse.y += (mouse.targetY - mouse.y) * 0.05;

      // Warp factor acceleration
      const targetWarp = isWarping ? 1 : 0;
      warpFactorRef.current += (targetWarp - warpFactorRef.current) * 0.08;
      const warp = warpFactorRef.current;

      // Global rotation step
      const rotStep = (0.0008 + warp * 0.009) * (prefersReducedMotion ? 0 : 1);
      rotationRef.current += rotStep;
      nebulaTime += 0.004;

      // Clear canvas with subtle trail in warp mode, or full clear
      ctx.clearRect(0, 0, width, height);

      // Galaxy Center Position (positioned slightly above true center to complement page hero)
      const centerX = width * 0.5 + (mouse.x - width * 0.5) * 0.035;
      const centerY = height * 0.42 + (mouse.y - height * 0.42) * 0.035;

      // -------------------------------------------------------------
      // 1. COSMIC NEBULA GLOWS (Soft deep-space gas clouds)
      // -------------------------------------------------------------
      if (mode !== "minimal") {
        ctx.save();
        ctx.globalCompositeOperation = isDark ? "screen" : "multiply";

        // Nebula 1: Thememax Electric Cyan (Top Right)
        const neb1X = centerX + Math.cos(nebulaTime * 0.7) * 90 + 120;
        const neb1Y = centerY + Math.sin(nebulaTime * 0.5) * 70 - 90;
        const neb1Rad = Math.min(width, height) * (0.38 + Math.sin(nebulaTime) * 0.04);
        const grad1 = ctx.createRadialGradient(neb1X, neb1Y, 0, neb1X, neb1Y, neb1Rad);
        const neb1Alpha = isDark ? (intensity === "vivid" ? 0.22 : 0.14) : 0.05;
        grad1.addColorStop(0, `rgba(0, 210, 255, ${neb1Alpha})`);
        grad1.addColorStop(0.45, `rgba(2, 132, 199, ${neb1Alpha * 0.5})`);
        grad1.addColorStop(1, "rgba(2, 18, 38, 0)");
        ctx.fillStyle = grad1;
        ctx.beginPath();
        ctx.arc(neb1X, neb1Y, neb1Rad, 0, Math.PI * 2);
        ctx.fill();

        // Nebula 2: Thememax Solar Orange / Crimson (Bottom Left)
        const neb2X = centerX - Math.sin(nebulaTime * 0.6) * 110 - 130;
        const neb2Y = centerY + Math.cos(nebulaTime * 0.8) * 80 + 110;
        const neb2Rad = Math.min(width, height) * (0.42 + Math.cos(nebulaTime * 0.8) * 0.04);
        const grad2 = ctx.createRadialGradient(neb2X, neb2Y, 0, neb2X, neb2Y, neb2Rad);
        const neb2Alpha = isDark ? (intensity === "vivid" ? 0.18 : 0.11) : 0.04;
        grad2.addColorStop(0, `rgba(255, 87, 34, ${neb2Alpha})`);
        grad2.addColorStop(0.4, `rgba(185, 28, 28, ${neb2Alpha * 0.6})`);
        grad2.addColorStop(1, "rgba(20, 5, 10, 0)");
        ctx.fillStyle = grad2;
        ctx.beginPath();
        ctx.arc(neb2X, neb2Y, neb2Rad, 0, Math.PI * 2);
        ctx.fill();

        // Nebula 3: Galactic Core Cosmic Halo (Center)
        const coreHaloRad = Math.min(width, height) * (0.28 + Math.sin(nebulaTime * 1.2) * 0.02);
        const gradCore = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, coreHaloRad);
        const coreAlpha = isDark ? (intensity === "vivid" ? 0.28 : 0.18) : 0.06;
        gradCore.addColorStop(0, `rgba(255, 138, 76, ${coreAlpha * 1.3})`);
        gradCore.addColorStop(0.25, `rgba(0, 210, 255, ${coreAlpha * 0.7})`);
        gradCore.addColorStop(0.65, `rgba(99, 102, 241, ${coreAlpha * 0.4})`);
        gradCore.addColorStop(1, "rgba(5, 8, 20, 0)");
        ctx.fillStyle = gradCore;
        ctx.beginPath();
        ctx.arc(centerX, centerY, coreHaloRad, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();
      }

      // -------------------------------------------------------------
      // 2. BACKGROUND DEEP FIELD STARS (Twinkling space depth)
      // -------------------------------------------------------------
      const fieldStars = fieldStarsRef.current;
      for (let i = 0; i < fieldStars.length; i++) {
        const star = fieldStars[i];
        if (!prefersReducedMotion) {
          star.twinklePhase += star.twinkleSpeed;
        }
        const twinkle = 0.5 + 0.5 * Math.sin(star.twinklePhase);
        const currentAlpha = star.baseAlpha * twinkle;

        // Subtle 3D parallax on mouse move
        const px = star.x + (mouse.x - width * 0.5) * (0.015 * (1 - star.z / 1000));
        const py = star.y + (mouse.y - height * 0.5) * (0.015 * (1 - star.z / 1000));

        ctx.fillStyle = star.color;
        ctx.globalAlpha = Math.max(0.1, Math.min(1, currentAlpha));
        ctx.beginPath();
        ctx.arc(px, py, star.size, 0, Math.PI * 2);
        ctx.fill();
      }

      // -------------------------------------------------------------
      // 3. SPIRAL GALAXY STARS & NUCLEUS
      // -------------------------------------------------------------
      if (mode === "spiral" || mode === "nebula") {
        const stars = galaxyStarsRef.current;
        const tilt = 0.54; // Perspective foreshortening for elliptical 3D tilt

        for (let i = 0; i < stars.length; i++) {
          const star = stars[i];

          // Advance orbital angle
          if (!prefersReducedMotion) {
            star.angle += star.orbitSpeed + warp * 0.015;
            star.twinklePhase += star.twinkleSpeed;
          }

          // Compute elliptical 3D coordinates relative to galaxy center
          const totalAngle = star.angle + rotationRef.current;
          const cosA = Math.cos(totalAngle);
          const sinA = Math.sin(totalAngle);

          // Star base position with inclination
          const rx = star.dist * cosA;
          const ry = star.dist * sinA * tilt;

          // Mouse gravity interaction (slight deflection when mouse gets close)
          let starX = centerX + rx;
          let starY = centerY + ry;

          if (mouse.isActive && !isWarping) {
            const dx = starX - mouse.x;
            const dy = starY - mouse.y;
            const distToMouse = Math.sqrt(dx * dx + dy * dy);
            if (distToMouse < 180 && distToMouse > 5) {
              const force = (1 - distToMouse / 180) * 12;
              starX += (dx / distToMouse) * force;
              starY += (dy / distToMouse) * force;
            }
          }

          // Warp streak rendering vs normal point rendering
          const twinkle = 0.6 + 0.4 * Math.sin(star.twinklePhase);
          const alpha = star.baseAlpha * twinkle * (isDark ? 1 : 0.7);

          if (warp > 0.05) {
            // Radiant lightspeed streak extending away from core
            const streakLen = (star.dist * 0.12 + 10) * warp;
            const normX = rx / (star.dist || 1);
            const normY = ry / (star.dist || 1);

            ctx.strokeStyle = star.color;
            ctx.lineWidth = star.size * (1 + warp * 0.5);
            ctx.globalAlpha = Math.min(1, alpha * (1 + warp * 0.5));
            ctx.beginPath();
            ctx.moveTo(starX, starY);
            ctx.lineTo(starX - normX * streakLen, starY - normY * streakLen);
            ctx.stroke();
          } else {
            // Standard luminous star point
            ctx.fillStyle = star.color;
            ctx.globalAlpha = Math.min(1, Math.max(0.05, alpha));
            ctx.beginPath();
            ctx.arc(starX, starY, star.size, 0, Math.PI * 2);
            ctx.fill();

            // Occasional bright star cross-flare
            if (star.size > 2.8 && isDark && twinkle > 0.85) {
              ctx.strokeStyle = star.color;
              ctx.lineWidth = 0.6;
              ctx.globalAlpha = alpha * 0.4;
              ctx.beginPath();
              ctx.moveTo(starX - 4, starY);
              ctx.lineTo(starX + 4, starY);
              ctx.moveTo(starX, starY - 4);
              ctx.lineTo(starX, starY + 4);
              ctx.stroke();
            }
          }
        }

        // Luminous Galactic Core (Center Nucleus)
        const coreRad = (14 + Math.sin(nebulaTime * 2) * 2) * (1 + warp * 0.8);
        const nucleusGrad = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, coreRad * 2.5);
        nucleusGrad.addColorStop(0, "#FFFFFF");
        nucleusGrad.addColorStop(0.2, isDark ? "#FF8A4C" : "#0284C7");
        nucleusGrad.addColorStop(0.5, isDark ? "#00D2FF" : "#38BDF8");
        nucleusGrad.addColorStop(1, "rgba(0, 210, 255, 0)");

        ctx.fillStyle = nucleusGrad;
        ctx.globalAlpha = isDark ? 0.9 : 0.4;
        ctx.beginPath();
        ctx.arc(centerX, centerY, coreRad * 2.5, 0, Math.PI * 2);
        ctx.fill();
      }

      // -------------------------------------------------------------
      // 4. PERIODIC METEORS & SHOOTING STARS
      // -------------------------------------------------------------
      const now = Date.now();
      if (!prefersReducedMotion && now - lastMeteorSpawnRef.current > (Math.random() * 4500 + 3500)) {
        spawnMeteor();
        lastMeteorSpawnRef.current = now;
      }

      const meteors = meteorsRef.current;
      for (let i = meteors.length - 1; i >= 0; i--) {
        const m = meteors[i];
        m.x += m.vx;
        m.y += m.vy;
        m.life++;

        const progress = m.life / m.maxLife;
        const currentAlpha = (1 - progress) * (isDark ? 0.95 : 0.55);

        // Meteor trail gradient
        const trailStartX = m.x - (m.vx / m.speed) * m.length;
        const trailStartY = m.y - (m.vy / m.speed) * m.length;

        const meteorGrad = ctx.createLinearGradient(trailStartX, trailStartY, m.x, m.y);
        meteorGrad.addColorStop(0, "rgba(255, 255, 255, 0)");
        meteorGrad.addColorStop(0.7, m.color);
        meteorGrad.addColorStop(1, "#FFFFFF");

        ctx.strokeStyle = meteorGrad;
        ctx.lineWidth = 1.8;
        ctx.globalAlpha = Math.max(0, currentAlpha);
        ctx.beginPath();
        ctx.moveTo(trailStartX, trailStartY);
        ctx.lineTo(m.x, m.y);
        ctx.stroke();

        // Meteor head spark
        ctx.fillStyle = "#FFFFFF";
        ctx.beginPath();
        ctx.arc(m.x, m.y, 1.8, 0, Math.PI * 2);
        ctx.fill();

        if (m.life >= m.maxLife) {
          meteors.splice(i, 1);
        }
      }

      // -------------------------------------------------------------
      // 5. SUPERNOVA BURSTS & SHOCKWAVES
      // -------------------------------------------------------------
      const shockwaves = shockwavesRef.current;
      for (let i = shockwaves.length - 1; i >= 0; i--) {
        const sw = shockwaves[i];
        sw.radius += 5.5;
        sw.alpha *= 0.95;

        ctx.strokeStyle = sw.color;
        ctx.lineWidth = 2.2;
        ctx.globalAlpha = Math.max(0, sw.alpha);
        ctx.beginPath();
        ctx.arc(sw.x, sw.y, sw.radius, 0, Math.PI * 2);
        ctx.stroke();

        if (sw.radius >= sw.maxRadius || sw.alpha <= 0.02) {
          shockwaves.splice(i, 1);
        }
      }

      const particles = particlesRef.current;
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.vx *= 0.97;
        p.vy *= 0.97;
        p.alpha -= p.decay;

        ctx.fillStyle = p.color;
        ctx.globalAlpha = Math.max(0, p.alpha);
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();

        if (p.alpha <= 0.02) {
          particles.splice(i, 1);
        }
      }

      // Reset global alpha
      ctx.globalAlpha = 1;

      // Next frame
      animFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      animationRunning = false;
      cancelAnimationFrame(animFrameRef.current);
      window.removeEventListener("resize", handleResize);
      window.removeEventListener("pointermove", handlePointerMove);
      window.removeEventListener("click", handleClick);
    };
  }, [enabled, mode, intensity, isDark, isWarping]);

  if (!enabled) {
    return null;
  }

  return (
    <div
      aria-hidden="true"
      className="fixed inset-0 pointer-events-none z-0 overflow-hidden select-none"
    >
      <canvas
        ref={canvasRef}
        className="w-full h-full block"
        style={{
          // Hardware accelerated compositing
          transform: "translate3d(0, 0, 0)",
          willChange: "transform"
        }}
      />
    </div>
  );
};
