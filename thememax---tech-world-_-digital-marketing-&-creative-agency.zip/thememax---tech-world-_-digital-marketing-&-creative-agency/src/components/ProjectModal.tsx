import React, { useEffect } from "react";
import { X, ArrowRight, CheckCircle2, ExternalLink } from "lucide-react";
import { Project } from "../data/portfolioData";
import { Link } from "react-router-dom";

interface ProjectModalProps {
  project: Project | null;
  onClose: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    if (project) {
      document.body.style.overflow = "hidden";
      window.addEventListener("keydown", handleKeyDown);
    }
    return () => {
      document.body.style.overflow = "unset";
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [project, onClose]);

  if (!project) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={project.title}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-3xl max-h-[90vh] bg-neutral-900 border border-neutral-800 rounded-3xl overflow-y-auto shadow-2xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="relative p-6 sm:p-8 bg-gradient-to-b from-neutral-800/60 to-neutral-900 border-b border-neutral-800">
          <button
            onClick={onClose}
            className="absolute top-6 right-6 p-2 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-colors"
            aria-label="Close project modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3 text-xs font-mono uppercase tracking-widest text-orange-400 mb-2">
            <span>{project.client}</span>
            <span>·</span>
            <span>{project.industry}</span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-extrabold font-display text-white tracking-tight pr-10">
            {project.title}
          </h3>

          <p className="mt-3 text-sm text-neutral-300 leading-relaxed">
            {project.summary}
          </p>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 space-y-8 flex-1">
          {/* Key Metrics Grid */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-3">
              Verified Impact Metrics (Demo)
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {project.metrics.map((m, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-neutral-950/80 border border-neutral-800">
                  <div className="text-2xl font-bold font-mono text-orange-500 tabular-nums">
                    {m.value}
                  </div>
                  <div className="text-xs text-neutral-400 mt-1">{m.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Narrative Details */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-3">
              Project Architecture & Execution
            </h4>
            <p className="text-sm text-neutral-300 leading-relaxed">
              {project.fullDescription}
            </p>
          </div>

          {/* Deliverables */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-3">
              Key Deliverables
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {project.deliverables.map((item, idx) => (
                <div key={idx} className="flex items-center gap-2.5 text-xs text-neutral-300 bg-neutral-950/40 p-2.5 rounded-lg border border-neutral-800/60">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Tech Stack */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-3">
              Technology & Platform Stack
            </h4>
            <div className="flex flex-wrap gap-2">
              {project.techStack.map((tech, idx) => (
                <span key={idx} className="text-xs font-mono px-3 py-1 rounded-md bg-neutral-800 text-neutral-300 border border-neutral-700">
                  {tech}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-6 bg-neutral-950 border-t border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-neutral-500">
            Interested in comparable outcomes for your industry?
          </div>
          <Link
            to="/contact"
            onClick={onClose}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-orange-500 to-red-600 text-white text-xs font-semibold uppercase tracking-wider shadow-md hover:from-orange-600 hover:to-red-700 transition-all"
          >
            <span>Start a Similar Project</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    </div>
  );
};
