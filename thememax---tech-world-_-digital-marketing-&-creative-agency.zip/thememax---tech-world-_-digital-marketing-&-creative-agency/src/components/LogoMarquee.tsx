import React from "react";
import { clientLogos } from "../data/testimonialsData";

export const LogoMarquee: React.FC = () => {
  // Duplicate for seamless infinite loop
  const duplicatedLogos = [...clientLogos, ...clientLogos, ...clientLogos];

  return (
    <section className="py-12 border-y border-neutral-800/80 bg-neutral-950/60 overflow-hidden relative">
      <div className="max-w-7xl mx-auto px-4 mb-6 text-center">
        <p className="text-xs font-semibold uppercase tracking-widest text-neutral-400">
          Trusted by ambitious high-growth brands
        </p>
      </div>

      {/* Marquee Wrapper with soft edge gradients */}
      <div className="relative w-full overflow-hidden mask-gradient-x">
        {/* Left edge shadow fade */}
        <div className="absolute left-0 top-0 bottom-0 w-24 bg-gradient-to-r from-neutral-950 to-transparent z-10 pointer-events-none" />
        {/* Right edge shadow fade */}
        <div className="absolute right-0 top-0 bottom-0 w-24 bg-gradient-to-l from-neutral-950 to-transparent z-10 pointer-events-none" />

        <div className="animate-marquee flex items-center gap-12 sm:gap-20 py-2">
          {duplicatedLogos.map((client, index) => (
            <div
              key={`${client.name}-${index}`}
              className="group shrink-0 flex items-center gap-3 cursor-default opacity-60 hover:opacity-100 transition-opacity duration-300"
            >
              <div className="text-lg sm:text-2xl font-bold font-display tracking-wider text-neutral-300 group-hover:text-white transition-colors flex items-center gap-2">
                <span className="text-orange-500 opacity-80 group-hover:opacity-100 text-sm font-normal">
                  {client.mark.split(" ")[0]}
                </span>
                <span>{client.name}</span>
              </div>
              <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-500 px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 hidden sm:inline-block">
                {client.sector}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
