import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { featuredServicesList } from "../data/servicesData";

export const FeaturedServices: React.FC = () => {
  return (
    <section className="py-24 bg-neutral-950/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-2xl">
            <span className="text-xs font-semibold uppercase tracking-widest text-orange-500">
              Core Capabilities
            </span>
            <h2 className="text-3xl sm:text-5xl font-extrabold font-display text-white tracking-tight mt-2">
              Engineered for impact at every funnel stage.
            </h2>
            <p className="mt-4 text-neutral-400 text-sm sm:text-base leading-relaxed">
              We merge brand desire with algorithmic discipline. Explore our four marquee service disciplines designed to turn market attention into tangible enterprise value.
            </p>
          </div>
          <Link
            to="/services"
            className="inline-flex items-center gap-2 text-sm font-semibold text-orange-500 hover:text-orange-400 transition-colors group shrink-0"
          >
            <span>View All Capabilities</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        {/* Large Horizontal Service Cards */}
        <div className="space-y-6">
          {featuredServicesList.map((service, index) => (
            <div
              key={service.id}
              className="p-8 sm:p-12 rounded-3xl bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 transition-all duration-300 group relative overflow-hidden"
            >
              {/* Subtle accent hairline */}
              <div
                className="absolute top-0 left-0 right-0 h-1 opacity-0 group-hover:opacity-100 transition-opacity"
                style={{ backgroundColor: service.accentColor }}
              />

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                {/* Number & Headline */}
                <div className="lg:col-span-4">
                  <span className="text-xs font-mono uppercase tracking-widest text-neutral-400 font-medium">
                    0{index + 1} // Discipline
                  </span>
                  <h3 className="text-2xl sm:text-3xl font-bold font-display text-white mt-2 group-hover:text-orange-400 transition-colors">
                    {service.name}
                  </h3>
                  <p className="text-base text-orange-400/90 font-medium mt-2">
                    {service.hook}
                  </p>
                </div>

                {/* Description */}
                <div className="lg:col-span-4">
                  <p className="text-sm text-neutral-400 leading-relaxed">
                    {service.description}
                  </p>
                  <div className="mt-4 grid grid-cols-2 gap-2">
                    {service.bullets.map((b, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs text-neutral-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-orange-500 shrink-0" />
                        <span>{b}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* CTA Action */}
                <div className="lg:col-span-4 flex lg:justify-end">
                  <Link
                    to={service.link}
                    className="inline-flex items-center gap-3 px-6 py-3.5 rounded-xl bg-neutral-800/80 hover:bg-neutral-800 text-white text-xs font-semibold uppercase tracking-wider group-hover:bg-gradient-to-r group-hover:from-orange-500 group-hover:to-red-600 transition-all shadow-md"
                  >
                    <span>Explore {service.name}</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
