import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Search, X, ArrowRight, Layers, Briefcase, TrendingUp, Building2, BookOpen } from "lucide-react";
import { servicesData } from "../data/servicesData";
import { portfolioData } from "../data/portfolioData";
import { caseStudiesData } from "../data/caseStudiesData";
import { industriesData } from "../data/industriesData";
import { blogData } from "../data/blogData";

interface GlobalSearchProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GlobalSearch: React.FC<GlobalSearchProps> = ({ isOpen, onClose }) => {
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === "Escape") onClose();
      };
      window.addEventListener("keydown", handleKeyDown);
      return () => window.removeEventListener("keydown", handleKeyDown);
    }
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const q = query.toLowerCase().trim();

  // Filter sections
  const filteredServices = servicesData
    .flatMap((cat) => [
      { type: "Service", title: cat.title, desc: cat.tagline, link: `/services#${cat.id}` },
      ...cat.subServices.map((sub) => ({
        type: "Service",
        title: sub.name,
        desc: sub.description,
        link: `/services#${cat.id}`
      }))
    ])
    .filter((s) => !q || s.title.toLowerCase().includes(q) || s.desc.toLowerCase().includes(q))
    .slice(0, 4);

  const filteredWork = portfolioData
    .filter((p) => !q || p.title.toLowerCase().includes(q) || p.client.toLowerCase().includes(q) || p.summary.toLowerCase().includes(q))
    .map((p) => ({
      type: "Work",
      title: `${p.client} — ${p.title}`,
      desc: p.summary,
      link: `/work`
    }))
    .slice(0, 3);

  const filteredCaseStudies = caseStudiesData
    .filter((cs) => !q || cs.client.toLowerCase().includes(q) || cs.headline.toLowerCase().includes(q))
    .map((cs) => ({
      type: "Case Study",
      title: `${cs.client}: ${cs.headline}`,
      desc: cs.solution,
      link: `/case-studies`
    }))
    .slice(0, 3);

  const filteredIndustries = industriesData
    .filter((ind) => !q || ind.name.toLowerCase().includes(q) || ind.shortDesc.toLowerCase().includes(q))
    .map((ind) => ({
      type: "Industry",
      title: ind.name,
      desc: ind.shortDesc,
      link: `/industries#${ind.id}`
    }))
    .slice(0, 3);

  const filteredBlog = blogData
    .filter((b) => !q || b.title.toLowerCase().includes(q) || b.excerpt.toLowerCase().includes(q))
    .map((b) => ({
      type: "Article",
      title: b.title,
      desc: b.excerpt,
      link: `/blog`
    }))
    .slice(0, 3);

  const totalResults =
    filteredServices.length +
    filteredWork.length +
    filteredCaseStudies.length +
    filteredIndustries.length +
    filteredBlog.length;

  const handleSelect = (link: string) => {
    onClose();
    navigate(link);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Global Search"
      className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="relative flex items-center px-4 py-4 border-b border-neutral-800">
          <Search className="w-5 h-5 text-orange-500 mr-3 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search services, case studies, industries, client work, insights..."
            className="w-full bg-transparent text-neutral-100 placeholder-neutral-500 text-base focus:outline-none"
          />
          {query ? (
            <button
              onClick={() => setQuery("")}
              className="p-1 rounded-md text-neutral-400 hover:text-white transition-colors"
              aria-label="Clear search"
            >
              <X className="w-4 h-4" />
            </button>
          ) : (
            <span className="hidden sm:inline-block text-xs font-mono text-neutral-400 border border-neutral-700 rounded px-1.5 py-0.5">
              ESC
            </span>
          )}
        </div>

        {/* Results Area */}
        <div className="max-h-[60vh] overflow-y-auto p-4 space-y-4">
          {totalResults === 0 ? (
            <div className="py-12 text-center text-neutral-500">
              <p className="text-sm">No results found for &ldquo;{query}&rdquo;</p>
              <p className="text-xs text-neutral-600 mt-1">Try searching for &quot;Performance&quot;, &quot;Real Estate&quot;, &quot;SEO&quot;, or &quot;Branding&quot;</p>
            </div>
          ) : (
            <>
              {filteredServices.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 text-xs font-semibold text-orange-400 uppercase tracking-wider mb-2">
                    <Layers className="w-3.5 h-3.5" />
                    Services & Capabilities
                  </div>
                  <div className="space-y-1">
                    {filteredServices.map((item, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleSelect(item.link)}
                        className="w-full text-left p-2.5 rounded-lg hover:bg-neutral-800/80 transition-colors group flex items-center justify-between"
                      >
                        <div>
                          <div className="text-sm font-medium text-neutral-200 group-hover:text-white">
                            {item.title}
                          </div>
                          <div className="text-xs text-neutral-400 line-clamp-1">{item.desc}</div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-neutral-500 group-hover:text-orange-400 opacity-0 group-hover:opacity-100 transition-all shrink-0 ml-2" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {filteredWork.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 text-xs font-semibold text-red-400 uppercase tracking-wider mb-2">
                    <Briefcase className="w-3.5 h-3.5" />
                    Portfolio & Work
                  </div>
                  <div className="space-y-1">
                    {filteredWork.map((item, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleSelect(item.link)}
                        className="w-full text-left p-2.5 rounded-lg hover:bg-neutral-800/80 transition-colors group flex items-center justify-between"
                      >
                        <div>
                          <div className="text-sm font-medium text-neutral-200 group-hover:text-white">
                            {item.title}
                          </div>
                          <div className="text-xs text-neutral-400 line-clamp-1">{item.desc}</div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-neutral-500 group-hover:text-orange-400 opacity-0 group-hover:opacity-100 transition-all shrink-0 ml-2" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {filteredCaseStudies.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400 uppercase tracking-wider mb-2">
                    <TrendingUp className="w-3.5 h-3.5" />
                    Case Studies
                  </div>
                  <div className="space-y-1">
                    {filteredCaseStudies.map((item, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleSelect(item.link)}
                        className="w-full text-left p-2.5 rounded-lg hover:bg-neutral-800/80 transition-colors group flex items-center justify-between"
                      >
                        <div>
                          <div className="text-sm font-medium text-neutral-200 group-hover:text-white">
                            {item.title}
                          </div>
                          <div className="text-xs text-neutral-400 line-clamp-1">{item.desc}</div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-neutral-500 group-hover:text-cyan-400 opacity-0 group-hover:opacity-100 transition-all shrink-0 ml-2" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {filteredIndustries.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2">
                    <Building2 className="w-3.5 h-3.5" />
                    Industries
                  </div>
                  <div className="space-y-1">
                    {filteredIndustries.map((item, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleSelect(item.link)}
                        className="w-full text-left p-2.5 rounded-lg hover:bg-neutral-800/80 transition-colors group flex items-center justify-between"
                      >
                        <div>
                          <div className="text-sm font-medium text-neutral-200 group-hover:text-white">
                            {item.title}
                          </div>
                          <div className="text-xs text-neutral-400 line-clamp-1">{item.desc}</div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-neutral-500 group-hover:text-amber-400 opacity-0 group-hover:opacity-100 transition-all shrink-0 ml-2" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {filteredBlog.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-wider mb-2">
                    <BookOpen className="w-3.5 h-3.5" />
                    Ideas & Insights
                  </div>
                  <div className="space-y-1">
                    {filteredBlog.map((item, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleSelect(item.link)}
                        className="w-full text-left p-2.5 rounded-lg hover:bg-neutral-800/80 transition-colors group flex items-center justify-between"
                      >
                        <div>
                          <div className="text-sm font-medium text-neutral-200 group-hover:text-white">
                            {item.title}
                          </div>
                          <div className="text-xs text-neutral-400 line-clamp-1">{item.desc}</div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-neutral-500 group-hover:text-emerald-400 opacity-0 group-hover:opacity-100 transition-all shrink-0 ml-2" />
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="px-4 py-3 bg-neutral-950/60 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-500">
          <span>Search index powered by Thememax Tech World</span>
          <span>Click result or hit ESC to exit</span>
        </div>
      </div>
    </div>
  );
};
