import React from "react";
import { ArrowUpRight } from "lucide-react";
import { Project } from "../data/portfolioData";

interface PortfolioCardProps {
  project: Project;
  onSelect: (project: Project) => void;
}

export const PortfolioCard: React.FC<PortfolioCardProps> = ({ project, onSelect }) => {
  return (
    <div
      onClick={() => onSelect(project)}
      className="group relative cursor-pointer rounded-2xl bg-neutral-900 border border-neutral-800 overflow-hidden hover:border-neutral-700 transition-all duration-300 flex flex-col"
    >
      {/* Visual Canvas Representation */}
      <div className="relative aspect-[16/10] overflow-hidden bg-gradient-to-br from-neutral-950 via-neutral-900 to-neutral-950 flex items-center justify-center p-6">
        {/* Subtle patterned grid in card background */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,87,34,0.12),transparent_70%)] opacity-70 group-hover:opacity-100 transition-opacity" />

        {/* Dynamic Graphic Card Focal Graphic */}
        <div className="relative z-10 w-full flex flex-col items-center justify-center text-center p-4">
          <div
            className="w-14 h-14 rounded-2xl flex items-center justify-center mb-3 shadow-lg transition-transform duration-300 group-hover:scale-110"
            style={{ backgroundColor: `${project.accentColor}18`, borderColor: `${project.accentColor}40`, borderWidth: 1 }}
          >
            <span className="text-xl font-bold font-display" style={{ color: project.accentColor }}>
              {project.client.charAt(0)}
            </span>
          </div>

          <div className="text-xs font-mono uppercase tracking-widest text-neutral-400">
            {project.client}
          </div>

          <div className="mt-2 text-base font-semibold text-white group-hover:text-orange-400 transition-colors line-clamp-1">
            {project.title}
          </div>
        </div>

        {/* Hover Arrow Badge */}
        <div className="absolute top-4 right-4 w-9 h-9 rounded-full bg-neutral-950/80 border border-neutral-700/60 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all duration-200">
          <ArrowUpRight className="w-4 h-4 text-orange-400" />
        </div>
      </div>

      {/* Card Info Area */}
      <div className="p-6 flex-1 flex flex-col justify-between border-t border-neutral-800/80 bg-neutral-900/60">
        <div>
          {/* Clean Unboxed Metadata with · separator (Zero-Pill discipline) */}
          <div className="flex items-center gap-2 text-xs text-neutral-400 mb-2.5">
            <span className="text-orange-400 font-medium">{project.category}</span>
            <span aria-hidden="true">·</span>
            <span>{project.industry}</span>
          </div>

          <p className="text-xs text-neutral-400 line-clamp-2 leading-relaxed">
            {project.summary}
          </p>
        </div>

        {/* Primary Impact Stat */}
        <div className="mt-4 pt-4 border-t border-neutral-800/60 flex items-center justify-between">
          <span className="text-[11px] text-neutral-500 uppercase tracking-wider">Top Impact</span>
          <span className="text-sm font-bold font-mono text-emerald-400 tabular-nums">
            {project.metrics[0]?.value} {project.metrics[0]?.label}
          </span>
        </div>
      </div>
    </div>
  );
};
