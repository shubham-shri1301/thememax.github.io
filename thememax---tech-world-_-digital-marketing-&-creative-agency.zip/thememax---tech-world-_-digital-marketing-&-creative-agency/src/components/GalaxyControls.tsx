import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, Compass, Rocket, Eye, EyeOff, Sliders, ChevronDown, ChevronUp } from "lucide-react";
import { useGalaxy, GalaxyMode, GalaxyIntensity } from "../context/GalaxyContext";

export const GalaxyControls: React.FC = () => {
  const {
    enabled,
    toggleEnabled,
    mode,
    setMode,
    intensity,
    setIntensity,
    isWarping,
    triggerWarp,
    triggerSupernova
  } = useGalaxy();

  const [expanded, setExpanded] = useState(false);

  const modeOptions: { id: GalaxyMode; label: string }[] = [
    { id: "spiral", label: "Spiral Arms" },
    { id: "nebula", label: "Cosmic Nebula" },
    { id: "deep-field", label: "Deep Field" }
  ];

  const intensityOptions: { id: GalaxyIntensity; label: string }[] = [
    { id: "subtle", label: "Subtle" },
    { id: "balanced", label: "Balanced" },
    { id: "vivid", label: "Vivid" }
  ];

  return (
    <aside
      aria-label="Cosmic Galaxy Controls"
      className="fixed bottom-5 right-5 z-40 select-none flex flex-col items-end"
    >
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ opacity: 0, y: 15, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="mb-3 w-72 sm:w-80 rounded-2xl bg-neutral-900/95 dark:bg-neutral-900/95 backdrop-blur-xl border border-neutral-800 p-4 shadow-2xl shadow-black/60 text-xs text-neutral-200"
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-500" />
                </span>
                <span className="font-semibold text-white tracking-wide uppercase text-[11px] font-mono">
                  Cosmic Galaxy Engine
                </span>
              </div>
              <button
                type="button"
                onClick={toggleEnabled}
                className={`px-2 py-0.5 rounded text-[10px] font-mono uppercase font-semibold transition-colors ${
                  enabled
                    ? "bg-cyan-950 text-cyan-400 border border-cyan-800/60"
                    : "bg-neutral-800 text-neutral-400"
                }`}
                title={enabled ? "Disable galaxy background" : "Enable galaxy background"}
              >
                {enabled ? "Active" : "Disabled"}
              </button>
            </div>

            {/* Quick Interactive Actions */}
            <div className="py-3 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => triggerSupernova()}
                className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-orange-500/15 hover:bg-orange-500/25 border border-orange-500/30 text-orange-300 font-medium transition-all active:scale-95"
              >
                <Sparkles size={13} className="text-orange-400" />
                <span>Supernova</span>
              </button>
              <button
                type="button"
                onClick={() => triggerWarp(2600)}
                disabled={isWarping}
                className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border font-medium transition-all active:scale-95 ${
                  isWarping
                    ? "bg-cyan-500 text-white border-cyan-400 animate-pulse"
                    : "bg-cyan-500/15 hover:bg-cyan-500/25 border-cyan-500/30 text-cyan-300"
                }`}
              >
                <Rocket size={13} className={isWarping ? "animate-bounce" : "text-cyan-400"} />
                <span>{isWarping ? "Warping..." : "Warp Speed"}</span>
              </button>
            </div>

            {/* Galaxy View Modes */}
            <div className="pt-2 pb-3">
              <label className="text-[10px] uppercase font-mono tracking-wider text-neutral-400 block mb-1.5">
                Galaxy Geometry
              </label>
              <div className="grid grid-cols-3 gap-1 p-1 bg-neutral-950/70 rounded-lg border border-neutral-800/80">
                {modeOptions.map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setMode(opt.id)}
                    className={`py-1 text-[11px] rounded transition-all font-medium ${
                      mode === opt.id
                        ? "bg-neutral-800 text-white shadow-sm border border-neutral-700 font-semibold"
                        : "text-neutral-400 hover:text-neutral-200"
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Intensity Level */}
            <div className="pt-1 pb-2">
              <label className="text-[10px] uppercase font-mono tracking-wider text-neutral-400 block mb-1.5">
                Stardust Density
              </label>
              <div className="grid grid-cols-3 gap-1 p-1 bg-neutral-950/70 rounded-lg border border-neutral-800/80">
                {intensityOptions.map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setIntensity(opt.id)}
                    className={`py-1 text-[11px] rounded transition-all font-medium ${
                      intensity === opt.id
                        ? "bg-neutral-800 text-orange-400 shadow-sm border border-neutral-700 font-semibold"
                        : "text-neutral-400 hover:text-neutral-200"
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Interactive hint */}
            <p className="mt-2 text-[10px] text-neutral-400 text-center italic border-t border-neutral-800/60 pt-2">
              Tip: Move cursor to swirl galaxy or click anywhere to ignite stardust.
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Persistent Floating Trigger Button */}
      <button
        type="button"
        onClick={() => setExpanded(!expanded)}
        className="group relative flex items-center gap-2.5 px-3.5 py-2.5 rounded-full bg-neutral-900/90 dark:bg-neutral-900/95 hover:bg-neutral-800 backdrop-blur-md border border-neutral-700/80 hover:border-orange-500/50 shadow-lg shadow-black/50 text-white transition-all duration-200 active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-orange-500"
        aria-expanded={expanded}
        aria-label="Toggle galaxy controls"
        title="Interactive Galaxy Controls"
      >
        <span className="relative flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-2 w-2 bg-orange-500" />
        </span>

        <span className="flex items-center gap-1.5 text-xs font-semibold tracking-wide">
          <Sparkles size={13} className="text-orange-400 group-hover:rotate-12 transition-transform duration-300" />
          <span className="font-mono text-[11px]">Galaxy Effect</span>
        </span>

        {expanded ? (
          <ChevronDown size={14} className="text-neutral-400" />
        ) : (
          <ChevronUp size={14} className="text-neutral-400" />
        )}
      </button>
    </aside>
  );
};
