import React, { useRef } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, ChevronLeft, ChevronRight, Eye } from "lucide-react";

interface WallItem {
  id: string;
  type: string;
  title: string;
  brand: string;
  aspect: string;
  color: string;
}

const wallItems: WallItem[] = [
  { id: "w1", type: "3D Motion Graphic", title: "Kinetic Sphere Visualizer", brand: "Tech World Labs", aspect: "w-80", color: "#FF5722" },
  { id: "w2", type: "Paid Social Ad", title: "4.8x ROAS Reel Hook Variant", brand: "Aurelia Beauty", aspect: "w-64", color: "#DC2626" },
  { id: "w3", type: "Web Interface", title: "Sub-Second EV Fleet Configurator", brand: "Vertex Mobility", aspect: "w-96", color: "#00D2FF" },
  { id: "w4", type: "Brand Identity", title: "Custom Neo-Grotesque Typography", brand: "Orbit Financial", aspect: "w-72", color: "#FF5722" },
  { id: "w5", type: "Architectural Showcase", title: "Ultra-Luxury Property Funnel", brand: "Nova Properties", aspect: "w-80", color: "#DC2626" },
  { id: "w6", type: "High-Fashion Video", title: "Capsule Drop Teaser Film", brand: "Monarch Apparel", aspect: "w-72", color: "#00D2FF" }
];

export const CreativeWall: React.FC = () => {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const offset = direction === "left" ? -400 : 400;
      scrollRef.current.scrollBy({ left: offset, behavior: "smooth" });
    }
  };

  return (
    <section className="py-24 bg-neutral-950 overflow-hidden relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-10">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-semibold uppercase tracking-widest text-orange-500">
              Visual Craft
            </span>
            <h2 className="text-3xl sm:text-5xl font-extrabold font-display text-white tracking-tight mt-2">
              The Creative Wall
            </h2>
            <p className="mt-2 text-sm text-neutral-400">
              A curated tapestry of campaign assets, kinetic motion graphics, and high-conversion interfaces.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => scroll("left")}
              className="p-2.5 rounded-full bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-neutral-300 hover:text-white transition-colors"
              aria-label="Scroll left"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => scroll("right")}
              className="p-2.5 rounded-full bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-neutral-300 hover:text-white transition-colors"
              aria-label="Scroll right"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
            <Link
              to="/work"
              className="ml-2 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-orange-400 hover:text-orange-300 transition-colors"
            >
              <span>Explore All Work</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </div>

      {/* Horizontal Scroll Gallery */}
      <div
        ref={scrollRef}
        className="flex gap-6 overflow-x-auto px-6 sm:px-12 pb-6 scrollbar-none scroll-smooth"
        style={{ scrollbarWidth: "none" }}
      >
        {wallItems.map((item) => (
          <div
            key={item.id}
            className={`shrink-0 ${item.aspect} h-80 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 p-6 flex flex-col justify-between relative overflow-hidden group cursor-pointer transition-all duration-300`}
          >
            {/* Ambient Corner Flare */}
            <div
              className="absolute top-0 right-0 w-32 h-32 rounded-full blur-2xl opacity-20 group-hover:opacity-40 transition-opacity"
              style={{ backgroundColor: item.color }}
            />

            {/* Top metadata */}
            <div className="flex items-center justify-between z-10">
              <span className="text-[11px] font-mono uppercase tracking-wider text-neutral-400">
                {item.type}
              </span>
              <span className="w-7 h-7 rounded-full bg-neutral-950/80 border border-neutral-800 flex items-center justify-center text-neutral-400 group-hover:text-white transition-colors">
                <Eye className="w-3.5 h-3.5" />
              </span>
            </div>

            {/* Center decorative motif */}
            <div className="my-auto text-center z-10">
              <div
                className="w-16 h-16 mx-auto rounded-xl flex items-center justify-center font-display font-bold text-2xl mb-2 transition-transform duration-300 group-hover:scale-110"
                style={{ backgroundColor: `${item.color}15`, color: item.color }}
              >
                {item.brand.charAt(0)}
              </div>
            </div>

            {/* Bottom details */}
            <div className="z-10">
              <div className="text-xs font-mono text-orange-400">{item.brand}</div>
              <div className="text-base font-bold text-white group-hover:text-orange-400 transition-colors line-clamp-1 mt-0.5">
                {item.title}
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
