import React, { createContext, useContext, useState, useEffect, useCallback } from "react";

export type GalaxyMode = "spiral" | "nebula" | "deep-field" | "minimal";
export type GalaxyIntensity = "subtle" | "balanced" | "vivid";

interface SupernovaEvent {
  id: number;
  x: number;
  y: number;
}

interface GalaxyContextType {
  enabled: boolean;
  toggleEnabled: () => void;
  mode: GalaxyMode;
  setMode: (mode: GalaxyMode) => void;
  intensity: GalaxyIntensity;
  setIntensity: (intensity: GalaxyIntensity) => void;
  isWarping: boolean;
  triggerWarp: (durationMs?: number) => void;
  triggerSupernova: (x?: number, y?: number) => void;
  supernovaEvents: SupernovaEvent[];
  clearSupernovaEvent: (id: number) => void;
}

const GALAXY_PREF_KEY = "thememax_galaxy_enabled";
const GALAXY_MODE_KEY = "thememax_galaxy_mode";

const GalaxyContext = createContext<GalaxyContextType | undefined>(undefined);

export const GalaxyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [enabled, setEnabled] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(GALAXY_PREF_KEY);
      if (stored !== null) return stored === "true";
    }
    return true; // Enabled by default for rich cosmic agency aesthetic
  });

  const [mode, setModeState] = useState<GalaxyMode>(() => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(GALAXY_MODE_KEY) as GalaxyMode | null;
      if (stored && ["spiral", "nebula", "deep-field", "minimal"].includes(stored)) {
        return stored;
      }
    }
    return "spiral";
  });

  const [intensity, setIntensityState] = useState<GalaxyIntensity>("balanced");
  const [isWarping, setIsWarping] = useState<boolean>(false);
  const [supernovaEvents, setSupernovaEvents] = useState<SupernovaEvent[]>([]);

  useEffect(() => {
    try {
      localStorage.setItem(GALAXY_PREF_KEY, String(enabled));
    } catch {
      // Safe fallback
    }
  }, [enabled]);

  useEffect(() => {
    try {
      localStorage.setItem(GALAXY_MODE_KEY, mode);
    } catch {
      // Safe fallback
    }
  }, [mode]);

  const toggleEnabled = useCallback(() => {
    setEnabled((prev) => !prev);
  }, []);

  const setMode = useCallback((newMode: GalaxyMode) => {
    setModeState(newMode);
  }, []);

  const setIntensity = useCallback((newIntensity: GalaxyIntensity) => {
    setIntensityState(newIntensity);
  }, []);

  const triggerWarp = useCallback((durationMs = 2800) => {
    setIsWarping(true);
    const timer = setTimeout(() => {
      setIsWarping(false);
    }, durationMs);
    return () => clearTimeout(timer);
  }, []);

  const triggerSupernova = useCallback((x?: number, y?: number) => {
    const defaultX = typeof window !== "undefined" ? window.innerWidth / 2 : 500;
    const defaultY = typeof window !== "undefined" ? window.innerHeight / 3 : 300;
    const newEvent: SupernovaEvent = {
      id: Date.now() + Math.random(),
      x: x ?? defaultX,
      y: y ?? defaultY
    };
    setSupernovaEvents((prev) => [...prev.slice(-4), newEvent]);
  }, []);

  const clearSupernovaEvent = useCallback((id: number) => {
    setSupernovaEvents((prev) => prev.filter((e) => e.id !== id));
  }, []);

  return (
    <GalaxyContext.Provider
      value={{
        enabled,
        toggleEnabled,
        mode,
        setMode,
        intensity,
        setIntensity,
        isWarping,
        triggerWarp,
        triggerSupernova,
        supernovaEvents,
        clearSupernovaEvent
      }}
    >
      {children}
    </GalaxyContext.Provider>
  );
};

export const useGalaxy = (): GalaxyContextType => {
  const context = useContext(GalaxyContext);
  if (!context) {
    throw new Error("useGalaxy must be used within a GalaxyProvider");
  }
  return context;
};
