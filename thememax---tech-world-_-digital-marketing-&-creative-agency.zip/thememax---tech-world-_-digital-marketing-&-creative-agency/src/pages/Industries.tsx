import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, CheckCircle2, Building, ShieldCheck, Zap } from "lucide-react";
import { industriesData, Industry } from "../data/industriesData";
import { CTASection } from "../components/CTASection";
import { FadeUp, StaggerContainer, StaggerItem } from "../components/FadeUp";

export const Industries: React.FC = () => {
  const [selectedIndustry, setSelectedIndustry] = useState<Industry | null>(industriesData[0]);

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 pt-32 sm:pt-40">
      {/* Header */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 border-b border-neutral-900">
        <FadeUp delay={0.1} className="max-w-3xl">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-orange-500 mb-3">
            <span>Specialized Domain Expertise</span>
          </div>
          <h1 className="text-4xl sm:text-6xl font-extrabold font-display text-white tracking-tight leading-tight text-balance">
            Industries We Understand
          </h1>
          <p className="mt-4 text-lg text-neutral-300 leading-relaxed text-balance">
            Every sector possesses distinct buying psychology, regulatory constraints, and unit economics. We build growth architectures tailored to the nuanced realities of your market.
          </p>
        </FadeUp>
      </section>

      {/* 12 Industry Cards Grid with StaggerContainer */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <StaggerContainer staggerDelay={0.06} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {industriesData.map((ind) => (
            <StaggerItem key={ind.id}>
              <div
                id={ind.id}
                className="p-8 rounded-2xl bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 transition-all duration-300 flex flex-col justify-between group relative overflow-hidden h-full"
              >
                {/* Subtle top accent */}
                <div
                  className="absolute top-0 left-0 right-0 h-1 opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ backgroundColor: ind.color }}
                />

                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center font-bold font-display text-base transition-transform group-hover:scale-105"
                      style={{ backgroundColor: `${ind.color}15`, color: ind.color }}
                    >
                      {ind.name.charAt(0)}
                    </div>
                    <span className="text-xs font-mono text-neutral-400">
                      {ind.metricLabel}: <strong className="text-white">{ind.keyMetric}</strong>
                    </span>
                  </div>

                  <h2 className="text-2xl font-bold font-display text-white group-hover:text-orange-400 transition-colors">
                    {ind.name}
                  </h2>

                  <p className="mt-3 text-xs text-neutral-400 leading-relaxed">
                    {ind.shortDesc}
                  </p>

                  {/* Tactical Solutions */}
                  <div className="mt-6 pt-4 border-t border-neutral-800/80 space-y-1.5">
                    <div className="text-[10px] font-mono uppercase tracking-widest text-neutral-400 mb-2">
                      Core Solutions
                    </div>
                    {ind.solutions.map((sol, sIdx) => (
                      <div key={sIdx} className="flex items-center gap-2 text-xs text-neutral-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-orange-500 shrink-0" />
                        <span>{sol}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Button */}
                <div className="mt-8 pt-4 border-t border-neutral-800/60 flex items-center justify-between">
                  <Link
                    to="/contact"
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-orange-400 hover:text-orange-300 transition-colors group-hover:translate-x-0.5"
                  >
                    <span>Build {ind.name} Campaign</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </section>

      {/* CTA */}
      <FadeUp delay={0.1}>
        <CTASection />
      </FadeUp>
    </div>
  );
};
