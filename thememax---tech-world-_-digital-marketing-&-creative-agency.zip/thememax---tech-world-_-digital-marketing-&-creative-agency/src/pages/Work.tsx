import React, { useState } from "react";
import { portfolioData, Project } from "../data/portfolioData";
import { PortfolioCard } from "../components/PortfolioCard";
import { ProjectModal } from "../components/ProjectModal";
import { CTASection } from "../components/CTASection";
import { FadeUp, StaggerContainer, StaggerItem } from "../components/FadeUp";

type CategoryFilter = "All" | "Branding" | "Websites" | "Social Media" | "Performance" | "Video" | "Ecommerce";

const filterOptions: CategoryFilter[] = [
  "All",
  "Branding",
  "Websites",
  "Social Media",
  "Performance",
  "Video",
  "Ecommerce"
];

export const Work: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState<CategoryFilter>("All");
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const filteredProjects = activeFilter === "All"
    ? portfolioData
    : portfolioData.filter((p) => p.category === activeFilter);

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 pt-32 sm:pt-40">
      {/* Header */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12 border-b border-neutral-900">
        <FadeUp delay={0.1} className="max-w-3xl">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-orange-500 mb-3">
            <span>Portfolio & Case Vault</span>
          </div>
          <h1 className="text-4xl sm:text-6xl font-extrabold font-display text-white tracking-tight leading-tight text-balance">
            Selected Work
          </h1>
          <p className="mt-4 text-lg text-neutral-300 leading-relaxed text-balance">
            Ideas brought to life through strategy, design, and technology. Explore our featured engagements across branding, performance, video, and web engineering.
          </p>
        </FadeUp>

        {/* Filter Tabs / Segmented Controls with subtle fade */}
        <FadeUp delay={0.2} className="mt-10 flex flex-wrap items-center gap-2">
          {filterOptions.map((filter) => {
            const isActive = activeFilter === filter;
            return (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-lg transition-all duration-200 ${
                  isActive
                    ? "bg-gradient-to-r from-orange-500 to-red-600 text-white shadow-md shadow-orange-500/20"
                    : "bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800 border border-neutral-800"
                }`}
              >
                {filter}
              </button>
            );
          })}
        </FadeUp>
      </section>

      {/* Grid Portfolio with StaggerContainer */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <StaggerContainer key={activeFilter} staggerDelay={0.08} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <StaggerItem key={project.id}>
              <PortfolioCard
                project={project}
                onSelect={(p) => setSelectedProject(p)}
              />
            </StaggerItem>
          ))}
        </StaggerContainer>

        {filteredProjects.length === 0 && (
          <FadeUp className="py-20 text-center text-neutral-500">
            <p className="text-sm">No projects currently listed in this category filter.</p>
          </FadeUp>
        )}
      </section>

      {/* Final CTA */}
      <FadeUp delay={0.1}>
        <CTASection />
      </FadeUp>

      {/* Interactive Project Modal */}
      <ProjectModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
      />
    </div>
  );
};
