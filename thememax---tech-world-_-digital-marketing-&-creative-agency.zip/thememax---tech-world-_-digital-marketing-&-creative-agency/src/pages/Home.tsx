import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, ArrowDown, Sparkles, CheckCircle2, TrendingUp, Layers, Zap } from "lucide-react";
import { HeroVisual } from "../components/HeroVisual";
import { LogoMarquee } from "../components/LogoMarquee";
import { FeaturedServices } from "../components/FeaturedServices";
import { StatsSection } from "../components/StatsSection";
import { ProcessTimeline } from "../components/ProcessTimeline";
import { TechStackSection } from "../components/TechStackSection";
import { TestimonialSlider } from "../components/TestimonialSlider";
import { CreativeWall } from "../components/CreativeWall";
import { CTASection } from "../components/CTASection";
import { PortfolioCard } from "../components/PortfolioCard";
import { ProjectModal } from "../components/ProjectModal";
import { FadeUp, StaggerContainer, StaggerItem } from "../components/FadeUp";
import { portfolioData, Project } from "../data/portfolioData";
import { caseStudiesData } from "../data/caseStudiesData";
import { blogData } from "../data/blogData";
import { useGalaxy } from "../context/GalaxyContext";

export const Home: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const { triggerSupernova } = useGalaxy();
  const featuredProjects = portfolioData.slice(0, 4);
  const recentArticles = blogData.slice(0, 3);

  return (
    <div className="min-h-screen bg-transparent text-neutral-100">
      {/* 1. HERO SECTION */}
      <section className="relative pt-32 pb-20 sm:pt-40 sm:pb-32 overflow-hidden flex items-center min-h-[90vh]">
        {/* Background ambient gradient glow */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[500px] bg-[radial-gradient(ellipse_at_top,rgba(255,87,34,0.12),transparent_70%)] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
            {/* Left Content Column with Framer Motion FadeUp */}
            <FadeUp delay={0.1} duration={0.8} distance={30} className="lg:col-span-7 space-y-6 sm:space-y-8 text-left">
              {/* Top Label */}
              <div className="inline-flex items-center gap-2.5 px-3 py-1.5 rounded-full bg-neutral-900/80 border border-neutral-800 text-[11px] font-mono tracking-widest uppercase text-orange-400 backdrop-blur-sm">
                <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
                <span>DIGITAL · CREATIVE · PERFORMANCE</span>
                <span className="hidden sm:inline text-neutral-600">·</span>
                <span className="hidden sm:inline-flex items-center gap-1 text-cyan-400 font-semibold normal-case">
                  <Sparkles size={11} />
                  <span>Galaxy Active</span>
                </span>
              </div>

              {/* Main Headline */}
              <h1 className="text-4xl sm:text-6xl xl:text-7xl font-extrabold font-display text-white tracking-tight leading-[1.05] text-balance">
                We Build Brands That{" "}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 via-red-500 to-cyan-400">
                  Get Noticed.
                </span>
              </h1>

              {/* Alternative supporting line */}
              <p className="text-base sm:text-xl text-neutral-300 max-w-2xl leading-relaxed text-balance">
                Strategy, creativity, and technology designed to turn market attention into measurable, predictable business growth.
              </p>

              {/* CTA Action Buttons */}
              <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
                <Link
                  to="/contact"
                  className="inline-flex items-center justify-center gap-2 px-8 py-4 text-xs font-semibold uppercase tracking-wider text-white bg-gradient-to-r from-orange-500 via-red-600 to-orange-600 hover:from-orange-600 hover:to-red-700 rounded-xl shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40 transition-all duration-200 active:scale-95 whitespace-nowrap"
                >
                  <span>Start a Project</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>

                <a
                  href="#selected-work"
                  className="inline-flex items-center justify-center gap-2 px-8 py-4 text-xs font-semibold uppercase tracking-wider text-neutral-300 hover:text-white bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-800 rounded-xl transition-all whitespace-nowrap"
                >
                  <span>Explore Our Work</span>
                  <ArrowDown className="w-4 h-4 text-neutral-400" />
                </a>

                {/* Interactive Galaxy Pulse Trigger */}
                <button
                  type="button"
                  onClick={(e) => triggerSupernova(e.clientX, e.clientY)}
                  className="inline-flex items-center justify-center gap-2 px-5 py-4 text-xs font-mono text-cyan-300 hover:text-white bg-neutral-900/60 hover:bg-neutral-800/80 border border-cyan-500/30 hover:border-cyan-400/60 rounded-xl transition-all active:scale-95 whitespace-nowrap group"
                  title="Ignite an interactive stardust burst"
                >
                  <Sparkles className="w-4 h-4 text-cyan-400 group-hover:rotate-45 transition-transform duration-300" />
                  <span>Ignite Stardust</span>
                </button>
              </div>

              {/* Quiet Proof Markers */}
              <div className="pt-6 border-t border-neutral-900/80 flex flex-wrap items-center gap-6 text-xs text-neutral-400">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-orange-500" />
                  <span>Full-Funnel Attribution</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-red-500" />
                  <span>High-Craft Creative</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                  <span>Sub-Second Tech</span>
                </div>
              </div>
            </FadeUp>

            {/* Right Abstract Visual Column with Subtle delayed reveal */}
            <FadeUp delay={0.25} duration={0.85} distance={35} className="lg:col-span-5 flex justify-center">
              <HeroVisual />
            </FadeUp>
          </div>
        </div>
      </section>

      {/* 2. TRUST / CLIENT LOGO SECTION */}
      <FadeUp delay={0.15}>
        <LogoMarquee />
      </FadeUp>

      {/* 3. ABOUT / AGENCY INTRODUCTION */}
      <section className="py-24 bg-neutral-950/80 relative border-b border-neutral-900/80 backdrop-blur-[2px]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <FadeUp delay={0.1} className="lg:col-span-6 space-y-6">
              <span className="text-xs font-semibold uppercase tracking-widest text-orange-500">
                Who We Are
              </span>
              <h2 className="text-3xl sm:text-5xl font-extrabold font-display text-white tracking-tight leading-tight">
                A creative agency built for the digital age.
              </h2>
              <p className="text-base text-neutral-300 leading-relaxed">
                Thememax was conceived at the intersection of aesthetic brilliance and quantitative discipline. Traditional agencies often treat marketing, technology, and branding as isolated silos.
              </p>
              <p className="text-sm text-neutral-400 leading-relaxed">
                We combine strategy, branding, creative production, technology, performance marketing, and server-side data analytics into a single cohesive growth engine. The result is work that doesn&apos;t just win awards—it compounds revenue.
              </p>

              <div className="pt-4">
                <Link
                  to="/about"
                  className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-orange-400 hover:text-orange-300 transition-colors group"
                >
                  <span>Learn More About Our Philosophy</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>
            </FadeUp>

            {/* Visual Alongside the Content with Quick Statistics */}
            <FadeUp delay={0.2} className="lg:col-span-6">
              <div className="p-8 sm:p-10 rounded-3xl bg-neutral-900/60 border border-neutral-800 relative overflow-hidden">
                <div className="grid grid-cols-2 gap-6 sm:gap-8">
                  <div className="p-4 rounded-xl bg-neutral-950/70 border border-neutral-800">
                    <div className="text-3xl sm:text-4xl font-extrabold font-mono text-orange-500 tabular-nums">
                      10+
                    </div>
                    <div className="text-xs font-semibold text-white mt-1">Years Experience</div>
                    <p className="text-[11px] text-neutral-400 mt-1">Pioneering digital growth</p>
                  </div>

                  <div className="p-4 rounded-xl bg-neutral-950/70 border border-neutral-800">
                    <div className="text-3xl sm:text-4xl font-extrabold font-mono text-red-500 tabular-nums">
                      150+
                    </div>
                    <div className="text-xs font-semibold text-white mt-1">Brands Scaled</div>
                    <p className="text-[11px] text-neutral-400 mt-1">Global market reach</p>
                  </div>

                  <div className="p-4 rounded-xl bg-neutral-950/70 border border-neutral-800">
                    <div className="text-3xl sm:text-4xl font-extrabold font-mono text-cyan-400 tabular-nums">
                      300+
                    </div>
                    <div className="text-xs font-semibold text-white mt-1">Campaigns</div>
                    <p className="text-[11px] text-neutral-400 mt-1">Multi-channel executions</p>
                  </div>

                  <div className="p-4 rounded-xl bg-neutral-950/70 border border-neutral-800">
                    <div className="text-3xl sm:text-4xl font-extrabold font-mono text-orange-400 tabular-nums">
                      12+
                    </div>
                    <div className="text-xs font-semibold text-white mt-1">Industries</div>
                    <p className="text-[11px] text-neutral-400 mt-1">Domain-specific models</p>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-neutral-800 text-[11px] font-mono text-neutral-400 text-center">
                  * Representative demonstration metrics for agency portfolio capabilities
                </div>
              </div>
            </FadeUp>
          </div>
        </div>
      </section>

      {/* 4. FEATURED SERVICES SECTION */}
      <FadeUp delay={0.1}>
        <FeaturedServices />
      </FadeUp>

      {/* 5. SELECTED WORK SECTION */}
      <section id="selected-work" className="py-24 bg-neutral-950/80 relative border-t border-neutral-900/80 backdrop-blur-[2px]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <FadeUp delay={0.1} className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
            <div>
              <span className="text-xs font-semibold uppercase tracking-widest text-orange-500">
                Selected Work
              </span>
              <h2 className="text-3xl sm:text-5xl font-extrabold font-display text-white tracking-tight mt-2">
                Ideas brought to life through strategy, design & technology.
              </h2>
            </div>
            <Link
              to="/work"
              className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-orange-400 hover:text-orange-300 transition-colors group shrink-0"
            >
              <span>Explore All Projects</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </FadeUp>

          <StaggerContainer staggerDelay={0.12} className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {featuredProjects.map((project) => (
              <StaggerItem key={project.id}>
                <PortfolioCard
                  project={project}
                  onSelect={(p) => setSelectedProject(p)}
                />
              </StaggerItem>
            ))}
          </StaggerContainer>
        </div>
      </section>

      {/* 6. CASE STUDY SPOTLIGHT */}
      <section className="py-24 bg-neutral-950/70 relative border-t border-neutral-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <FadeUp delay={0.1} className="max-w-3xl mb-16">
            <span className="text-xs font-semibold uppercase tracking-widest text-orange-500">
              In-Depth Analysis
            </span>
            <h2 className="text-3xl sm:text-5xl font-extrabold font-display text-white tracking-tight mt-2">
              Documented Client Transformations
            </h2>
          </FadeUp>

          <StaggerContainer staggerDelay={0.12} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {caseStudiesData.map((cs) => (
              <StaggerItem key={cs.id}>
                <div
                  className="p-8 rounded-2xl bg-neutral-900/60 border border-neutral-800 flex flex-col justify-between hover:border-neutral-700 transition-all group h-full"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs font-mono text-neutral-400 mb-3">
                      <span className="text-orange-400 font-medium">{cs.client}</span>
                      <span>{cs.timeline}</span>
                    </div>
                    <h3 className="text-xl font-bold font-display text-white group-hover:text-orange-400 transition-colors mb-3">
                      {cs.headline}
                    </h3>
                    <div className="text-xs text-neutral-400 mb-4 line-clamp-3">
                      <strong className="text-neutral-300">Challenge:</strong> {cs.challenge}
                    </div>
                  </div>

                  <div className="pt-6 border-t border-neutral-800">
                    <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
                      {cs.results[0]?.metric}
                    </div>
                    <div className="text-xs text-neutral-400 mt-0.5">
                      {cs.results[0]?.description}
                    </div>
                    <Link
                      to="/case-studies"
                      className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-orange-400 hover:text-orange-300"
                    >
                      <span>Read Full Case Study</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </div>
              </StaggerItem>
            ))}
          </StaggerContainer>
        </div>
      </section>

      {/* 7. METHODOLOGY / HOW WE WORK */}
      <FadeUp delay={0.1}>
        <ProcessTimeline />
      </FadeUp>

      {/* 8. RESULTS / METRICS SECTION */}
      <FadeUp delay={0.1}>
        <StatsSection />
      </FadeUp>

      {/* 9. TESTIMONIALS */}
      <FadeUp delay={0.1}>
        <TestimonialSlider />
      </FadeUp>

      {/* 10. THE CREATIVE WALL */}
      <FadeUp delay={0.1}>
        <CreativeWall />
      </FadeUp>

      {/* 11. TECHNOLOGY / DIGITAL CAPABILITIES */}
      <FadeUp delay={0.1}>
        <TechStackSection />
      </FadeUp>

      {/* 12. IDEAS & INSIGHTS (BLOG PREVIEW) */}
      <section className="py-24 bg-neutral-950/80 relative border-t border-neutral-900/80 backdrop-blur-[2px]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <FadeUp delay={0.1} className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
            <div>
              <span className="text-xs font-semibold uppercase tracking-widest text-orange-500">
                Thought Leadership
              </span>
              <h2 className="text-3xl sm:text-5xl font-extrabold font-display text-white tracking-tight mt-2">
                Ideas & Insights
              </h2>
            </div>
            <Link
              to="/blog"
              className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-orange-400 hover:text-orange-300 transition-colors group shrink-0"
            >
              <span>View All Articles</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </FadeUp>

          <StaggerContainer staggerDelay={0.12} className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {recentArticles.map((article) => (
              <StaggerItem key={article.id}>
                <div
                  className="p-6 rounded-2xl bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 transition-all flex flex-col justify-between group h-full"
                >
                  <div>
                    <div className="flex items-center gap-2 text-xs text-neutral-400 mb-3">
                      <span className="text-orange-400 font-medium">{article.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{article.readTime}</span>
                    </div>
                    <h3 className="text-lg font-bold font-display text-white group-hover:text-orange-400 transition-colors leading-snug">
                      {article.title}
                    </h3>
                    <p className="mt-3 text-xs text-neutral-400 leading-relaxed line-clamp-3">
                      {article.excerpt}
                    </p>
                  </div>
                  <div className="mt-6 pt-4 border-t border-neutral-800/80 flex items-center justify-between">
                    <span className="text-xs text-neutral-400">{article.date}</span>
                    <Link
                      to="/blog"
                      className="inline-flex items-center gap-1 text-xs font-semibold text-orange-400 hover:text-orange-300"
                    >
                      <span>Read Article</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </div>
              </StaggerItem>
            ))}
          </StaggerContainer>
        </div>
      </section>

      {/* 13. FINAL CTA */}
      <FadeUp delay={0.1}>
        <CTASection />
      </FadeUp>

      {/* Project Detail Modal */}
      <ProjectModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
      />
    </div>
  );
};
