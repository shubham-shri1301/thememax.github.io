import React, { useState } from "react";
import { Mail, Phone, MapPin, Send, CheckCircle2, AlertCircle, ArrowRight, ShieldCheck } from "lucide-react";
import { api, ContactSubmission } from "../services/api";
import { FadeUp } from "../components/FadeUp";

const availableServices = [
  "Digital Marketing",
  "Google Ads",
  "Meta Ads",
  "SEO",
  "Social Media",
  "Branding",
  "Website Development",
  "Ecommerce",
  "Other"
];

const budgetRanges = [
  "Under ₹2 Lakhs",
  "₹2 Lakhs – ₹5 Lakhs",
  "₹5 Lakhs – ₹15 Lakhs",
  "₹15 Lakhs – ₹50 Lakhs",
  "₹50 Lakhs+"
];

export const Contact: React.FC = () => {
  const [formData, setFormData] = useState<ContactSubmission>({
    name: "",
    company: "",
    email: "",
    phone: "",
    website: "",
    services: ["Digital Marketing"],
    budget: "₹5 Lakhs – ₹15 Lakhs",
    details: "",
    honeypot: ""
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitResult, setSubmitResult] = useState<{ success: boolean; message: string; id?: string } | null>(null);

  const toggleService = (service: string) => {
    setFormData((prev) => {
      const exists = prev.services.includes(service);
      if (exists) {
        if (prev.services.length === 1) return prev; // Keep at least one
        return { ...prev, services: prev.services.filter((s) => s !== service) };
      }
      return { ...prev, services: [...prev.services, service] };
    });
  };

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.name.trim()) errs.name = "Full name is required";
    if (!formData.company.trim()) errs.company = "Company / Brand name is required";
    if (!formData.email.trim()) {
      errs.email = "Email address is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errs.email = "Please provide a valid work email address";
    }
    if (!formData.phone.trim()) {
      errs.phone = "Phone / WhatsApp number is required";
    } else if (formData.phone.replace(/\D/g, "").length < 7) {
      errs.phone = "Please enter a valid telephone number";
    }
    if (!formData.details.trim()) {
      errs.details = "Please share a brief summary of your project or targets";
    } else if (formData.details.trim().length < 15) {
      errs.details = "Project brief must be at least 15 characters";
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    setSubmitResult(null);

    const res = await api.submitContact(formData);
    setIsSubmitting(false);

    if (res.success && res.data) {
      setSubmitResult({
        success: true,
        message: res.data.message,
        id: res.data.id
      });
      // Reset form
      setFormData({
        name: "",
        company: "",
        email: "",
        phone: "",
        website: "",
        services: ["Digital Marketing"],
        budget: "₹5 Lakhs – ₹15 Lakhs",
        details: "",
        honeypot: ""
      });
      setErrors({});
    } else {
      setSubmitResult({
        success: false,
        message: res.error || "An error occurred while submitting your enquiry. Please retry."
      });
    }
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 pt-32 sm:pt-40">
      {/* Header */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12 border-b border-neutral-900">
        <FadeUp>
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-orange-500 mb-3">
              <span>Initiate Collaboration</span>
            </div>
            <h1 className="text-4xl sm:text-6xl font-extrabold font-display text-white tracking-tight leading-tight text-balance">
              Start a Project
            </h1>
            <p className="mt-4 text-lg text-neutral-300 leading-relaxed text-balance">
              Tell us about your brand, growth hurdles, and commercial targets. A Senior Thememax Partner will review your brief within 24 hours.
            </p>
          </div>
        </FadeUp>
      </section>

      {/* Main Grid */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <FadeUp delay={0.1}>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Contact Details Column */}
          <div className="lg:col-span-4 space-y-8">
            <div className="p-8 rounded-3xl bg-neutral-900/60 border border-neutral-800 space-y-6">
              <h2 className="text-xl font-bold font-display text-white">
                Studio Communications
              </h2>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Whether you are launching a flagship consumer brand or scaling enterprise B2B customer acquisition, our partners are ready to diagnose your funnel.
              </p>

              <div className="space-y-4 pt-4 border-t border-neutral-800 text-sm">
                <a
                  href="mailto:hello@thememax.example"
                  className="flex items-center gap-3 text-neutral-300 hover:text-orange-400 transition-colors"
                >
                  <div className="w-10 h-10 rounded-xl bg-orange-500/15 text-orange-500 flex items-center justify-center shrink-0">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[11px] font-mono text-neutral-500">General Inquiries</div>
                    <div className="font-semibold text-white">hello@thememax.example</div>
                  </div>
                </a>

                <a
                  href="tel:+919876543210"
                  className="flex items-center gap-3 text-neutral-300 hover:text-orange-400 transition-colors"
                >
                  <div className="w-10 h-10 rounded-xl bg-red-500/15 text-red-500 flex items-center justify-center shrink-0">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[11px] font-mono text-neutral-500">Direct Telephone</div>
                    <div className="font-semibold text-white">+91 98765 43210</div>
                  </div>
                </a>

                <div className="flex items-center gap-3 text-neutral-300">
                  <div className="w-10 h-10 rounded-xl bg-cyan-500/15 text-cyan-400 flex items-center justify-center shrink-0">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[11px] font-mono text-neutral-500">Operations Hub</div>
                    <div className="font-semibold text-white">Thememax Tech World HQ</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Engagement SLA Assurance */}
            <div className="p-6 rounded-2xl bg-neutral-900/40 border border-neutral-800 space-y-3">
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-wider">
                <ShieldCheck className="w-4 h-4" />
                <span>Client Partnership SLA</span>
              </div>
              <p className="text-xs text-neutral-400 leading-relaxed">
                All communications are protected under mutual Non-Disclosure Agreement standards. No sales spam or third-party data broker sharing.
              </p>
            </div>
          </div>

          {/* Form Column */}
          <div className="lg:col-span-8">
            <div className="p-8 sm:p-12 rounded-3xl bg-neutral-900/60 border border-neutral-800 relative">
              {submitResult?.success ? (
                <div className="py-16 text-center space-y-5 animate-in fade-in duration-300">
                  <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-2xl font-bold font-display text-white">
                    Project Brief Received
                  </h3>
                  <div className="inline-block px-3 py-1 rounded bg-neutral-950 font-mono text-xs text-orange-400 border border-neutral-800">
                    Reference ID: {submitResult.id}
                  </div>
                  <p className="text-sm text-neutral-300 max-w-md mx-auto leading-relaxed">
                    {submitResult.message}
                  </p>
                  <div className="pt-4">
                    <button
                      onClick={() => setSubmitResult(null)}
                      className="px-6 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold uppercase tracking-wider text-white"
                    >
                      Submit Another Brief
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-8">
                  {submitResult && !submitResult.success && (
                    <div className="p-4 rounded-xl bg-red-950/60 border border-red-800/80 text-red-300 text-xs flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                      <span>{submitResult.message}</span>
                    </div>
                  )}

                  {/* Honeypot field (hidden from genuine users) */}
                  <div className="hidden" aria-hidden="true">
                    <input
                      type="text"
                      name="company_fax_verification"
                      tabIndex={-1}
                      autoComplete="off"
                      value={formData.honeypot}
                      onChange={(e) => setFormData({ ...formData, honeypot: e.target.value })}
                    />
                  </div>

                  {/* 1. Services Multi-select buttons */}
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-300 mb-3">
                      Required Services / Disciplines <span className="text-orange-500">*</span>
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {availableServices.map((service) => {
                        const isSelected = formData.services.includes(service);
                        return (
                          <button
                            type="button"
                            key={service}
                            onClick={() => toggleService(service)}
                            className={`px-3.5 py-2 rounded-lg text-xs font-medium transition-all ${
                              isSelected
                                ? "bg-orange-500 text-white shadow-md shadow-orange-500/25"
                                : "bg-neutral-950 text-neutral-400 hover:text-white border border-neutral-800"
                            }`}
                          >
                            {service}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* 2. Budget Range Selection */}
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-300 mb-3">
                      Target Monthly or Project Budget Range <span className="text-orange-500">*</span>
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                      {budgetRanges.map((range) => {
                        const isSelected = formData.budget === range;
                        return (
                          <button
                            type="button"
                            key={range}
                            onClick={() => setFormData({ ...formData, budget: range })}
                            className={`p-3 rounded-xl text-xs font-mono font-medium text-center transition-all ${
                              isSelected
                                ? "bg-neutral-800 text-orange-400 border border-orange-500/50 shadow-inner"
                                : "bg-neutral-950 text-neutral-400 hover:text-white border border-neutral-800"
                            }`}
                          >
                            {range}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* 3. Client Contact Fields */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                        Your Full Name <span className="text-orange-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="e.g. Alex Sterling"
                        className={`w-full bg-neutral-950 border rounded-xl px-4 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none transition-colors ${
                          errors.name ? "border-red-500" : "border-neutral-800 focus:border-orange-500"
                        }`}
                      />
                      {errors.name && <span className="text-[11px] text-red-400 mt-1 block">{errors.name}</span>}
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                        Company or Brand Name <span className="text-orange-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={formData.company}
                        onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                        placeholder="e.g. Acme Mobility"
                        className={`w-full bg-neutral-950 border rounded-xl px-4 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none transition-colors ${
                          errors.company ? "border-red-500" : "border-neutral-800 focus:border-orange-500"
                        }`}
                      />
                      {errors.company && <span className="text-[11px] text-red-400 mt-1 block">{errors.company}</span>}
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                        Work Email Address <span className="text-orange-500">*</span>
                      </label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="alex@acme.example"
                        className={`w-full bg-neutral-950 border rounded-xl px-4 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none transition-colors ${
                          errors.email ? "border-red-500" : "border-neutral-800 focus:border-orange-500"
                        }`}
                      />
                      {errors.email && <span className="text-[11px] text-red-400 mt-1 block">{errors.email}</span>}
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                        Phone or WhatsApp <span className="text-orange-500">*</span>
                      </label>
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="+91 98765 43210"
                        className={`w-full bg-neutral-950 border rounded-xl px-4 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none transition-colors ${
                          errors.phone ? "border-red-500" : "border-neutral-800 focus:border-orange-500"
                        }`}
                      />
                      {errors.phone && <span className="text-[11px] text-red-400 mt-1 block">{errors.phone}</span>}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                      Current Website URL (Optional)
                    </label>
                    <input
                      type="url"
                      value={formData.website}
                      onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                      placeholder="https://acme.example"
                      className="w-full bg-neutral-950 border border-neutral-800 focus:border-orange-500 rounded-xl px-4 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                      Project Details, Current CAC, or Key Targets <span className="text-orange-500">*</span>
                    </label>
                    <textarea
                      rows={4}
                      value={formData.details}
                      onChange={(e) => setFormData({ ...formData, details: e.target.value })}
                      placeholder="Briefly describe your current growth bottlenecks, quarterly targets, or what you want us to build..."
                      className={`w-full bg-neutral-950 border rounded-xl px-4 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none transition-colors ${
                        errors.details ? "border-red-500" : "border-neutral-800 focus:border-orange-500"
                      }`}
                    />
                    {errors.details && <span className="text-[11px] text-red-400 mt-1 block">{errors.details}</span>}
                  </div>

                  {/* Submission CTA */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-4 text-xs font-semibold uppercase tracking-wider text-white bg-gradient-to-r from-orange-500 via-red-600 to-orange-600 hover:from-orange-600 hover:to-red-700 rounded-xl shadow-lg shadow-orange-500/25 transition-all duration-200 active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <span>Transmitting Project Brief...</span>
                    ) : (
                      <>
                        <span>Send Project Enquiry</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
        </FadeUp>
      </section>
    </div>
  );
};
