import React, { useState, useEffect } from "react";
import { useLocation, Link } from "react-router-dom";
import { ChevronDown, ArrowRight, CheckCircle2, Layers, Sparkles } from "lucide-react";
import { servicesData, ServiceCategory } from "../data/servicesData";
import { CTASection } from "../components/CTASection";
import { FadeUp, StaggerContainer, StaggerItem } from "../components/FadeUp";

export const Services: React.FC = () => {
  const [openCategories, setOpenCategories] = useState<Record<string, boolean>>({
    "strategy-branding": true,
    "digital-marketing": true,
    "social-media": false,
    "creative-content": false,
    "web-technology": false
  });

  const location = useLocation();

  useEffect(() => {
    if (location.hash) {
      const targetId = location.hash.replace("#", "");
      setOpenCategories((prev) => ({ ...prev, [targetId]: true }));
      const elem = document.getElementById(targetId);
      if (elem) {
        setTimeout(() => {
          elem.scrollIntoView({ behavior: "smooth" });
        }, 100);
      }
    }
  }, [location.hash]);

  const toggleCategory = (id: string) => {
    setOpenCategories((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 pt-32 sm:pt-40">
      {/* Header */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 border-b border-neutral-900">
        <FadeUp delay={0.1} className="max-w-3xl">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-orange-500 mb-3">
            <span>Integrated Capabilities</span>
          </div>
          <h1 className="text-4xl sm:text-6xl font-extrabold font-display text-white tracking-tight leading-tight text-balance">
            What We Do
          </h1>
          <p className="mt-4 text-lg text-neutral-300 leading-relaxed text-balance">
            From brand strategy to performance marketing, we build complete digital growth systems designed to turn market attention into compounding enterprise value.
          </p>
        </FadeUp>
      </section>

      {/* Services Categories Accordion / Expandable Presentation */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {servicesData.map((category, idx) => {
          const isOpen = !!openCategories[category.id];
          return (
            <FadeUp key={category.id} delay={0.08 * idx}>
              <div
                id={category.id}
                className={`rounded-3xl border transition-all duration-300 overflow-hidden ${
                  isOpen
                    ? "bg-neutral-900/80 border-neutral-700/80 shadow-2xl"
                    : "bg-neutral-900/40 border-neutral-800 hover:border-neutral-700"
                }`}
              >
                {/* Category Header Bar */}
                <button
                  onClick={() => toggleCategory(category.id)}
                  className="w-full p-6 sm:p-10 flex flex-col md:flex-row md:items-center justify-between gap-6 text-left group"
                  aria-expanded={isOpen}
                >
                  <div className="space-y-2 max-w-2xl">
                    <div className="flex items-center gap-3">
                      <span className="w-2.5 h-2.5 rounded-full bg-orange-500" />
                      <h2 className="text-2xl sm:text-3xl font-bold font-display text-white group-hover:text-orange-400 transition-colors">
                        {category.title}
                      </h2>
                    </div>
                    <p className="text-sm font-medium text-orange-400/90 pl-5">
                      {category.tagline}
                    </p>
                    <p className="text-xs sm:text-sm text-neutral-400 pl-5 leading-relaxed">
                      {category.description}
                    </p>
                  </div>

                  <div className="flex items-center justify-between md:justify-end gap-6 pl-5 md:pl-0">
                    {/* Category key metrics */}
                    <div className="flex items-center gap-6">
                      {category.metrics.map((m, mIdx) => (
                        <div key={mIdx} className="text-right">
                          <div className="text-xl sm:text-2xl font-bold font-mono text-emerald-400 tabular-nums">
                            {m.value}
                          </div>
                          <div className="text-[11px] text-neutral-400">{m.label}</div>
                        </div>
                      ))}
                    </div>

                    {/* Toggle button */}
                    <div className="w-10 h-10 rounded-full bg-neutral-800 border border-neutral-700 flex items-center justify-center text-white shrink-0 group-hover:bg-orange-500 transition-colors">
                      <ChevronDown
                        className={`w-5 h-5 transition-transform duration-300 ${
                          isOpen ? "rotate-180" : ""
                        }`}
                      />
                    </div>
                  </div>
                </button>

                {/* Expandable Sub-Services Grid */}
                {isOpen && (
                  <div className="px-6 sm:px-10 pb-10 pt-4 border-t border-neutral-800/80 bg-neutral-950/40 animate-in fade-in duration-300">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
                      {category.subServices.map((sub, sIdx) => (
                        <div
                          key={sIdx}
                          className="p-6 rounded-2xl bg-neutral-900/90 border border-neutral-800/90 hover:border-neutral-700 transition-colors flex flex-col justify-between"
                        >
                          <div>
                            <h3 className="text-lg font-bold font-display text-white mb-2">
                              {sub.name}
                            </h3>
                            <p className="text-xs text-neutral-400 leading-relaxed mb-4">
                              {sub.description}
                            </p>
                          </div>

                          <div>
                            <div className="text-[10px] font-mono uppercase tracking-widest text-neutral-500 mb-2">
                              Standard Deliverables
                            </div>
                            <div className="space-y-1.5">
                              {sub.deliverables.map((del, dIdx) => (
                                <div key={dIdx} className="flex items-center gap-2 text-xs text-neutral-300">
                                  <CheckCircle2 className="w-3.5 h-3.5 text-orange-500 shrink-0" />
                                  <span>{del}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Bottom category CTA */}
                    <div className="mt-8 pt-6 border-t border-neutral-800/80 flex flex-col sm:flex-row items-center justify-between gap-4">
                      <div className="text-xs text-neutral-400">
                        Need custom scoping or multidisciplinary execution in {category.title}?
                      </div>
                      <Link
                        to="/contact"
                        className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs font-semibold uppercase tracking-wider transition-colors shadow-md shadow-orange-500/20"
                      >
                        <span>Inquire About {category.title}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </Link>
                    </div>
                  </div>
                )}
              </div>
            </FadeUp>
          );
        })}
      </section>

      {/* Final CTA */}
      <FadeUp delay={0.1}>
        <CTASection />
      </FadeUp>
    </div>
  );
};
