import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight, CheckCircle2, Shield, Zap, Target, Award, Users, Compass } from "lucide-react";
import { CTASection } from "../components/CTASection";
import { StatsSection } from "../components/StatsSection";
import { FadeUp, StaggerContainer, StaggerItem } from "../components/FadeUp";

export const About: React.FC = () => {
  const leadershipTeam = [
    {
      name: "Devon Zhang",
      role: "Founder & Chief Executive Officer",
      bio: "Former growth engineering lead at top tech scaleups. 12+ years pioneering performance attribution systems and digital brand architectures.",
      focus: "Strategy & Capital Allocation"
    },
    {
      name: "Sophia Laurent",
      role: "Executive Creative Director",
      bio: "Ex-creative studio head with Cannes Lion recognized work. Specializes in kinetic branding, typography systems, and luxury campaigns.",
      focus: "Brand Systems & Design"
    },
    {
      name: "Aarav Mehta",
      role: "Head of Growth & Performance",
      bio: "Managed over ₹320 Cr in paid advertising spend across Google, Meta, and programmatic exchanges with proprietary bidding algorithms.",
      focus: "Paid Acquisition & Funnels"
    },
    {
      name: "Kavita Rao",
      role: "VP of Engineering & Web Technology",
      bio: "Architected sub-second headless e-commerce storefronts and WebGL experiences for global commercial enterprises.",
      focus: "Cloud Systems & Speed"
    }
  ];

  const values = [
    {
      icon: Target,
      title: "Quantitative Rigor",
      desc: "We don't gamble client capital on vague intuition. Every creative angle and campaign deployment is backed by structured hypotheses and verifiable metrics."
    },
    {
      icon: Zap,
      title: "Speed as a Weapon",
      desc: "Markets reward velocity. We ship rapid weekly creative iterations, sub-second web platforms, and agile response strategies that outpace bureaucracy."
    },
    {
      icon: Shield,
      title: "Uncompromising Craft",
      desc: "Performance without brand dignity is cheap. High-converting work must still look and feel like world-class editorial artistry."
    },
    {
      icon: Compass,
      title: "Radical Transparency",
      desc: "Direct attribution reports, raw data access, zero hidden agency markups, and unfiltered operational reviews with your executive leadership."
    }
  ];

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 pt-32 sm:pt-40">
      {/* Hero Header */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20 border-b border-neutral-900">
        <FadeUp delay={0.1} className="max-w-3xl">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-orange-500 mb-3">
            <span>About Thememax Tech World</span>
          </div>
          <h1 className="text-4xl sm:text-6xl font-extrabold font-display text-white tracking-tight leading-tight text-balance">
            A creative agency built for the digital age.
          </h1>
          <p className="mt-6 text-lg text-neutral-300 leading-relaxed text-balance">
            We exist to dismantle the artificial divide between brand storytelling and numerical performance marketing. Ideas that move businesses forward require both.
          </p>
        </FadeUp>
      </section>

      {/* Narrative Section */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-b border-neutral-900">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <FadeUp delay={0.1} className="lg:col-span-6 space-y-6">
            <span className="text-xs font-semibold uppercase tracking-widest text-orange-500">
              Our Genesis
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-white tracking-tight">
              Why We Built Thememax
            </h2>
            <p className="text-sm text-neutral-300 leading-relaxed">
              A decade ago, brands had to hire two fundamentally different agencies: a traditional design firm that produced gorgeous graphics but had no concept of CAC or LTV, and a media-buying agency that generated leads through ugly, clickbait ad templates.
            </p>
            <p className="text-sm text-neutral-400 leading-relaxed">
              We realized that in the modern algorithmic landscape, high aesthetic craft is the single most potent lever for lowering acquisition costs. When an advertisement looks like cinema and the destination website renders in 600 milliseconds, conversion rates surge.
            </p>
            <p className="text-sm text-neutral-400 leading-relaxed">
              Today, Thememax operates across the globe, serving market leaders in real estate, automotive, healthcare, finance, and consumer commerce.
            </p>
          </FadeUp>

          <FadeUp delay={0.2} className="lg:col-span-6">
            <div className="p-8 sm:p-10 rounded-3xl bg-neutral-900/60 border border-neutral-800 space-y-6">
              <h3 className="text-xl font-bold font-display text-white">
                Our Operating Principles
              </h3>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-orange-500 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-sm text-white">Creative Testing Matrix:</strong>
                    <p className="text-xs text-neutral-400 mt-0.5">We test 12-24 creative hooks weekly to discover true outlier ad performance.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-sm text-white">Edge-First Codebases:</strong>
                    <p className="text-xs text-neutral-400 mt-0.5">Every web application is engineered for sub-second mobile render times.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-sm text-white">Direct Executive Alignment:</strong>
                    <p className="text-xs text-neutral-400 mt-0.5">No junior account managers buffering communications; direct access to growth directors.</p>
                  </div>
                </div>
              </div>
            </div>
          </FadeUp>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-b border-neutral-900">
        <FadeUp delay={0.1} className="max-w-2xl mb-16">
          <span className="text-xs font-semibold uppercase tracking-widest text-orange-500">
            Guiding Philosophy
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold font-display text-white tracking-tight mt-2">
            The DNA of Thememax
          </h2>
        </FadeUp>

        <StaggerContainer staggerDelay={0.1} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {values.map((v, i) => {
            const Icon = v.icon;
            return (
              <StaggerItem key={i}>
                <div className="p-6 rounded-2xl bg-neutral-900/60 border border-neutral-800 flex flex-col justify-between h-full">
                  <div>
                    <div className="w-12 h-12 rounded-xl bg-orange-500/15 text-orange-500 flex items-center justify-center mb-4">
                      <Icon className="w-6 h-6" />
                    </div>
                    <h3 className="text-lg font-bold font-display text-white mb-2">{v.title}</h3>
                    <p className="text-xs text-neutral-400 leading-relaxed">{v.desc}</p>
                  </div>
                </div>
              </StaggerItem>
            );
          })}
        </StaggerContainer>
      </section>

      {/* Leadership Team */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-b border-neutral-900">
        <FadeUp delay={0.1} className="max-w-2xl mb-16">
          <span className="text-xs font-semibold uppercase tracking-widest text-orange-500">
            Agency Leadership
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold font-display text-white tracking-tight mt-2">
            Led by Practitioners
          </h2>
          <p className="mt-4 text-sm text-neutral-400">
            Our leadership team actively audits accounts, scripts commercial narratives, and oversees system deployments.
          </p>
        </FadeUp>

        <StaggerContainer staggerDelay={0.1} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {leadershipTeam.map((lead, idx) => (
            <StaggerItem key={idx}>
              <div className="p-6 rounded-2xl bg-neutral-900/60 border border-neutral-800 flex flex-col justify-between h-full">
                <div>
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-orange-500 to-red-600 flex items-center justify-center text-white text-xl font-bold font-display mb-4 shadow-lg shadow-orange-500/20">
                    {lead.name.split(" ").map(n => n[0]).join("")}
                  </div>
                  <h3 className="text-lg font-bold font-display text-white">{lead.name}</h3>
                  <div className="text-xs text-orange-400 font-medium mb-3">{lead.role}</div>
                  <p className="text-xs text-neutral-400 leading-relaxed">{lead.bio}</p>
                </div>
                <div className="mt-6 pt-4 border-t border-neutral-800 text-[11px] font-mono text-neutral-400">
                  Focus: {lead.focus}
                </div>
              </div>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </section>

      {/* Stats Section with FadeUp */}
      <FadeUp delay={0.1}>
        <StatsSection />
      </FadeUp>

      {/* CTA */}
      <FadeUp delay={0.1}>
        <CTASection />
      </FadeUp>
    </div>
  );
};
