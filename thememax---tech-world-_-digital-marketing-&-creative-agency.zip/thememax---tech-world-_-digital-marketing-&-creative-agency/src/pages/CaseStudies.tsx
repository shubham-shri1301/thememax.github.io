import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight, CheckCircle2, Quote, Clock, TrendingUp } from "lucide-react";
import { caseStudiesData } from "../data/caseStudiesData";
import { CTASection } from "../components/CTASection";
import { FadeUp, StaggerContainer, StaggerItem } from "../components/FadeUp";

export const CaseStudies: React.FC = () => {
  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 pt-32 sm:pt-40">
      {/* Header */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 border-b border-neutral-900">
        <FadeUp delay={0.1} className="max-w-3xl">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-orange-500 mb-3">
            <span>In-Depth Client Case Studies</span>
          </div>
          <h1 className="text-4xl sm:text-6xl font-extrabold font-display text-white tracking-tight leading-tight text-balance">
            Real Transformations. Measurable Outcomes.
          </h1>
          <p className="mt-4 text-lg text-neutral-300 leading-relaxed text-balance">
            Explore how we dismantle commercial growth bottlenecks across complex industries through bespoke creative strategy, media buying algorithms, and web technology.
          </p>
          <div className="mt-4 text-xs font-mono text-neutral-400">
            * Note: Quantitative client metrics represent verified demonstration results.
          </div>
        </FadeUp>
      </section>

      {/* Deep Case Studies List */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-20">
        {caseStudiesData.map((study, index) => (
          <FadeUp key={study.id} delay={0.1} distance={28}>
            <div
              className="p-8 sm:p-14 rounded-3xl bg-neutral-900/60 border border-neutral-800 relative overflow-hidden"
            >
              {/* Top Index & Industry Bar */}
              <div className="flex flex-wrap items-center justify-between gap-4 pb-8 border-b border-neutral-800">
                <div className="flex items-center gap-3">
                  <span className="text-xs font-mono font-bold text-orange-500 bg-orange-500/10 px-2.5 py-1 rounded">
                    CASE 0{index + 1}
                  </span>
                  <span className="text-base font-bold text-white font-display">
                    {study.client}
                  </span>
                  <span className="text-xs text-neutral-400">· {study.industry}</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-mono text-neutral-400">
                  <Clock className="w-3.5 h-3.5 text-neutral-500" />
                  <span>Engagement: {study.timeline}</span>
                </div>
              </div>

              {/* Headline */}
              <h2 className="text-2xl sm:text-4xl font-extrabold font-display text-white mt-8 mb-8 leading-tight">
                {study.headline}
              </h2>

              {/* Challenge & Solution Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 py-6">
                <div className="space-y-3">
                  <div className="text-xs font-mono uppercase tracking-widest text-red-400 font-semibold">
                    The Core Obstacle
                  </div>
                  <p className="text-sm text-neutral-300 leading-relaxed">
                    {study.challenge}
                  </p>
                </div>

                <div className="space-y-3">
                  <div className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-semibold">
                    The Agency Solution
                  </div>
                  <p className="text-sm text-neutral-300 leading-relaxed">
                    {study.solution}
                  </p>
                </div>
              </div>

              {/* Tactical Execution Approach */}
              <div className="mt-6 pt-6 border-t border-neutral-800">
                <div className="text-xs font-mono uppercase tracking-widest text-neutral-400 mb-4 font-semibold">
                  Strategic Execution Architecture
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {study.approach.map((point, pIdx) => (
                    <div key={pIdx} className="flex items-start gap-3 p-3 rounded-xl bg-neutral-950/60 border border-neutral-800/80">
                      <CheckCircle2 className="w-4 h-4 text-orange-500 shrink-0 mt-0.5" />
                      <span className="text-xs text-neutral-300 leading-relaxed">{point}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Impact Metric Cards */}
              <div className="mt-10 pt-8 border-t border-neutral-800">
                <div className="text-xs font-mono uppercase tracking-widest text-neutral-400 mb-4 font-semibold">
                  Verified Business Impact
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {study.results.map((res, rIdx) => (
                    <div key={rIdx} className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800">
                      <div className="text-3xl font-extrabold font-mono text-emerald-400 tabular-nums">
                        {res.metric}
                      </div>
                      <div className="text-xs text-neutral-300 mt-1 font-medium">
                        {res.description}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Client Testimonial Quote */}
              <div className="mt-10 p-6 rounded-2xl bg-neutral-950/80 border border-neutral-800 flex items-start gap-4">
                <Quote className="w-8 h-8 text-orange-500/40 shrink-0 mt-1" />
                <div>
                  <p className="text-sm text-neutral-200 italic leading-relaxed">
                    &ldquo;{study.quote.text}&rdquo;
                  </p>
                  <div className="mt-3 text-xs font-semibold text-white">
                    {study.quote.author} <span className="text-neutral-400 font-normal">· {study.quote.title}</span>
                  </div>
                </div>
              </div>
            </div>
          </FadeUp>
        ))}
      </section>

      {/* CTA */}
      <FadeUp delay={0.1}>
        <CTASection />
      </FadeUp>
    </div>
  );
};
