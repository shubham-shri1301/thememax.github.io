import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, BookOpen, Clock, User, X } from "lucide-react";
import { blogData, BlogPost } from "../data/blogData";
import { CTASection } from "../components/CTASection";
import { FadeUp } from "../components/FadeUp";

type BlogCategory = "All" | "Digital Marketing" | "SEO" | "Paid Advertising" | "Branding" | "AI Marketing" | "Social Media" | "Web Design";

const categories: BlogCategory[] = [
  "All",
  "Digital Marketing",
  "SEO",
  "Paid Advertising",
  "Branding",
  "AI Marketing",
  "Social Media",
  "Web Design"
];

export const Blog: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<BlogCategory>("All");
  const [readingPost, setReadingPost] = useState<BlogPost | null>(null);

  const filteredPosts = activeCategory === "All"
    ? blogData
    : blogData.filter((b) => b.category === activeCategory);

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 pt-32 sm:pt-40">
      {/* Header */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12 border-b border-neutral-900">
        <FadeUp>
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-orange-500 mb-3">
              <span>Agency Research & Analysis</span>
            </div>
            <h1 className="text-4xl sm:text-6xl font-extrabold font-display text-white tracking-tight leading-tight text-balance">
              Ideas & Insights
            </h1>
            <p className="mt-4 text-lg text-neutral-300 leading-relaxed text-balance">
              Strategic commentary, creative analysis, paid media testing playbooks, and web engineering teardowns directly from the Thememax studio floor.
            </p>
          </div>

          {/* Category Filter Buttons */}
          <div className="mt-10 flex flex-wrap items-center gap-2">
            {categories.map((cat) => {
              const isActive = activeCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-lg transition-all duration-200 ${
                    isActive
                      ? "bg-gradient-to-r from-orange-500 to-red-600 text-white shadow-md shadow-orange-500/20"
                      : "bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800 border border-neutral-800"
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </FadeUp>
      </section>

      {/* Blog Cards Grid */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <FadeUp delay={0.1}>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map((post) => (
              <div
                key={post.id}
                className="p-8 rounded-2xl bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 transition-all duration-300 flex flex-col justify-between group cursor-pointer"
                onClick={() => setReadingPost(post)}
              >
                <div>
                  {/* Zero-Pill metadata with · */}
                  <div className="flex items-center gap-2 text-xs text-neutral-400 mb-3">
                    <span className="text-orange-400 font-medium">{post.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>{post.readTime}</span>
                  </div>

                  <h3 className="text-xl font-bold font-display text-white group-hover:text-orange-400 transition-colors leading-snug">
                    {post.title}
                  </h3>

                  <p className="mt-4 text-xs text-neutral-400 leading-relaxed line-clamp-3">
                    {post.excerpt}
                  </p>
                </div>

                <div className="mt-8 pt-6 border-t border-neutral-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs text-neutral-400">
                    <User className="w-3.5 h-3.5 text-neutral-500" />
                    <span>{post.author.name}</span>
                  </div>
                  <div className="inline-flex items-center gap-1 text-xs font-semibold text-orange-400 group-hover:translate-x-1 transition-transform">
                    <span>Read Article</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </FadeUp>
      </section>

      {/* Reader Drawer / Modal */}
      {readingPost && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={readingPost.title}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
          onClick={() => setReadingPost(null)}
        >
          <div
            className="w-full max-w-3xl max-h-[85vh] bg-neutral-900 border border-neutral-800 rounded-3xl overflow-y-auto p-8 sm:p-12 shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setReadingPost(null)}
              className="absolute top-6 right-6 p-2 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-colors"
              aria-label="Close article"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-xs font-mono text-orange-400 mb-3">
              <span>{readingPost.category}</span>
              <span>·</span>
              <span>{readingPost.date}</span>
              <span>·</span>
              <span>{readingPost.readTime}</span>
            </div>

            <h2 className="text-2xl sm:text-4xl font-extrabold font-display text-white tracking-tight leading-tight pr-10">
              {readingPost.title}
            </h2>

            <div className="mt-4 pt-4 border-t border-neutral-800 flex items-center gap-3 text-xs text-neutral-400">
              <span className="font-semibold text-white">{readingPost.author.name}</span>
              <span>—</span>
              <span>{readingPost.author.role}</span>
            </div>

            <div className="mt-8 space-y-4 text-sm sm:text-base text-neutral-300 leading-relaxed">
              <p className="font-medium text-white text-lg">
                {readingPost.excerpt}
              </p>
              <p>{readingPost.content}</p>
              <p>
                As consumer attention fragments across channels, successful brands prioritize structured experimentation. Building high-velocity creative testing frameworks ensures your business remains resilient against algorithmic volatility.
              </p>
              <div className="p-6 rounded-2xl bg-neutral-950 border border-neutral-800 text-sm text-neutral-300">
                <strong className="text-white block mb-1">Key Strategic Takeaway:</strong>
                Never separate media spend from creative craft. When the ad creative and conversion experience speak the same high-standard language, acquisition costs compress dramatically.
              </div>
            </div>

            <div className="mt-10 pt-6 border-t border-neutral-800 flex items-center justify-between">
              <span className="text-xs text-neutral-500">Thememax Insights</span>
              <button
                onClick={() => setReadingPost(null)}
                className="px-5 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-white"
              >
                Close Article
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CTA */}
      <CTASection />
    </div>
  );
};
