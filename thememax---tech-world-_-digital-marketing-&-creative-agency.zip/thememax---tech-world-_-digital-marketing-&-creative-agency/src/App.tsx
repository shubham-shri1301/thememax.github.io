import React, { useEffect } from "react";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";
import { Home } from "./pages/Home";
import { About } from "./pages/About";
import { Services } from "./pages/Services";
import { Work } from "./pages/Work";
import { CaseStudies } from "./pages/CaseStudies";
import { Industries } from "./pages/Industries";
import { Blog } from "./pages/Blog";
import { Contact } from "./pages/Contact";
import { GalaxyProvider } from "./context/GalaxyContext";
import { GalaxyBackground } from "./components/GalaxyBackground";
import { GalaxyControls } from "./components/GalaxyControls";

// Component to ensure page scrolls to top on navigation unless a hash is present
const ScrollToTop: React.FC = () => {
  const { pathname, hash } = useLocation();

  useEffect(() => {
    if (!hash) {
      window.scrollTo(0, 0);
    }
  }, [pathname, hash]);

  return null;
};

export default function App() {
  return (
    <BrowserRouter>
      <GalaxyProvider>
        <ScrollToTop />
        <div className="flex flex-col min-h-screen bg-neutral-950/95 text-neutral-100 selection:bg-orange-500 selection:text-white relative">
          {/* Interactive Cosmic Galaxy Background */}
          <GalaxyBackground />

          <Header />
          <main className="flex-grow relative z-10">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/about" element={<About />} />
              <Route path="/services" element={<Services />} />
              <Route path="/work" element={<Work />} />
              <Route path="/case-studies" element={<CaseStudies />} />
              <Route path="/industries" element={<Industries />} />
              <Route path="/blog" element={<Blog />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="*" element={<Home />} />
            </Routes>
          </main>
          <Footer />

          {/* Interactive Galaxy Floating Controls HUD */}
          <GalaxyControls />
        </div>
      </GalaxyProvider>
    </BrowserRouter>
  );
}
