export interface CaseStudy {
  id: string;
  client: string;
  industry: string;
  headline: string;
  timeline: string;
  challenge: string;
  solution: string;
  approach: string[];
  results: { metric: string; description: string }[];
  quote: { text: string; author: string; title: string };
  accentColor: string;
}

export const caseStudiesData: CaseStudy[] = [
  {
    id: "nova-properties",
    client: "Nova Properties",
    industry: "Real Estate Development",
    headline: "Transforming Fragmented Ad Clicks into ₹154 Cr in Luxury Unit Sales",
    timeline: "6 Months",
    challenge: "Nova was spending over ₹35 Lakhs/month across Meta and Google Ads, but their sales reps reported that 78% of incoming leads were unqualified or unresponsive. Their static lead forms failed to capture intent or price bracket.",
    solution: "Thememax engineered a multi-stage qualification engine: deploying an interactive property unit visualizer that pre-qualified buyer budgets and timelines before triggering high-priority WhatsApp and CRM routing.",
    approach: [
      "Audience persona segmentation based on high-net-worth real estate behavioral signals",
      "Interactive 3D unit selector capturing square-footage preference and budget",
      "Dynamic webhook sync to HubSpot with instantaneous SMS/WhatsApp concierge alerts",
      "Algorithmic retargeting tailored to specific floor plans viewed"
    ],
    results: [
      { metric: "+340%", description: "Increase in sales-ready qualified consultations" },
      { metric: "-42%", description: "Reduction in customer acquisition cost per buyer" },
      { metric: "₹154 Cr", description: "Attributed property contract value closed" }
    ],
    quote: {
      text: "Thememax completely restructured our digital pipeline. Our sales team no longer chases dead leads; every conversation is with a vetted, high-intent buyer ready to tour.",
      author: "Marcus Vance",
      title: "Chief Commercial Officer, Nova Properties"
    },
    accentColor: "#FF5722"
  },
  {
    id: "aurelia-beauty",
    client: "Aurelia Beauty",
    industry: "Clean Cosmetics & DTC",
    headline: "Scaling DTC Revenue by 185% Through Headless Speed & Creator UGC",
    timeline: "4 Months",
    challenge: "Aurelia faced steep customer acquisition costs on paid social due to ad fatigue, while their legacy e-commerce storefront suffered from sluggish 4-second load times that caused high checkout abandonment.",
    solution: "We re-architected their digital presence: replacing their clunky theme with an ultra-fast React headless storefront with sub-second page transitions, and pairing it with a high-velocity UGC creative testing pipeline.",
    approach: [
      "Sub-0.8s headless storefront with 1-click bundle customizer",
      "30-day sprint generating 24 native TikTok and Reels creator hooks",
      "Klaviyo post-purchase cross-sell and automated replenishment sequences",
      "A/B checkout optimization eliminating form field friction"
    ],
    results: [
      { metric: "+185%", description: "Direct-to-consumer online revenue growth" },
      { metric: "0.6s", description: "Mobile checkout render speed (down from 4.2s)" },
      { metric: "3.8x", description: "Return on Ad Spend (ROAS) on Meta and TikTok" }
    ],
    quote: {
      text: "The speed of our new store combined with Thememax's creative engine doubled our conversion rate within the first 60 days. An unmatched agency partnership.",
      author: "Elena Rostova",
      title: "Founder & CEO, Aurelia Beauty"
    },
    accentColor: "#DC2626"
  },
  {
    id: "vertex-automotive",
    client: "Vertex Mobility",
    industry: "Electric Fleet Solutions",
    headline: "Securing 2,840+ Fleet Reservations for an Emerging EV Commercial Lineup",
    timeline: "8 Months",
    challenge: "Vertex was entering a crowded commercial EV market dominated by legacy manufacturers. They lacked brand awareness and needed a high-impact digital platform to secure pre-orders from corporate fleet directors.",
    solution: "We engineered an interactive commercial fleet configurator with real-time Total Cost of Ownership (TCO) calculators, backed by targeted Google Search campaigns capturing commercial vehicle procurement queries.",
    approach: [
      "Custom WebGL 3D vehicle visualizer with modular cargo configurations",
      "Dynamic fleet ROI and carbon emissions reduction calculator",
      "Targeted LinkedIn ABM campaign addressing corporate sustainability heads",
      "High-authority industry PR and technical EV publication link acquisition"
    ],
    results: [
      { metric: "2,840+", description: "Commercial fleet reservations secured" },
      { metric: "₹350 Cr+", description: "Qualified B2B enterprise procurement pipeline" },
      { metric: "#1", description: "Organic search ranking for commercial fleet electrification terms" }
    ],
    quote: {
      text: "Thememax proved that commercial B2B buyers respond to world-class interactive design. The 3D platform became our central sales weapon.",
      author: "Julian Chen",
      title: "VP of Global Marketing, Vertex Mobility"
    },
    accentColor: "#00D2FF"
  }
];
