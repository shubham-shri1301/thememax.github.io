export interface Industry {
  id: string;
  name: string;
  shortDesc: string;
  fullDesc: string;
  solutions: string[];
  keyMetric: string;
  metricLabel: string;
  color: string;
}

export const industriesData: Industry[] = [
  {
    id: "real-estate",
    name: "Real Estate",
    shortDesc: "High-ticket acquisition funnels, dynamic unit visualizers, and pre-qualified property buyer lead systems.",
    fullDesc: "We help property developers and luxury brokerages attract qualified buyers through targeted location geofencing, virtual unit tours, and automated CRM intake.",
    solutions: ["Dynamic Property Portals", "Pre-Qualified WhatsApp Inbound Funnels", "High-Net-Worth Paid Social Campaigns", "Hyper-Local SEO"],
    keyMetric: "₹1,500 Cr+",
    metricLabel: "Property Value Sold via Funnels",
    color: "#FF5722"
  },
  {
    id: "automotive",
    name: "Automotive & Mobility",
    shortDesc: "Interactive 3D car visualizers, dealership traffic generation, and electric vehicle fleet campaigns.",
    fullDesc: "From luxury dealerships to EV startups, we turn automotive enthusiasm into test drives and confirmed fleet orders with immersive digital experiences.",
    solutions: ["Interactive 3D Vehicle Customizers", "Dealership Footfall Google Ads", "TCO Fleet Calculators", "New Vehicle Launch Campaigns"],
    keyMetric: "14,000+",
    metricLabel: "Test Drive Inquiries",
    color: "#00D2FF"
  },
  {
    id: "healthcare",
    name: "Healthcare & Diagnostics",
    shortDesc: "HIPAA-conscious patient acquisition, telehealth booking portals, and medical authority content.",
    fullDesc: "We navigate healthcare compliance regulations to build high-trust digital front doors that connect patients with specialists seamlessly.",
    solutions: ["Compliant Patient Intake Portals", "Specialty Medical Search Campaigns", "Doctor Credential Showcase", "Reputation Management"],
    keyMetric: "+280%",
    metricLabel: "Patient Booking Surge",
    color: "#00C2FF"
  },
  {
    id: "education",
    name: "Education & EdTech",
    shortDesc: "Student recruitment campaigns, virtual campus tours, and automated admission counseling pipelines.",
    fullDesc: "We partner with leading universities, academies, and EdTech platforms to scale enrollment while lowering student acquisition cost.",
    solutions: ["Enrollment Lead Generation", "Course Landing Experience", "Parent & Student Funnels", "Webinar & Workshop Funnels"],
    keyMetric: "45,000+",
    metricLabel: "Student Applications",
    color: "#DC2626"
  },
  {
    id: "ecommerce",
    name: "E-Commerce & Retail",
    shortDesc: "Sub-second headless storefronts, high-velocity TikTok UGC, and full-funnel retargeting engines.",
    fullDesc: "We engineer online stores that load instantaneously, look like high-fashion editorials, and maximize lifetime customer value.",
    solutions: ["Headless Storefront Development", "Creator UGC Ad Production", "Klaviyo Retention Automation", "Checkout Abandonment Recovery"],
    keyMetric: "3.9x",
    metricLabel: "Average Blended ROAS",
    color: "#FF5722"
  },
  {
    id: "finance",
    name: "Finance & Fintech",
    shortDesc: "Institutional trust-building, wealth management lead generation, and compliant app growth funnels.",
    fullDesc: "We merge regulatory precision with Silicon Valley aesthetic standards to win institutional investors and digital banking consumers.",
    solutions: ["Institutional Brand Systems", "Interactive Wealth Calculators", "Fintech Mobile App Scaling", "Executive Thought Leadership"],
    keyMetric: "₹11,000 Cr+",
    metricLabel: "Platform AUM Supported",
    color: "#00D2FF"
  },
  {
    id: "hospitality",
    name: "Hospitality & Travel",
    shortDesc: "Direct reservation engines that cut OTA commissions, experiential storytelling, and VIP guest journeys.",
    fullDesc: "We empower luxury resorts, boutique hotels, and restaurant collectives to capture direct, zero-commission reservations.",
    solutions: ["Direct Booking Web Applications", "Cinematic Destination Film", "Seasonal Holiday Campaigns", "Influencer Travel Alliances"],
    keyMetric: "74%",
    metricLabel: "Direct Booking Capture",
    color: "#FF5722"
  },
  {
    id: "fashion",
    name: "Fashion & Luxury",
    shortDesc: "Kinetic lookbooks, seasonal drop countdowns, and aesthetic brand direction that sparks cultural desire.",
    fullDesc: "We craft visually arresting digital flagships and social media campaigns that transform apparel labels into cult brands.",
    solutions: ["High-Fashion Digital Flagships", "Limited-Drop Reservation Funnels", "Lookbook Motion Design", "High-Aesthetic Paid Social"],
    keyMetric: "48h",
    metricLabel: "Average Drop Sellout Time",
    color: "#DC2626"
  },
  {
    id: "beauty",
    name: "Beauty & Personal Care",
    shortDesc: "Clean cosmetic branding, authentic creator UGC engines, and subscription re-order flows.",
    fullDesc: "We engineer high-converting beauty narratives that highlight formulation purity, clinical efficacy, and viral consumer buzz.",
    solutions: ["Cosmetics Packaging & Identity", "TikTok Viral Hook Testing", "Subscription Retention Funnels", "Retail Partner Co-Op Campaigns"],
    keyMetric: "+195%",
    metricLabel: "Repeat Purchase Rate",
    color: "#FF6E40"
  },
  {
    id: "technology",
    name: "Technology & B2B SaaS",
    shortDesc: "Account-Based Marketing (ABM) on LinkedIn, product-led growth onboarding, and developer-grade websites.",
    fullDesc: "We translate complex software architectures and AI capabilities into compelling buyer propositions that enterprise executives understand.",
    solutions: ["Interactive Product Tours", "LinkedIn Enterprise ABM", "Technical Documentation Design", "Sales Pipeline Acceleration"],
    keyMetric: "₹540 Cr+",
    metricLabel: "SaaS Pipeline Generated",
    color: "#00D2FF"
  },
  {
    id: "manufacturing",
    name: "Manufacturing & Industrial",
    shortDesc: "Precision B2B OEM lead engines, digital capability catalogs, and international trade visibility.",
    fullDesc: "We modernize industrial suppliers and contract manufacturers with modern digital catalogs and global procurement search campaigns.",
    solutions: ["B2B RFQ Specification Portals", "Global Industrial SEO", "Factory & Cleanroom Video", "Distributor Portal Systems"],
    keyMetric: "320+",
    metricLabel: "Global RFQs Monthly",
    color: "#DC2626"
  },
  {
    id: "food-beverage",
    name: "Food & Beverage",
    shortDesc: "CPG brand architecture, supermarket shelf distribution campaigns, and direct-to-consumer beverage scaling.",
    fullDesc: "We craft appetizing digital presences, packaging systems, and localized retail launch campaigns for artisan food and drink brands.",
    solutions: ["CPG Brand Packaging Systems", "Store Locator & Retail Push", "Amazon & DTC Blended Strategy", "Sensory Social Creative"],
    keyMetric: "1,400+",
    metricLabel: "Retail Shelves Reached",
    color: "#FF5722"
  }
];
