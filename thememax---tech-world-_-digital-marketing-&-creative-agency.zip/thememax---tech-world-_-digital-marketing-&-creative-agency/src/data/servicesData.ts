export interface ServiceSubItem {
  name: string;
  description: string;
  deliverables: string[];
}

export interface ServiceCategory {
  id: string;
  title: string;
  tagline: string;
  description: string;
  accent: string;
  subServices: ServiceSubItem[];
  metrics: { value: string; label: string }[];
}

export const servicesData: ServiceCategory[] = [
  {
    id: "strategy-branding",
    title: "Strategy & Branding",
    tagline: "Define distinct identity. Own your market positioning.",
    description: "We craft enduring brand architectures, compelling verbal narratives, and future-proof design systems that transform how companies are perceived.",
    accent: "from-orange-500 to-amber-500",
    metrics: [
      { value: "3.4x", label: "Brand Recall Lift" },
      { value: "48+", label: "Brand Systems Built" }
    ],
    subServices: [
      {
        name: "Brand Strategy & Positioning",
        description: "Competitive auditing, market whitespace mapping, audience personas, and distinct value proposition formulation.",
        deliverables: ["Brand Positioning Playbook", "Audience Persona Dossiers", "Category Narrative Matrix"]
      },
      {
        name: "Visual Identity Systems",
        description: "Bespoke logos, typography hierarchies, kinetic design guidelines, color harmonies, and iconography.",
        deliverables: ["Comprehensive Brand Guidelines", "Vector Asset Suites", "Design Token Library"]
      },
      {
        name: "Creative & Art Direction",
        description: "Holistic creative governance across visual media, campaign collateral, packaging, and digital assets.",
        deliverables: ["Campaign Visual Guides", "Photography Direction", "Motion Spec Sheets"]
      },
      {
        name: "Communication Strategy",
        description: "Tone of voice frameworks, corporate messaging architectures, and multichannel brand storytelling.",
        deliverables: ["Tone of Voice Manual", "Brand Messaging Pillars", "Key Stakeholder Deck"]
      }
    ]
  },
  {
    id: "digital-marketing",
    title: "Digital & Performance Marketing",
    tagline: "Turn advertising budgets into predictable, scalable revenue.",
    description: "Data-engineered paid customer acquisition combining granular audience segmentation, real-time attribution, and rapid creative iteration.",
    accent: "from-red-600 to-orange-500",
    metrics: [
      { value: "412%", label: "Average ROAS" },
      { value: "₹300 Cr+", label: "Ad Spend Managed" }
    ],
    subServices: [
      {
        name: "Paid Search (Google & Bing Ads)",
        description: "Intent-harvesting search campaigns, smart bidding architectures, negative keyword firewalls, and shopping optimization.",
        deliverables: ["Search Campaign Restructure", "Bidding Algorithm Calibration", "Weekly Attribution Reports"]
      },
      {
        name: "Paid Social (Meta, TikTok, LinkedIn)",
        description: "High-velocity paid acquisition with creative testing matrix, dynamic catalog retargeting, and funnel-stage messaging.",
        deliverables: ["Creative Matrix Testing", "Full-Funnel Pixel Tracking", "Lookalike Modeling"]
      },
      {
        name: "Technical SEO & Organic Visibility",
        description: "Core Web Vitals audit, programmatic keyword clustering, link equity acquisition, and entity search optimization.",
        deliverables: ["Technical Audit Remediation", "Content Cluster Roadmap", "Monthly Search Visibility Dashboard"]
      },
      {
        name: "Conversion Rate Optimization (CRO)",
        description: "Heatmap analysis, multivariate split testing, behavioral user flows, and checkout friction eradication.",
        deliverables: ["A/B Testing Roadmap", "Conversion Audit Report", "High-Converting Page Variants"]
      }
    ]
  },
  {
    id: "social-media",
    title: "Social Media & Influence",
    tagline: "Cultivate magnetic communities that amplify your message.",
    description: "End-to-end community building, high-retention short-form video creation, and high-converting creator partnerships.",
    accent: "from-orange-500 to-rose-500",
    metrics: [
      { value: "82M+", label: "Organic Impressions" },
      { value: "4.8x", label: "Engagement Rate vs Industry" }
    ],
    subServices: [
      {
        name: "Social Media Management & Publishing",
        description: "Content calendars, daily community interaction, brand advocacy programs, and proactive reputation management.",
        deliverables: ["Monthly Content Calendars", "Community Response Protocol", "Performance Analytics"]
      },
      {
        name: "Short-Form Video Production (Reels, TikTok, Shorts)",
        description: "Viral hook structuring, scripted narrative content, rapid mobile editing, and trend-responsive turnaround.",
        deliverables: ["12-20 Monthly Studio Reels", "Trend Opportunity Alerts", "Sound & Audio Licensing"]
      },
      {
        name: "Influencer Marketing & Creator Alliances",
        description: "Creator vetting, contract negotiation, gifting campaigns, and performance-incentivized affiliate relationships.",
        deliverables: ["Creator Shortlists", "Affiliate Contract Setup", "Influencer ROI Tracking"]
      },
      {
        name: "User-Generated Content (UGC) Engine",
        description: "Direct-to-consumer UGC pipeline, video creator networks, and high-converting authentic testimonial libraries.",
        deliverables: ["Authentic UGC Video Bank", "Usage Rights Clearances", "Paid Social Native Variants"]
      }
    ]
  },
  {
    id: "creative-content",
    title: "Creative & Content Production",
    tagline: "High-craft visuals that stop the infinite scroll.",
    description: "Studio-grade creative engineering: 3D product visualizations, kinetic typography, motion graphics, and punchy commercial copywriting.",
    accent: "from-rose-500 to-red-600",
    metrics: [
      { value: "2,400+", label: "Ad Creatives Delivered" },
      { value: "98.2%", label: "Client Satisfaction" }
    ],
    subServices: [
      {
        name: "Motion Graphics & Kinetic Animation",
        description: "Dynamic logo stings, UI motion mockups, product explode animations, and broadcast-ready promotional clips.",
        deliverables: ["Lottie Web Animations", "Broadcast Motion Packages", "Kinetic Typography Reels"]
      },
      {
        name: "Commercial Graphic Design",
        description: "Display ads, pitch decks, corporate whitepapers, billboards, and high-conversion landing page graphical assets.",
        deliverables: ["Omnichannel Ad Kits", "Executive Keynotes", "Marketing Collateral Suites"]
      },
      {
        name: "Video Commercials & Post-Production",
        description: "Concept scripting, cinematic color grading, sound design, and multi-aspect ratio video cutdowns.",
        deliverables: ["4K Master Commercials", "16:9, 9:16, 1:1 Exports", "Custom Soundscapes"]
      },
      {
        name: "Conversion Copywriting",
        description: "Landing page copy, email sequences, video ad scripts, and value propositions that trigger emotional and rational buying decisions.",
        deliverables: ["High-Converting VSL Scripts", "Email Welcome Automations", "Ad Copy Swipe Files"]
      }
    ]
  },
  {
    id: "web-technology",
    title: "Web & Digital Technology",
    tagline: "Engineered for lightning speed, fluid interaction, and conversions.",
    description: "Next-generation web applications, bespoke headless e-commerce stores, and high-performing digital platforms built with modern technology.",
    accent: "from-cyan-500 to-blue-600",
    metrics: [
      { value: "< 0.8s", label: "Core Web Vital Speed" },
      { value: "99.98%", label: "Uptime Reliability" }
    ],
    subServices: [
      {
        name: "Modern Web Development",
        description: "React, Next.js, and Vite single-page applications with server-side caching, edge deployment, and fluid motion design.",
        deliverables: ["Production Web Application", "Component Library", "Clean TypeScript Codebase"]
      },
      {
        name: "Headless E-commerce Solutions",
        description: "Custom Shopify, WooCommerce, or headless storefronts with instant product filtering, 1-click checkouts, and CRM integrations.",
        deliverables: ["Custom Storefront Theme", "Payment Gateway Integration", "Inventory Sync Pipeline"]
      },
      {
        name: "High-Conversion Landing Pages",
        description: "Standalone performance landing pages architected for single-minded conversion, ultra-fast mobile rendering, and A/B testability.",
        deliverables: ["Custom Landing Pages", "Speed Optimization (95+ score)", "Form Attribution Webhooks"]
      },
      {
        name: "UI/UX & Design Systems",
        description: "Interactive Figma design systems, accessibility-audited wireframes, clickable prototypes, and micro-interaction engineering.",
        deliverables: ["Complete Figma Design System", "Interactive Prototype", "Accessibility Audit Report"]
      }
    ]
  }
];

export const featuredServicesList = [
  {
    id: "performance-marketing",
    name: "Performance Marketing",
    hook: "Turn advertising budgets into measurable growth.",
    description: "Full-funnel Google Ads, Meta Ads, and automated bid calibration engineered to lower CAC and scale lifetime customer value.",
    bullets: ["Google & Meta Ads", "Conversion Tracking", "Remarketing Funnels", "Campaign Optimization"],
    link: "/services#digital-marketing",
    accentColor: "#FF5722"
  },
  {
    id: "brand-strategy",
    name: "Brand & Visual Identity",
    hook: "Position your brand as the undeniable market leader.",
    description: "Comprehensive brand positioning, visual identity systems, and kinetic guidelines that establish premium market authority.",
    bullets: ["Brand Positioning", "Visual Identity Systems", "Brand Architecture", "Design Token Libraries"],
    link: "/services#strategy-branding",
    accentColor: "#DC2626"
  },
  {
    id: "seo-visibility",
    name: "Search Engine Optimization",
    hook: "Dominate search queries where buyers make decisions.",
    description: "Programmatic search architecture, Core Web Vitals engineering, entity modeling, and authoritative editorial link building.",
    bullets: ["Technical SEO", "Semantic Keyword Modeling", "Content Hubs", "Entity Search Optimization"],
    link: "/services#digital-marketing",
    accentColor: "#00D2FF"
  },
  {
    id: "web-development",
    name: "Web & E-Commerce Engineering",
    hook: "Lightning-fast digital platforms built to convert.",
    description: "Custom React applications, headless e-commerce platforms, and conversion-optimized landing pages engineered for speed.",
    bullets: ["Custom Web Apps", "E-Commerce Architecture", "Sub-Second Load Times", "Conversion-Focused UX"],
    link: "/services#web-technology",
    accentColor: "#FF5722"
  }
];
