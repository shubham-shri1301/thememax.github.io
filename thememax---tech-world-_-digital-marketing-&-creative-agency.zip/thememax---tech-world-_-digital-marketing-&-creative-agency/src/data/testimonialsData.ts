export interface Testimonial {
  id: string;
  name: string;
  company: string;
  role: string;
  quote: string;
  outcome: string;
  industry: string;
}

export const testimonialsData: Testimonial[] = [
  {
    id: "test-1",
    name: "Marcus Vance",
    company: "Nova Properties",
    role: "Chief Commercial Officer",
    quote: "Thememax completely transformed our digital presence. Instead of drowning our sales reps in thousands of unqualified form fills, their interactive qualification engine produced our highest-converting quarters in company history.",
    outcome: "+340% qualified property buyers, ₹154 Cr in closed contracts",
    industry: "Real Estate"
  },
  {
    id: "test-2",
    name: "Elena Rostova",
    company: "Aurelia Beauty",
    role: "Founder & CEO",
    quote: "The combination of high-craft creative design with technical web engineering is rare. Thememax delivered a headless store that loads in 0.6 seconds and paired it with a viral video engine that scaled our DTC sales 185% in four months.",
    outcome: "+185% online revenue, 3.8x ROAS across TikTok & Meta",
    industry: "Beauty & DTC"
  },
  {
    id: "test-3",
    name: "Julian Chen",
    company: "Vertex Mobility",
    role: "VP of Global Marketing",
    quote: "Commercial buyers demand serious evidence and intuitive technology. The 3D vehicle visualizer Thememax engineered became our central commercial weapon, driving over 2,800 fleet reservations before our assembly line even opened.",
    outcome: "2,840+ commercial fleet reservations secured",
    industry: "Automotive & CleanTech"
  },
  {
    id: "test-4",
    name: "Nadia Farooq",
    company: "Orbit Financial",
    role: "Managing Director",
    quote: "In institutional finance, trust is everything. Thememax elevated our brand identity to match our tier-1 hedge fund peers while engineering an acquisition funnel that generated a 210% increase in inbound enterprise RFPs.",
    outcome: "+210% inbound institutional RFPs, ₹9,800 Cr platform AUM",
    industry: "Financial Services"
  },
  {
    id: "test-5",
    name: "Thomas Sterling",
    company: "Monarch Apparel",
    role: "Brand Director",
    quote: "Their video and motion team has an innate pulse on contemporary culture. Our autumn drop sold out in 48 hours thanks to the kinetic campaign film and automated waitlist mechanics Thememax orchestrated.",
    outcome: "Complete capsule sellout in 48 hours, 4.6M organic views",
    industry: "Fashion & Retail"
  }
];

export const clientLogos = [
  { name: "NOVA", sector: "Real Estate", mark: "◆ NOVA" },
  { name: "VERTEX", sector: "Automotive", mark: "▲ VERTEX" },
  { name: "ORBIT", sector: "Fintech", mark: "◎ ORBIT" },
  { name: "LUMEN", sector: "Health", mark: "✦ LUMEN" },
  { name: "AXIS", sector: "Cloud Tech", mark: "✕ AXIS" },
  { name: "AUREL", sector: "Hospitality", mark: "◈ AUREL" },
  { name: "MONARCH", sector: "Apparel", mark: "❖ MONARCH" },
  { name: "PULSE", sector: "Media", mark: "◉ PULSE" },
  { name: "NEXAR", sector: "Robotics", mark: "■ NEXAR" }
];
