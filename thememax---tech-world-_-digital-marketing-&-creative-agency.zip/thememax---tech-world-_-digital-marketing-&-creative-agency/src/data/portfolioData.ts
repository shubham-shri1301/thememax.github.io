export interface Project {
  id: string;
  title: string;
  client: string;
  category: "Branding" | "Websites" | "Social Media" | "Performance" | "Video" | "Ecommerce";
  industry: string;
  summary: string;
  fullDescription: string;
  deliverables: string[];
  metrics: { label: string; value: string }[];
  accentColor: string;
  techStack: string[];
  featured: boolean;
}

export const portfolioData: Project[] = [
  {
    id: "nova-properties",
    title: "High-Ticket Real Estate Acquisition Engine",
    client: "Nova Properties",
    category: "Performance",
    industry: "Real Estate",
    summary: "Meta Ads campaign with interactive unit configurator and automated WhatsApp qualification funnel.",
    fullDescription: "Nova Properties suffered from high volumes of low-intent property inquiries that bogged down their sales team. We overhauled their digital acquisition funnel: deploying interactive dynamic lead qualification pages, hyper-targeted Meta & Google Search ads, and automated CRM routing that cut qualification latency from 14 hours to 4 minutes.",
    deliverables: ["Meta Ads Creative Suite", "Interactive Property Tour Funnel", "HubSpot CRM Webhook Workflow", "Conversion Tracking Architecture"],
    metrics: [
      { label: "Qualified Lead Volume", value: "+340%" },
      { label: "Cost Per Qualified Booking", value: "-42%" },
      { label: "Closed Pipeline Value", value: "₹154 Cr" }
    ],
    accentColor: "#FF5722",
    techStack: ["Meta Conversions API", "React Landing Engine", "Google Search Ads", "CRM Automation"],
    featured: true
  },
  {
    id: "aurelia-beauty",
    title: "Clean Beauty Headless Storefront & DTC Scale",
    client: "Aurelia Beauty",
    category: "Ecommerce",
    industry: "Beauty & Wellness",
    summary: "Headless e-commerce rebuild coupled with high-velocity TikTok UGC and dynamic retargeting.",
    fullDescription: "Aurelia Beauty's previous monolithic storefront suffered 4.2s mobile load times and a 1.2% conversion rate. We built a bespoke headless storefront utilizing modern edge caching, integrated a 1-click bundle builder, and deployed an intensive creator UGC testing engine on TikTok and Instagram Reels.",
    deliverables: ["Headless E-commerce Store", "18 Short-Form UGC Creatives", "Email & SMS Klaviyo Flows", "Custom Bundle Builder"],
    metrics: [
      { label: "E-commerce Conversion Rate", value: "+185%" },
      { label: "Average Order Value (AOV)", value: "+38%" },
      { label: "Mobile Page Load", value: "0.6s" }
    ],
    accentColor: "#DC2626",
    techStack: ["Shopify Headless", "React / Next.js", "Klaviyo", "TikTok Ads Manager"],
    featured: true
  },
  {
    id: "vertex-automotive",
    title: "Next-Gen EV Brand Experience & Lead Engine",
    client: "Vertex Mobility",
    category: "Websites",
    industry: "Automotive",
    summary: "Interactive 3D vehicle customizer, dealership routing platform, and organic search dominance.",
    fullDescription: "Vertex Mobility needed to launch their flagship electric commercial vehicle lineup across 6 markets simultaneously. We designed an immersive, interactive 3D visualizer that allowed fleet managers to customize battery configurations, calculate TCO savings, and book test drives directly with regional dealerships.",
    deliverables: ["Interactive 3D Web Visualizer", "Global Multilingual CMS", "Technical SEO Architecture", "Fleet Lead Generation Funnel"],
    metrics: [
      { label: "Test Drive Reservations", value: "2,840+" },
      { label: "Organic Search Top 3 Ranks", value: "48 Keywords" },
      { label: "Fleet Inquiries Generated", value: "₹350 Cr" }
    ],
    accentColor: "#00D2FF",
    techStack: ["Three.js / WebGL", "React SPA", "Google Ads Engine", "Salesforce Integration"],
    featured: true
  },
  {
    id: "orbit-fintech",
    title: "Institutional Wealth Platform Brand Transformation",
    client: "Orbit Financial",
    category: "Branding",
    industry: "Finance",
    summary: "Complete visual identity, design tokens, brand motion guidelines, and high-trust digital presence.",
    fullDescription: "Orbit required a brand refresh that balanced enterprise credibility with Silicon Valley agility. We rebuilt their visual identity from the ground up: introducing a bespoke geometric typeface, deep navy and cyan color hierarchy, an interactive investor dashboard design system, and executive thought leadership media.",
    deliverables: ["Comprehensive Brand System", "Figma Design Token Library", "Executive Keynote Decks", "Corporate Portal UI/UX"],
    metrics: [
      { label: "Institutional Inbound RFPs", value: "+210%" },
      { label: "Brand Recall Score", value: "94/100" },
      { label: "Assets Under Platform", value: "₹9,800 Cr" }
    ],
    accentColor: "#FF5722",
    techStack: ["Figma Enterprise", "Brand Token Architecture", "Corporate Motion Suite"],
    featured: true
  },
  {
    id: "lumen-health",
    title: "Patient Telehealth Funnel & Omnichannel Acquisition",
    client: "Lumen Diagnostics",
    category: "Performance",
    industry: "Healthcare",
    summary: "HIPAA-compliant search campaigns, localized symptom checker, and frictionless appointment booking.",
    fullDescription: "Lumen required strict regulatory compliance alongside aggressive patient acquisition across 14 metropolitan centers. We designed a compliant, fast symptom assessment funnel with localized Google Ads targeting high-intent health search terms.",
    deliverables: ["HIPAA-Compliant Intake Funnel", "Localized Google Ads Structure", "Medical Content Verification", "Review Generation System"],
    metrics: [
      { label: "Monthly Patient Bookings", value: "+460%" },
      { label: "CPA Reduction", value: "-36%" },
      { label: "Verified 5-Star Reviews", value: "1,200+" }
    ],
    accentColor: "#00D2FF",
    techStack: ["Google Health Ads", "Compliant Telehealth API", "React Mobile Funnel"],
    featured: false
  },
  {
    id: "monarch-apparel",
    title: "High-Fashion Streetwear Kinetic Video Campaign",
    client: "Monarch Apparel",
    category: "Video",
    industry: "Fashion",
    summary: "Editorial campaign film, 3D clothing simulations, and viral Instagram drop sequence.",
    fullDescription: "For Monarch's Autumn capsule launch, we engineered a cinematic multi-part video campaign filmed in brutalist architectural locations, augmented with kinetic 3D cloth simulations and high-energy electronic sound design.",
    deliverables: ["60s Cinema Commercial", "12 High-Energy Social Cutdowns", "Kinetic Motion Poster Series", "VIP Drop Countdown Funnel"],
    metrics: [
      { label: "Sold Out In", value: "48 Hours" },
      { label: "Organic Reel Views", value: "4.6M" },
      { label: "Follower Growth", value: "+62,000" }
    ],
    accentColor: "#DC2626",
    techStack: ["Cinema 4D", "DaVinci Resolve", "After Effects", "Instagram Shop"],
    featured: true
  },
  {
    id: "axis-cloud",
    title: "B2B SaaS LinkedIn Inbound & Account-Based Marketing",
    client: "Axis Cloud",
    category: "Social Media",
    industry: "Technology",
    summary: "Targeted ABM campaign targeting Fortune 500 CTOs and cloud engineering directors.",
    fullDescription: "Axis Cloud needed to penetrate enterprise engineering accounts without burning budget on broad awareness. We executed an Account-Based Marketing (ABM) strategy on LinkedIn, combining executive ghostwriting, interactive ROI calculators, and personalized video collateral.",
    deliverables: ["Executive LinkedIn Thought Leadership", "Interactive Cloud Savings Calculator", "ABM Account Targeting Tiering", "Cold Inbound Warmup Funnel"],
    metrics: [
      { label: "Enterprise Pipeline Created", value: "₹70 Cr" },
      { label: "Target Account Engagement", value: "68%" },
      { label: "Average Contract Value", value: "₹1.5 Cr" }
    ],
    accentColor: "#FF5722",
    techStack: ["LinkedIn Campaign Manager", "Clearbit", "React Calculator", "HubSpot Enterprise"],
    featured: false
  },
  {
    id: "aurel-hospitality",
    title: "Luxury Boutique Resort Digital Booking Engine",
    client: "Aurel Resorts",
    category: "Websites",
    industry: "Hospitality",
    summary: "Editorial travel web experience with immersive imagery and 0% commission direct booking engine.",
    fullDescription: "Aurel Resorts wanted to break dependency on high-commission Online Travel Agencies (OTAs). We engineered a breathtaking digital journey highlighting private villas, curated dining, and an ultra-streamlined direct booking engine with experiential upsells.",
    deliverables: ["Editorial Hospitality Web Experience", "Direct Booking Engine Integration", "Multilingual Experience (4 Languages)", "Luxury Email Concierge Sequence"],
    metrics: [
      { label: "Direct Booking Share", value: "72% (up from 24%)" },
      { label: "OTA Commission Saved", value: "₹3.4 Cr/yr" },
      { label: "Average Stay Duration", value: "+1.6 Nights" }
    ],
    accentColor: "#00D2FF",
    techStack: ["React SPA", "Custom Reservation Engine", "Tailwind CSS", "Stripe Connect"],
    featured: false
  }
];
