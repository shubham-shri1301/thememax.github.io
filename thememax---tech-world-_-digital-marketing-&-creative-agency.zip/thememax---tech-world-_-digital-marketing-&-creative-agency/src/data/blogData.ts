export interface BlogPost {
  id: string;
  slug: string;
  title: string;
  category: "Digital Marketing" | "SEO" | "Paid Advertising" | "Branding" | "AI Marketing" | "Social Media" | "Web Design";
  date: string;
  readTime: string;
  excerpt: string;
  content: string;
  author: { name: string; role: string };
  accentColor: string;
}

export const blogData: BlogPost[] = [
  {
    id: "post-1",
    slug: "post-ios-meta-ads-scaling-playbook",
    title: "The 2026 Paid Acquisition Playbook: Creative Velocity Over Bidding Tweaks",
    category: "Paid Advertising",
    date: "Sep 18, 2026",
    readTime: "6 min read",
    excerpt: "Why the highest-performing advertising teams have shifted 80% of their operational focus from media buying levers to structured creative hypothesis testing.",
    content: "Algorithms on Meta and Google have become exceptionally proficient at finding consumers. What they cannot do is manufacture emotional desire. In 2026, the brands achieving consistent 4x+ ROAS run systematic weekly creative testing matrixes: analyzing 3-second hook retention, testing divergent angle scripts, and dynamically serving modular video cuts at scale.",
    author: { name: "Aarav Mehta", role: "Head of Growth Engineering" },
    accentColor: "#FF5722"
  },
  {
    id: "post-2",
    slug: "modern-brand-identity-living-systems",
    title: "Beyond the Static Logo: Building Responsive, Living Brand Systems",
    category: "Branding",
    date: "Sep 12, 2026",
    readTime: "5 min read",
    excerpt: "How modern brands construct kinetic design guidelines and responsive token libraries that translate seamlessly from smartwatch viewports to 8K digital billboards.",
    content: "A PDF brand book is obsolete the week it is exported. Forward-thinking companies build living design systems encoded in code tokens, dynamic motion curves, and adaptable visual frameworks. We explore how kinetic type and programmatic color palettes establish deeper brand recognition across touchpoints.",
    author: { name: "Sophia Laurent", role: "Creative Director" },
    accentColor: "#DC2626"
  },
  {
    id: "post-3",
    slug: "ai-search-entity-seo-shift",
    title: "Entity-Based SEO: Dominating Search When AI Answers Before the Click",
    category: "SEO",
    date: "Aug 29, 2026",
    readTime: "7 min read",
    excerpt: "Navigating search engines that summarize results in AI overviews: why semantic schema, proprietary data, and direct brand authority are the only lasting defensibility.",
    content: "When search engines summarize answers directly, standard keyword stuffing yields zero traffic. The modern optimization frontier is Knowledge Graph citation: structuring proprietary datasets, earning authoritative editorial references, and establishing topical primacy that search algorithms reference as definitive truth.",
    author: { name: "Rohan Kapoor", role: "Technical Search Lead" },
    accentColor: "#00D2FF"
  },
  {
    id: "post-4",
    slug: "headless-speed-ecommerce-conversion",
    title: "Why Sub-Second Page Speeds Out-Convert Flashy Gimmicks Every Time",
    category: "Web Design",
    date: "Aug 15, 2026",
    readTime: "4 min read",
    excerpt: "The math of latency: how shaving 1.2 seconds off mobile render times directly lifted checkout completion rates by 28% without altering a single marketing sentence.",
    content: "Consumer attention is razor thin. Every 100 milliseconds of latency during checkout costs measurable margin. By decoupling frontend storefronts from monolithic backends and serving pre-rendered edge assets, brands eliminate the invisible friction that causes mobile abandonment.",
    author: { name: "Devon Zhang", role: "VP of Web Engineering" },
    accentColor: "#FF5722"
  },
  {
    id: "post-5",
    slug: "ai-generative-video-workflows",
    title: "Deploying AI in Agency Video Pipelines: Amplifying Human Craftsmanship",
    category: "AI Marketing",
    date: "Jul 28, 2026",
    readTime: "6 min read",
    excerpt: "How our studio uses generative AI for rapid storyboarding, localized voiceover dubbing, and dynamic visual variant testing while keeping human taste at the helm.",
    content: "AI does not replace visionary art direction; it liberates creative teams from repetitive production grunt work. Discover how our studio accelerates commercial video turnarounds from 6 weeks to 8 days through intelligent generative pre-visualization workflows.",
    author: { name: "Kavita Rao", role: "Executive Video Producer" },
    accentColor: "#DC2626"
  },
  {
    id: "post-6",
    slug: "b2b-social-c-suite-influence",
    title: "Executive Ghostwriting on LinkedIn: The Unfair Inbound Advantage",
    category: "Social Media",
    date: "Jul 10, 2026",
    readTime: "5 min read",
    excerpt: "Why corporate logos struggle for organic reach while verified founder and C-suite profiles generate millions in high-margin enterprise software pipeline.",
    content: "People buy from people, not faceless corporate emblems. When an enterprise CEO or Head of Engineering regularly publishes sharp, unfiltered domain insights, inbound RFP velocity accelerates by 300%. Here is the exact editorial framework we use for C-level executives.",
    author: { name: "Liam O'Connor", role: "Director of Content Strategy" },
    accentColor: "#00D2FF"
  }
];
